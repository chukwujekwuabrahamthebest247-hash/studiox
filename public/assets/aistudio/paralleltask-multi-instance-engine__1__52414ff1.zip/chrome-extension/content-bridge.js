/**
 * OmniAgent Content Bridge (Runs inside the AI Studio / Preview tab)
 * Relays OMNIAGENT_BRIDGE_PING and OMNIAGENT_BRIDGE_REQUEST between the web page and background.js
 */

(function () {
  if (window.__omniAgentBridgeLoaded) return;
  window.__omniAgentBridgeLoaded = true;

  function relayToExtension(type, requestId, payload) {
    const responseType =
      type === 'OMNIAGENT_BRIDGE_PING'
        ? 'OMNIAGENT_BRIDGE_PONG'
        : 'OMNIAGENT_BRIDGE_RESPONSE';

    try {
      chrome.runtime.sendMessage(
        {
          type,
          requestId,
          payload,
        },
        (response) => {
          if (chrome.runtime.lastError) {
            window.postMessage(
              {
                source: 'omniagent-extension',
                type: responseType,
                requestId,
                payload: {
                  ok: false,
                  extensionInstalled: true,
                  connected: false,
                  error: chrome.runtime.lastError.message,
                },
              },
              '*'
            );
            return;
          }

          window.postMessage(
            {
              source: 'omniagent-extension',
              type: responseType,
              requestId,
              payload: response,
            },
            '*'
          );
        }
      );
    } catch (err) {
      window.postMessage(
        {
          source: 'omniagent-extension',
          type: responseType,
          requestId,
          payload: {
            ok: false,
            extensionInstalled: true,
            connected: false,
            error: err?.message || 'Extension communication failed',
          },
        },
        '*'
      );
    }
  }

  // Listen to window.postMessage from the React app
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'omniagent-app') return;

    if (
      data.type === 'OMNIAGENT_BRIDGE_PING' ||
      data.type === 'OMNIAGENT_BRIDGE_REQUEST'
    ) {
      relayToExtension(data.type, data.requestId, data.payload || {});
    }
  });
})();
