/**
 * OmniAgent Background Service Worker (Manifest V3)
 * Locates open AI web tabs (Gemini, ChatGPT, Claude) and relays prompts + screenshots.
 */

const AI_TAB_MATCHERS = [
  { provider: 'Gemini', key: 'gemini', patterns: ['gemini.google.com', 'google.com/gemini'] },
  { provider: 'ChatGPT', key: 'chatgpt', patterns: ['chatgpt.com', 'chat.openai.com'] },
  { provider: 'Claude', key: 'claude', patterns: ['claude.ai'] },
];

function detectProviderFromUrl(url) {
  if (!url) return null;
  const lower = url.toLowerCase();
  for (const matcher of AI_TAB_MATCHERS) {
    if (matcher.patterns.some((p) => lower.includes(p))) {
      return matcher;
    }
  }
  return null;
}

async function findAvailableAiTabs() {
  const allTabs = await chrome.tabs.query({});
  const matches = [];
  for (const tab of allTabs) {
    const info = detectProviderFromUrl(tab.url);
    if (info) {
      matches.push({ tab, ...info });
    }
  }
  return matches;
}

function selectTargetTab(matches, preferredProvider = 'auto') {
  if (!matches || matches.length === 0) return null;

  if (preferredProvider && preferredProvider !== 'auto') {
    const exact = matches.find((m) => m.key === preferredProvider.toLowerCase());
    if (exact) return exact;
  }

  // Prefer active or most recently highlighted tab
  const activeMatch = matches.find((m) => m.tab.active);
  return activeMatch || matches[0];
}

async function sendMessageWithAutoInject(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    // Content script may not have been injected if the AI tab was open before loading extension
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content-ai-tab.js'],
    });
    return await chrome.tabs.sendMessage(tabId, message);
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !message.type) return false;

  if (message.type === 'OMNIAGENT_BRIDGE_PING') {
    (async () => {
      try {
        const preferred = message.payload?.preferredProvider || 'auto';
        const matches = await findAvailableAiTabs();
        const selected = selectTargetTab(matches, preferred);
        const availableProviders = Array.from(new Set(matches.map((m) => m.provider)));

        if (!selected) {
          sendResponse({
            extensionInstalled: true,
            connected: false,
            activeTabProvider: null,
            availableProviders: [],
            error: 'Extension active, but no Gemini, ChatGPT, or Claude tab is currently open.',
          });
          return;
        }

        // Verify tab script responds
        try {
          await sendMessageWithAutoInject(selected.tab.id, { type: 'AI_TAB_PING' });
        } catch {}

        sendResponse({
          extensionInstalled: true,
          connected: true,
          activeTabProvider: selected.provider,
          activeTabTitle: selected.tab.title || selected.provider,
          activeTabUrl: selected.tab.url,
          availableProviders,
        });
      } catch (err) {
        sendResponse({
          extensionInstalled: true,
          connected: false,
          activeTabProvider: null,
          error: err?.message || 'Tab lookup failed',
        });
      }
    })();
    return true;
  }

  if (message.type === 'OMNIAGENT_BRIDGE_REQUEST') {
    (async () => {
      try {
        const preferred = message.payload?.preferredProvider || 'auto';
        const matches = await findAvailableAiTabs();
        const selected = selectTargetTab(matches, preferred);

        if (!selected) {
          sendResponse({
            ok: false,
            error: 'No open Gemini, ChatGPT, or Claude web tab found.',
          });
          return;
        }

        const result = await sendMessageWithAutoInject(selected.tab.id, {
          type: 'EXECUTE_AI_PROMPT',
          payload: {
            mode: message.payload?.mode || 'plan',
            prompt: message.payload?.prompt || '',
            screenshot: message.payload?.screenshot || null,
          },
        });

        sendResponse({
          ok: Boolean(result?.ok),
          text: result?.text || '',
          provider: selected.provider,
          error: result?.error,
        });
      } catch (err) {
        sendResponse({
          ok: false,
          error: err?.message || 'Failed to relay prompt to AI web tab',
        });
      }
    })();
    return true;
  }

  return false;
});
