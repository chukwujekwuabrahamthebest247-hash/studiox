/**
 * OmniAgent AI Tab Controller (Runs on gemini.google.com, chatgpt.com, claude.ai)
 * Injects prompt + optional base64 screenshot, clicks Send, waits for streaming completion, and scrapes response.
 */

(function () {
  if (window.__omniAgentAITabLoaded) return;
  window.__omniAgentAITabLoaded = true;

  function detectSite() {
    const host = window.location.hostname.toLowerCase();
    if (host.includes('gemini') || host.includes('google.com')) return 'Gemini';
    if (host.includes('chatgpt') || host.includes('openai')) return 'ChatGPT';
    if (host.includes('claude.ai')) return 'Claude';
    return 'WebAI';
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function dataUrlToFile(dataUrl, filename = 'phone-screenshot.png') {
    const arr = dataUrl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/png';
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  function findChatInput() {
    const selectors = [
      // ChatGPT
      '#prompt-textarea',
      'div[id="prompt-textarea"][contenteditable="true"]',
      // Gemini
      'rich-textarea .ql-editor[contenteditable="true"]',
      '.ql-editor[contenteditable="true"]',
      // Claude
      'div.ProseMirror[contenteditable="true"]',
      // Generic fallbacks
      'div[contenteditable="true"][role="textbox"]',
      'textarea[placeholder]',
      'textarea',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }
    return document.querySelector('textarea, div[contenteditable="true"]');
  }

  function setInputText(inputEl, text) {
    if (!inputEl) return false;
    inputEl.focus();

    if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        'value'
      )?.set;
      if (setter) {
        setter.call(inputEl, text);
      } else {
        inputEl.value = text;
      }
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    // Contenteditable editors (Gemini .ql-editor, Claude .ProseMirror, ChatGPT div)
    inputEl.innerHTML = '';
    const p = document.createElement('p');
    p.textContent = text;
    inputEl.appendChild(p);
    inputEl.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  async function attachScreenshot(screenshotDataUrl, inputEl) {
    if (!screenshotDataUrl) return false;
    try {
      const file = dataUrlToFile(screenshotDataUrl, `omniagent-${Date.now()}.png`);

      // 1. Try assigning to an <input type="file">
      const fileInputs = Array.from(document.querySelectorAll('input[type="file"]'));
      if (fileInputs.length > 0) {
        const targetInput = fileInputs[fileInputs.length - 1];
        const dt = new DataTransfer();
        dt.items.add(file);
        targetInput.files = dt.files;
        targetInput.dispatchEvent(new Event('change', { bubbles: true }));
        targetInput.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(800);
        return true;
      }

      // 2. Fallback: Dispatch clipboard paste event directly onto the chat editor
      if (inputEl) {
        inputEl.focus();
        const dt = new DataTransfer();
        dt.items.add(file);
        const pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: dt,
        });
        inputEl.dispatchEvent(pasteEvent);
        await sleep(800);
        return true;
      }
    } catch (err) {
      console.warn('[OmniAgent AI Tab] Screenshot attach warning:', err);
    }
    return false;
  }

  function findSendButton() {
    const selectors = [
      // ChatGPT
      'button[data-testid="send-button"]',
      'button[aria-label*="Send prompt" i]',
      // Gemini
      'button.send-button',
      'button[aria-label*="Send message" i]',
      'button[mattooltip*="Send" i]',
      // Claude
      'button[aria-label="Send Message"]',
      'button[aria-label*="Send" i]',
      // Generic
      'button[type="submit"]',
    ];
    for (const sel of selectors) {
      const btn = document.querySelector(sel);
      if (btn && !btn.disabled && btn.getAttribute('aria-disabled') !== 'true') {
        return btn;
      }
    }
    return null;
  }

  function isCurrentlyStreaming() {
    const stopSelectors = [
      'button[data-testid="stop-button"]',
      'button[aria-label*="Stop generating" i]',
      'button[aria-label*="Stop response" i]',
      'button[aria-label*="Stop streaming" i]',
      'button[aria-label="Stop"]',
    ];
    return stopSelectors.some((sel) => Boolean(document.querySelector(sel)));
  }

  function getAssistantMessagesText() {
    const site = detectSite();
    let nodes = [];

    if (site === 'ChatGPT') {
      nodes = Array.from(document.querySelectorAll('[data-message-author-role="assistant"]'));
    } else if (site === 'Gemini') {
      nodes = Array.from(document.querySelectorAll('model-response, message-content, .model-response-text'));
    } else if (site === 'Claude') {
      nodes = Array.from(document.querySelectorAll('[data-is-streaming], .font-claude-message, [class*="claude"]'));
    }

    if (nodes.length === 0) {
      nodes = Array.from(document.querySelectorAll('article, [role="article"], .markdown'));
    }

    return nodes.map((n) => (n.innerText || n.textContent || '').trim()).filter(Boolean);
  }

  async function waitForCompletion(previousCount, previousLastText, timeoutMs = 26000) {
    const start = Date.now();
    let stableTicks = 0;
    let lastObservedText = '';

    // Wait briefly for streaming to start
    await sleep(900);

    while (Date.now() - start < timeoutMs) {
      const texts = getAssistantMessagesText();
      const latestText = texts.length > 0 ? texts[texts.length - 1] : '';
      const hasNewMessage = texts.length > previousCount || (latestText && latestText !== previousLastText);
      const streaming = isCurrentlyStreaming();

      if (hasNewMessage && !streaming && latestText.length > 0) {
        if (latestText === lastObservedText) {
          stableTicks++;
          if (stableTicks >= 3) {
            return latestText;
          }
        } else {
          lastObservedText = latestText;
          stableTicks = 0;
        }
      } else {
        lastObservedText = latestText;
        stableTicks = 0;
      }

      await sleep(350);
    }

    // Return latest captured text if we timed out after getting partial/complete text
    const finalTexts = getAssistantMessagesText();
    const finalLatest = finalTexts.length > 0 ? finalTexts[finalTexts.length - 1] : '';
    if (finalLatest && finalLatest !== previousLastText) {
      return finalLatest;
    }
    return null;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || !message.type) return false;

    if (message.type === 'AI_TAB_PING') {
      sendResponse({ ok: true, site: detectSite() });
      return false;
    }

    if (message.type === 'EXECUTE_AI_PROMPT') {
      (async () => {
        try {
          const { prompt, screenshot } = message.payload || {};
          const inputEl = findChatInput();
          if (!inputEl) {
            sendResponse({
              ok: false,
              error: `Could not locate chat input on ${detectSite()}. Make sure you are logged in to an active chat.`,
            });
            return;
          }

          const existingMessages = getAssistantMessagesText();
          const prevCount = existingMessages.length;
          const prevLastText = prevCount > 0 ? existingMessages[prevCount - 1] : '';

          if (screenshot) {
            await attachScreenshot(screenshot, inputEl);
          }

          setInputText(inputEl, prompt);
          await sleep(250);

          const sendBtn = findSendButton();
          if (sendBtn) {
            sendBtn.click();
          } else {
            inputEl.dispatchEvent(
              new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true,
              })
            );
          }

          const responseText = await waitForCompletion(prevCount, prevLastText);
          if (!responseText) {
            sendResponse({
              ok: false,
              error: `Timed out waiting for ${detectSite()} to finish generating.`,
            });
            return;
          }

          sendResponse({
            ok: true,
            provider: detectSite(),
            text: responseText,
          });
        } catch (err) {
          sendResponse({
            ok: false,
            error: err?.message || 'Failed to execute prompt in AI web tab',
          });
        }
      })();
      return true;
    }

    return false;
  });
})();
