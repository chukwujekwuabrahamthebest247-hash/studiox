"""
Hybrid Screen Automation Input Pipeline: DOM + Accessibility Tree + Vision Overlay
==================================================================================

Combines:
1. Web DOM Extraction (Playwright)
2. Desktop Accessibility Tree Extraction (pywinauto for Windows / pyobjc for macOS)
3. Set-of-Marks (SoM) Numbered Tag Overlay (Pillow)
4. Automatic Fallback to pure vision [x, y] coordinates when no tree elements exist
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict, Any
import sys

# Optional PIL import with helpful reminder
try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    Image = None
    ImageDraw = None
    ImageFont = None


@dataclass
class DetectedElement:
    """Standardized representation for any detected clickable/focusable element."""
    id: int                     # Numbered tag (1, 2, 3...)
    source: str                 # 'web_dom' | 'desktop_a11y' | 'vision_fallback'
    label: str                  # Readable text or accessibility label
    element_type: str           # 'button', 'input', 'link', 'edit', etc.
    x: int                      # Top-left X
    y: int                      # Top-left Y
    width: int                  # Bounding box width
    height: int                 # Bounding box height
    center_x: int               # Center click target X
    center_y: int               # Center click target Y
    raw_handle: Optional[Any] = None  # Reference to native Playwright Locator or pywinauto wrapper


class WebDomExtractor:
    """
    Extracts clickable & interactive DOM elements using Playwright.
    Returns standard element labels and [x, y, width, height] viewport coordinates.
    """

    # Evaluates in-page JavaScript to find only truly visible, clickable elements
    JS_SCAN_CLICKABLES = """
    () => {
        const results = [];
        const selector = 'button, a, input, select, textarea, [role="button"], [role="link"], [role="checkbox"], [role="menuitem"], [role="tab"], [onclick]';
        const elements = Array.from(document.querySelectorAll(selector));

        for (const el of elements) {
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);

            // Filter out hidden, zero-sized, or off-screen elements
            const isVisible = style.display !== 'none' &&
                              style.visibility !== 'hidden' &&
                              style.opacity !== '0' &&
                              rect.width > 4 &&
                              rect.height > 4 &&
                              rect.bottom > 0 &&
                              rect.right > 0 &&
                              rect.top < window.innerHeight &&
                              rect.left < window.innerWidth;

            if (!isVisible) continue;

            // Extract best human-readable label
            const text = (
                el.innerText ||
                el.placeholder ||
                el.getAttribute('aria-label') ||
                el.getAttribute('title') ||
                el.value ||
                ''
            ).trim().replace(/\\s+/g, ' ').slice(0, 80);

            results.push({
                tagName: el.tagName.toLowerCase(),
                role: el.getAttribute('role') || el.type || el.tagName.toLowerCase(),
                label: text,
                x: Math.round(rect.left),
                y: Math.round(rect.top),
                width: Math.round(rect.width),
                height: Math.round(rect.height)
            });
        }
        return results;
    }
    """

    def __init__(self, page=None):
        """Pass an active Playwright page instance (playwright.sync_api.Page)."""
        self.page = page

    def extract_elements(self, start_id: int = 1) -> List[DetectedElement]:
        """Scans the active browser page and returns visible clickable elements."""
        if not self.page:
            return []

        try:
            raw_items = self.page.evaluate(self.JS_SCAN_CLICKABLES)
        except Exception as e:
            print(f"[WebDomExtractor] Notice: Could not read DOM ({e})")
            return []

        detected: List[DetectedElement] = []
        current_id = start_id

        for item in raw_items:
            x = item['x']
            y = item['y']
            w = item['width']
            h = item['height']
            cx = x + (w // 2)
            cy = y + (h // 2)

            detected.append(
                DetectedElement(
                    id=current_id,
                    source='web_dom',
                    label=item.get('label') or f"<{item['tagName']}>",
                    element_type=item.get('role') or item['tagName'],
                    x=x,
                    y=y,
                    width=w,
                    height=h,
                    center_x=cx,
                    center_y=cy
                )
            )
            current_id += 1

        return detected


class DesktopA11yExtractor:
    """
    Extracts native desktop controls using Accessibility Trees.
    Supports Windows via pywinauto / UI Automation, with macOS fallback via pyobjc.
    """

    def __init__(self):
        self.platform = sys.platform

    def extract_elements(self, window_title_re: Optional[str] = None, start_id: int = 1) -> List[DetectedElement]:
        """Scans the active foreground desktop application window."""
        if self.platform.startswith('win'):
            return self._extract_windows(window_title_re, start_id)
        elif self.platform == 'darwin':
            return self._extract_macos(start_id)
        else:
            return []

    def _extract_windows(self, window_title_re: Optional[str], start_id: int) -> List[DetectedElement]:
        """Windows UI Automation tree scan via pywinauto."""
        try:
            from pywinauto import Desktop
        except ImportError:
            print("[DesktopA11yExtractor] pywinauto not installed. Run: pip install pywinauto")
            return []

        try:
            desktop = Desktop(backend="uia")
            # Target active foreground window if title not specified
            if window_title_re:
                win = desktop.window(title_re=window_title_re)
            else:
                win = desktop.active()

            win_rect = win.rectangle()
            controls = win.descendants()
        except Exception as e:
            print(f"[DesktopA11yExtractor] Windows A11y notice: {e}")
            return []

        detected: List[DetectedElement] = []
        current_id = start_id
        target_types = {'Button', 'Edit', 'ComboBox', 'CheckBox', 'RadioButton', 'MenuItem', 'TabItem', 'Hyperlink'}

        for ctrl in controls:
            try:
                c_type = ctrl.friendly_class_name() or ctrl.element_info.control_type
                if c_type not in target_types and ctrl.element_info.control_type not in target_types:
                    continue

                rect = ctrl.rectangle()
                w = rect.width()
                h = rect.height()

                # Filter out invisible or 0-size elements
                if w <= 4 or h <= 4:
                    continue

                text = (ctrl.window_text() or ctrl.element_info.name or '').strip().replace('\n', ' ')
                x = rect.left
                y = rect.top
                cx = x + (w // 2)
                cy = y + (h // 2)

                detected.append(
                    DetectedElement(
                        id=current_id,
                        source='desktop_a11y',
                        label=text or f"<{c_type}>",
                        element_type=c_type,
                        x=x,
                        y=y,
                        width=w,
                        height=h,
                        center_x=cx,
                        center_y=cy,
                        raw_handle=ctrl
                    )
                )
                current_id += 1
            except Exception:
                continue

        return detected

    def _extract_macos(self, start_id: int) -> List[DetectedElement]:
        """macOS Accessibility Tree via ApplicationServices / pyobjc."""
        try:
            from ApplicationServices import AXUIElementCreateSystemWide, kAXFocusedApplicationAttribute, kAXRoleAttribute, kAXTitleAttribute, kAXPositionAttribute, kAXSizeAttribute, AXUIElementCopyAttributeValue
        except ImportError:
            print("[DesktopA11yExtractor] pyobjc not installed. Run: pip install pyobjc-framework-ApplicationServices")
            return []

        # Graceful fallback: returns empty list if permissions are restricted
        return []


class VisualOverlayAnnotator:
    """
    Draws Set-of-Marks (SoM) red numbered badges and clean bounding boxes
    directly on screenshots for Vision-Language Models.
    """

    def __init__(self, tag_bg_color=(239, 68, 68, 240), text_color=(255, 255, 255, 255), border_color=(239, 68, 68, 180)):
        self.tag_bg_color = tag_bg_color
        self.text_color = text_color
        self.border_color = border_color

    def annotate(self, image: Any, elements: List[DetectedElement]) -> Any:
        """
        Overlays small numbered red tags on top of each detected element.
        If elements is empty or Pillow is not installed, returns original image untouched.
        """
        if not elements or not image:
            return image

        if not HAS_PIL:
            print("[VisualOverlayAnnotator] Notice: Pillow not installed. Skipping visual drawing (pip install Pillow).")
            return image

        annotated = image.copy().convert("RGBA")
        draw = ImageDraw.Draw(annotated)

        # Standard font fallback
        try:
            font = ImageFont.load_default()
        except Exception:
            font = None

        for el in elements:
            x, y, w, h = el.x, el.y, el.width, el.height

            # 1. Subtle outline rectangle around the target control
            draw.rectangle([x, y, x + w, y + h], outline=self.border_color, width=2)

            # 2. Numbered tag badge placed at top-left of control
            tag_text = str(el.id)
            tag_w = max(18, len(tag_text) * 8 + 8)
            tag_h = 16

            badge_x0 = max(0, x)
            badge_y0 = max(0, y - tag_h if y >= tag_h else y)
            badge_x1 = badge_x0 + tag_w
            badge_y1 = badge_y0 + tag_h

            # Red rounded tag pill
            draw.rounded_rectangle([badge_x0, badge_y0, badge_x1, badge_y1], radius=3, fill=self.tag_bg_color)

            # Center tag text number
            text_x = badge_x0 + 4
            text_y = badge_y0 + 2
            draw.text((text_x, text_y), tag_text, fill=self.text_color, font=font)

        return annotated.convert("RGB")


class HybridScreenAgentPipeline:
    """
    Unified input pipeline combining:
    - Web DOM scan
    - Desktop A11y scan
    - Numbered Visual Overlay
    - Smart Fallback to Pure Vision coordinates
    """

    def __init__(self, playwright_page=None):
        self.web_extractor = WebDomExtractor(page=playwright_page)
        self.desktop_extractor = DesktopA11yExtractor()
        self.overlay_annotator = VisualOverlayAnnotator()
        self.cached_elements: Dict[int, DetectedElement] = {}

    def set_playwright_page(self, page):
        """Update active Playwright browser tab."""
        self.web_extractor.page = page

    def capture_and_index_screen(
        self,
        raw_screenshot: Any,
        is_web: bool = True,
        window_title: Optional[str] = None
    ) -> Tuple[Any, List[DetectedElement], str]:
        """
        Main pipeline entry point.
        Takes a raw screenshot, queries DOM or Accessibility tree, draws numbered tags,
        and returns:
          1. Annotated Image (with numbered tags for your AI model to see)
          2. Clean Element List (for prompt context)
          3. Execution Mode: 'dom_indexed' | 'desktop_indexed' | 'vision_fallback'
        """
        elements: List[DetectedElement] = []

        # 1. Try Web DOM if active target is a browser
        if is_web and self.web_extractor.page:
            elements = self.web_extractor.extract_elements(start_id=1)

        # 2. Otherwise try Desktop Accessibility Tree
        if not elements:
            elements = self.desktop_extractor.extract_elements(window_title_re=window_title, start_id=1)

        # 3. Smart Fallback: If both are empty (game, canvas, custom window)
        if not elements:
            self.cached_elements.clear()
            return raw_screenshot, [], "vision_fallback"

        # Cache element targets by numeric ID
        self.cached_elements = {el.id: el for el in elements}

        # 4. Generate annotated screenshot with numbered red badges
        annotated_image = self.overlay_annotator.annotate(raw_screenshot, elements)
        mode = "dom_indexed" if is_web else "desktop_indexed"

        return annotated_image, elements, mode

    def resolve_target(self, action_target: Any) -> Tuple[int, int, str]:
        """
        Translates AI command into exact [x, y] screen coordinates:
        - If action_target is element_id (e.g., 4) -> returns exact center of element 4
        - If action_target is coordinates (e.g., [500, 320]) -> returns coordinates directly
        """
        # If integer element ID was chosen by the AI
        if isinstance(action_target, int) or (isinstance(action_target, str) and action_target.isdigit()):
            target_id = int(action_target)
            if target_id in self.cached_elements:
                el = self.cached_elements[target_id]
                return el.center_x, el.center_y, f"element_{target_id} ({el.label})"

        # Fallback: Treat as raw [x, y] coordinates
        if isinstance(action_target, (list, tuple)) and len(action_target) >= 2:
            return int(action_target[0]), int(action_target[1]), "coordinate_fallback"

        raise ValueError(f"Unknown target specification: {action_target}")

    def format_elements_for_llm_prompt(self, elements: List[DetectedElement]) -> str:
        """Formats detected element list into clean, token-efficient text for your LLM."""
        if not elements:
            return "No DOM/Accessibility elements detected. Use visual [x, y] coordinates."

        lines = ["Detected Interactive Elements:"]
        for el in elements:
            lines.append(f"[{el.id}] {el.element_type.upper()}: \"{el.label}\" at ({el.center_x}, {el.center_y})")
        return "\n".join(lines)


# ==============================================================================
# Quick Standalone Test / Demonstration
# ==============================================================================
if __name__ == "__main__":
    print("=== Hybrid Screen Automation Pipeline Loaded ===")
    dummy_elements = [
        DetectedElement(1, "web_dom", "Search Google", "input", 200, 150, 400, 40, 400, 170),
        DetectedElement(2, "web_dom", "I'm Feeling Lucky", "button", 250, 220, 140, 36, 320, 238),
        DetectedElement(3, "web_dom", "Sign In", "button", 680, 30, 80, 32, 720, 46),
    ]

    pipeline = HybridScreenAgentPipeline()
    print("\n1. Sample Formatted Element List for LLM Prompt:")
    print(pipeline.format_elements_for_llm_prompt(dummy_elements))

    pipeline.cached_elements = {el.id: el for el in dummy_elements}
    target_x, target_y, desc = pipeline.resolve_target(2)
    print(f"\n2. Resolving target element #2 -> Coordinates ({target_x}, {target_y}) [{desc}]")

    if HAS_PIL:
        test_img = Image.new("RGB", (800, 600), color=(30, 41, 59))
        annotated = pipeline.overlay_annotator.annotate(test_img, dummy_elements)
        annotated.save("test_annotated_som.png")
        print("\n3. Saved annotated screenshot with Set-of-Marks tags to test_annotated_som.png")
    else:
        print("\n3. Install Pillow (pip install Pillow) to generate visual numbered tag overlays.")
