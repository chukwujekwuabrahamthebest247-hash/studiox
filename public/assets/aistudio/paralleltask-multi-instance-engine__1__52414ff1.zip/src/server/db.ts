/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const DEFAULT_INITIAL_BALANCE = 0; // Zero welcome grant: new accounts start with 0 tokens
export const SERVER_TOKENS_PER_DOLLAR = 2_500_000; // $8.00 = 20,000,000 tokens -> $1.00 = 2,500,000 tokens
export const STANDARD_PACKAGE_DOLLARS = 8;
export const STANDARD_PACKAGE_TOKENS = 20_000_000;
export const APP_INSTALL_TOKEN_COST = 25_000;
export const PROMPT_PLANNING_TOKEN_COST = 5_000;
export const EXECUTION_STEP_TOKEN_COST = 1_500;
export const SERVER_REFERRAL_BONUS_TOKENS = 5_000_000;
export const REFERRAL_QUALIFYING_PURCHASE_USD = 8;
export const LOW_QUOTA_ALERT_THRESHOLD = 250_000;
export const MAX_FLEET_VIRTUAL_SLOTS = 250_000;

export interface DbUser {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  salt: string;
  referralCode: string;
  referredBy?: string;
  createdAt: string;
}

export interface DbSession {
  token: string;
  userId: string;
  email: string;
  name: string;
  createdAt: string;
  expiresAt: string;
}

export interface DbWallet {
  userId: string;
  referralCode: string;
  referredBy?: string;
  hasMadeFirstQualifyingPurchase: boolean;
  referralInvitesCount: number;
  referralConversionsCount: number;
  referralTokensEarned: number;
  appTokenBalance: number;
  lifetimeTokensUsed: number;
  lifetimeTokensPurchased: number;
  lastTopupDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DbLedgerEntry {
  id: string;
  userId: string;
  timestamp: string;
  type: 'TOPUP' | 'AUTOMATION_RUN' | 'REFUND' | 'REFERRAL_BONUS';
  workflowName: string;
  tokensDelta: number;
  balanceAfter: number;
  dollarEquivalent: number;
  amountInDollars?: number;
  reference?: string;
  metadata?: {
    promptSnippet?: string;
    stepsCount?: number;
    paymentReference?: string;
    provider?: string;
    referralCode?: string;
    referredUser?: string;
    friendName?: string;
  };
}

export interface DbReferralRecord {
  referralCode: string;
  ownerUserId?: string;
  invites: string[];
  conversions: Array<{ friendId: string; timestamp: string; tokensAwarded: number }>;
  totalBonusTokens: number;
}

export interface DbReviewRecord {
  id: string;
  rating: number;
  title?: string;
  reviewText: string;
  authorName?: string;
  authorEmail?: string;
  category?: string;
  submittedAt: string;
  destinationEmail?: string;
}

export interface DbWorkflowRecord {
  id: string;
  slug: string;
  title: string;
  description: string;
  prompt: string;
  targetApp: string;
  author: string;
  createdAt: string;
  runCount: number;
  cloneCount: number;
  estimatedTokens: number;
  estimatedSeconds: number;
  tags: string[];
  isFeatured?: boolean;
}

export type FleetSlotStatus = 'idle' | 'running' | 'paused' | 'completed' | 'hydrating';
export type FleetSlotPlatform = 'android' | 'ios' | 'linux' | 'windows';

export interface DbFleetSlot {
  id: string;
  slotNumber: number;
  title: string;
  status: FleetSlotStatus;
  platform: FleetSlotPlatform;
  region: string;
  workerNode: string;
  streamUrl?: string;
  webrtcUrl?: string;
  currentApp: string;
  currentTaskSummary: string;
  stepProgress: { current: number; total: number };
  memoryUsageMb: number;
  createdAt: string;
  updatedAt: string;
}

export interface FleetVirtualBatch {
  id: string;
  startSlotNumber: number;
  count: number;
  platform: FleetSlotPlatform;
  region: string;
  taskSummary: string;
  status: FleetSlotStatus;
  createdAt: string;
}

export interface IosRegisteredAppRecord {
  bundleId: string;
  appName: string;
  launchUrl?: string;
  sha256?: string;
  deduplicated?: boolean;
  engineMode: 'webkit_linux' | 'xcode_simulator';
  engineLabel: string;
  installedAt: string;
}

interface OmniAgentJsonDb {
  users: Record<string, DbUser>;
  usersByEmail: Record<string, string>;
  sessions: Record<string, DbSession>;
  wallets: Record<string, DbWallet>;
  ledger: Record<string, DbLedgerEntry[]>;
  referrals: Record<string, DbReferralRecord>;
  processedPaymentRefs: Record<string, string>;
  reviews: DbReviewRecord[];
  workflows: DbWorkflowRecord[];
  fleetExplicitSlots: Record<string, DbFleetSlot>;
  fleetVirtualBatches: FleetVirtualBatch[];
  fleetNextSlotNumber: number;
  iosApps: Record<string, IosRegisteredAppRecord>;
  iosActiveLaunchMeta: { bundleId?: string; appName?: string; launchUrl?: string };
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const JSON_DB_PATH = path.join(DATA_DIR, 'omniagent_db.json');

const DEFAULT_FEATURED_WORKFLOW: DbWorkflowRecord = {
  id: 'wf-lead-scraper-pro',
  slug: 'copy-my-automated-lead-scraper',
  title: 'Automated Lead Scraper',
  description:
    'Searches the web for high-growth tech startups, extracts executive founder contacts, and securely compiles them into a structured Notes lead sheet.',
  prompt:
    'Open SearchGlobe browser, search for top AI startups in San Francisco, extract founder contact details and save into a note titled "AI Startup Leads".',
  targetApp: 'browser',
  author: 'Abraham (Platform Creator)',
  createdAt: new Date().toISOString(),
  runCount: 248,
  cloneCount: 97,
  estimatedTokens: 950,
  estimatedSeconds: 6,
  tags: ['Leads', 'Scraper', 'Sales', 'Productivity'],
  isFeatured: true,
};

function createDefaultSlot1(): DbFleetSlot {
  const now = new Date().toISOString();
  return {
    id: 'slot-1',
    slotNumber: 1,
    title: 'Prompt Slot #1: Autonomous Mobile Operator',
    status: 'idle',
    platform: 'android',
    region: 'us-east-1',
    workerNode: 'worker-edge-01',
    currentApp: 'home',
    currentTaskSummary: 'Ready for instructions',
    stepProgress: { current: 1, total: 1 },
    memoryUsageMb: 42.4,
    createdAt: now,
    updatedAt: now,
  };
}

function createEmptyDb(): OmniAgentJsonDb {
  return {
    users: {},
    usersByEmail: {},
    sessions: {},
    wallets: {},
    ledger: {},
    referrals: {},
    processedPaymentRefs: {},
    reviews: [],
    workflows: [DEFAULT_FEATURED_WORKFLOW],
    fleetExplicitSlots: {
      'slot-1': createDefaultSlot1(),
    },
    fleetVirtualBatches: [],
    fleetNextSlotNumber: 2,
    iosApps: {},
    iosActiveLaunchMeta: {},
  };
}

let supabaseClient: SupabaseClient | null = null;
let supabaseInitAttempted = false;
let supabaseAuthVerifierClient: SupabaseClient | null = null;
let supabaseAuthInitAttempted = false;
let supabaseWarned = false;

export function getSupabaseClient(): SupabaseClient | null {
  if (supabaseInitAttempted) return supabaseClient;
  supabaseInitAttempted = true;
  const url = (process.env.SUPABASE_URL || '').trim();
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  if (url && key) {
    supabaseClient = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    console.log('[DB] Supabase PostgreSQL client initialized for stateless horizontal scaling.');
  } else {
    console.log(
      `[DB] SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not configured. Using atomic JSON persistence at ${JSON_DB_PATH}`
    );
  }
  return supabaseClient;
}

export function getSupabaseAuthVerifierClient(): SupabaseClient | null {
  if (supabaseClient) return supabaseClient;
  if (supabaseAuthInitAttempted) return supabaseAuthVerifierClient;
  supabaseAuthInitAttempted = true;
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
  const key = (
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY ||
    ''
  ).trim();
  if (url && key) {
    supabaseAuthVerifierClient = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    console.log('[AUTH] Supabase Auth JWT verifier initialized.');
  }
  return supabaseAuthVerifierClient;
}

export function getStorageMode(): 'supabase' | 'json_file' {
  return getSupabaseClient() ? 'supabase' : 'json_file';
}

// Per-replica serialized file lock (only used for local JSON dev fallback; Supabase handles row atomicity natively)
let dbLockChain: Promise<unknown> = Promise.resolve();

export function withDbLock<T>(fn: () => Promise<T>): Promise<T> {
  const next = dbLockChain.then(fn, fn);
  dbLockChain = next.then(
    () => undefined,
    () => undefined
  );
  return next;
}

function readJsonDb(): OmniAgentJsonDb {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(JSON_DB_PATH)) {
    const initial = createEmptyDb();
    writeJsonDb(initial);
    return initial;
  }
  try {
    const raw = fs.readFileSync(JSON_DB_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    const explicitSlots = parsed.fleetExplicitSlots || { 'slot-1': createDefaultSlot1() };
    return {
      users: parsed.users || {},
      usersByEmail: parsed.usersByEmail || {},
      sessions: parsed.sessions || {},
      wallets: parsed.wallets || {},
      ledger: parsed.ledger || {},
      referrals: parsed.referrals || {},
      processedPaymentRefs: parsed.processedPaymentRefs || {},
      reviews: Array.isArray(parsed.reviews) ? parsed.reviews : [],
      workflows:
        Array.isArray(parsed.workflows) && parsed.workflows.length > 0
          ? parsed.workflows
          : [DEFAULT_FEATURED_WORKFLOW],
      fleetExplicitSlots: explicitSlots,
      fleetVirtualBatches: Array.isArray(parsed.fleetVirtualBatches) ? parsed.fleetVirtualBatches : [],
      fleetNextSlotNumber:
        typeof parsed.fleetNextSlotNumber === 'number' && parsed.fleetNextSlotNumber >= 2
          ? parsed.fleetNextSlotNumber
          : Math.max(2, Object.keys(explicitSlots).length + 1),
      iosApps: parsed.iosApps || {},
      iosActiveLaunchMeta: parsed.iosActiveLaunchMeta || {},
    };
  } catch (err) {
    console.warn('[DB] Failed reading JSON DB, reinitializing safely:', err);
    const fresh = createEmptyDb();
    writeJsonDb(fresh);
    return fresh;
  }
}

function writeJsonDb(db: OmniAgentJsonDb): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmpPath = `${JSON_DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tmpPath, JSON_DB_PATH);
}

try {
  getSupabaseClient();
  readJsonDb();
} catch (err) {
  console.warn('[DB] Startup init notice:', err);
}

function logSupabaseNotice(context: string, error: any): void {
  if (!supabaseWarned) {
    supabaseWarned = true;
    console.warn(
      `[DB] Supabase ${context} notice (falling back gracefully to local JSON store if tables are unprovisioned):`,
      error?.message || error
    );
  }
}

async function syncUserToSupabase(user: DbUser): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_users').upsert({
      id: user.id,
      email: user.email,
      name: user.name,
      password_hash: user.passwordHash,
      salt: user.salt,
      referral_code: user.referralCode,
      referred_by: user.referredBy || null,
      created_at: user.createdAt,
    });
    if (error) logSupabaseNotice('omni_users', error);
  } catch (err) {
    logSupabaseNotice('omni_users', err);
  }
}

async function syncWalletToSupabase(wallet: DbWallet): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_wallets').upsert({
      user_id: wallet.userId,
      referral_code: wallet.referralCode,
      referred_by: wallet.referredBy || null,
      has_made_first_qualifying_purchase: wallet.hasMadeFirstQualifyingPurchase,
      referral_invites_count: wallet.referralInvitesCount,
      referral_conversions_count: wallet.referralConversionsCount,
      referral_tokens_earned: wallet.referralTokensEarned,
      app_token_balance: wallet.appTokenBalance,
      lifetime_tokens_used: wallet.lifetimeTokensUsed,
      lifetime_tokens_purchased: wallet.lifetimeTokensPurchased,
      last_topup_date: wallet.lastTopupDate || null,
      created_at: wallet.createdAt,
      updated_at: wallet.updatedAt,
    });
    if (error) logSupabaseNotice('omni_wallets', error);
  } catch (err) {
    logSupabaseNotice('omni_wallets', err);
  }
}

async function syncLedgerEntryToSupabase(entry: DbLedgerEntry): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_quota_ledger').upsert({
      id: entry.id,
      user_id: entry.userId,
      timestamp: entry.timestamp,
      type: entry.type,
      workflow_name: entry.workflowName,
      tokens_delta: entry.tokensDelta,
      balance_after: entry.balanceAfter,
      dollar_equivalent: entry.dollarEquivalent,
      reference: entry.reference || null,
      metadata: entry.metadata || {},
    });
    if (error) logSupabaseNotice('omni_quota_ledger', error);
  } catch (err) {
    logSupabaseNotice('omni_quota_ledger', err);
  }
}

async function syncSessionToSupabase(session: DbSession): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_sessions').upsert({
      token: session.token,
      user_id: session.userId,
      email: session.email,
      name: session.name,
      created_at: session.createdAt,
      expires_at: session.expiresAt,
    });
    if (error) logSupabaseNotice('omni_sessions', error);
  } catch {}
}

async function syncReviewToSupabase(review: DbReviewRecord): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_reviews').upsert({
      id: review.id,
      rating: review.rating,
      title: review.title || null,
      review_text: review.reviewText,
      author_name: review.authorName || null,
      author_email: review.authorEmail || null,
      category: review.category || null,
      submitted_at: review.submittedAt,
      destination_email: review.destinationEmail || null,
    });
    if (error) logSupabaseNotice('omni_reviews', error);
  } catch {}
}

async function syncWorkflowToSupabase(wf: DbWorkflowRecord): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    const { error } = await sb.from('omni_workflows').upsert({
      id: wf.id,
      slug: wf.slug,
      title: wf.title,
      description: wf.description,
      prompt: wf.prompt,
      target_app: wf.targetApp,
      author: wf.author,
      created_at: wf.createdAt,
      run_count: wf.runCount,
      clone_count: wf.cloneCount,
      estimated_tokens: wf.estimatedTokens,
      estimated_seconds: wf.estimatedSeconds,
      tags: wf.tags,
      is_featured: Boolean(wf.isFeatured),
    });
    if (error) logSupabaseNotice('omni_workflows', error);
  } catch {}
}

function generateReferralCode(db: OmniAgentJsonDb): string {
  for (let i = 0; i < 10; i++) {
    const code = 'OMNI-' + crypto.randomBytes(2).toString('hex').toUpperCase();
    if (!db.referrals[code]) return code;
  }
  return 'OMNI-' + Date.now().toString(36).slice(-4).toUpperCase();
}

function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const actualSalt = salt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, actualSalt, 64).toString('hex');
  return { hash: derived, salt: actualSalt };
}

function verifyPasswordHash(password: string, salt: string, expectedHash: string): boolean {
  const derived = crypto.scryptSync(password, salt, 64);
  const expectedBuf = Buffer.from(expectedHash, 'hex');
  if (derived.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(derived, expectedBuf);
}

function ensureWalletInDb(db: OmniAgentJsonDb, userId: string, referredByCode?: string): DbWallet {
  const existing = db.wallets[userId];
  if (existing) {
    if (!db.referrals[existing.referralCode]) {
      db.referrals[existing.referralCode] = {
        referralCode: existing.referralCode,
        ownerUserId: userId,
        invites: [],
        conversions: [],
        totalBonusTokens: existing.referralTokensEarned || 0,
      };
    }
    return existing;
  }

  const now = new Date().toISOString();
  const userRecord = db.users[userId];
  const referralCode = userRecord?.referralCode || generateReferralCode(db);
  const cleanReferredBy = referredByCode ? referredByCode.trim().toUpperCase() : userRecord?.referredBy;

  const newWallet: DbWallet = {
    userId,
    referralCode,
    referredBy: cleanReferredBy && cleanReferredBy !== referralCode ? cleanReferredBy : undefined,
    hasMadeFirstQualifyingPurchase: false,
    referralInvitesCount: 0,
    referralConversionsCount: 0,
    referralTokensEarned: 0,
    appTokenBalance: DEFAULT_INITIAL_BALANCE,
    lifetimeTokensUsed: 0,
    lifetimeTokensPurchased: 0,
    createdAt: now,
    updatedAt: now,
  };

  db.wallets[userId] = newWallet;
  db.referrals[referralCode] = db.referrals[referralCode] || {
    referralCode,
    ownerUserId: userId,
    invites: [],
    conversions: [],
    totalBonusTokens: 0,
  };

  db.ledger[userId] = [];

  if (newWallet.referredBy) {
    const refRecord = db.referrals[newWallet.referredBy] || {
      referralCode: newWallet.referredBy,
      invites: [],
      conversions: [],
      totalBonusTokens: 0,
    };
    if (!refRecord.invites.includes(userId)) {
      refRecord.invites.push(userId);
      if (refRecord.ownerUserId && db.wallets[refRecord.ownerUserId]) {
        db.wallets[refRecord.ownerUserId].referralInvitesCount += 1;
        db.wallets[refRecord.ownerUserId].updatedAt = now;
      }
    }
    db.referrals[newWallet.referredBy] = refRecord;
  }

  return newWallet;
}

export async function registerUserAccount(input: {
  email: string;
  password: string;
  name?: string;
  referralCode?: string;
}): Promise<{
  user: Omit<DbUser, 'passwordHash' | 'salt'>;
  token: string;
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const email = input.email.trim().toLowerCase();
    if (!email || !email.includes('@')) {
      throw new Error('A valid email address is required.');
    }
    if (!input.password || input.password.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }
    if (db.usersByEmail[email]) {
      throw new Error('An account with this email already exists. Please sign in instead.');
    }

    const now = new Date().toISOString();
    const userId = `usr_${crypto.randomBytes(8).toString('hex')}`;
    const referralCode = generateReferralCode(db);
    const { hash, salt } = hashPassword(input.password);
    const cleanReferredBy = input.referralCode?.trim().toUpperCase();

    const user: DbUser = {
      id: userId,
      email,
      name: (input.name || email.split('@')[0] || 'Agent Operator').trim(),
      passwordHash: hash,
      salt,
      referralCode,
      referredBy: cleanReferredBy && cleanReferredBy !== referralCode ? cleanReferredBy : undefined,
      createdAt: now,
    };

    db.users[userId] = user;
    db.usersByEmail[email] = userId;

    const wallet = ensureWalletInDb(db, userId, user.referredBy);
    const sessionToken = `omni_sess_${crypto.randomBytes(24).toString('hex')}`;
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    const session: DbSession = {
      token: sessionToken,
      userId,
      email: user.email,
      name: user.name,
      createdAt: now,
      expiresAt,
    };
    db.sessions[sessionToken] = session;

    writeJsonDb(db);
    await Promise.all([
      syncUserToSupabase(user),
      syncWalletToSupabase(wallet),
      syncSessionToSupabase(session),
      db.ledger[userId]?.[0] ? syncLedgerEntryToSupabase(db.ledger[userId][0]) : Promise.resolve(),
    ]);

    const { passwordHash: _ph, salt: _s, ...publicUser } = user;
    return {
      user: publicUser,
      token: sessionToken,
      wallet,
      ledger: db.ledger[userId] || [],
    };
  });
}

export async function authenticateUserAccount(input: {
  email: string;
  password: string;
}): Promise<{
  user: Omit<DbUser, 'passwordHash' | 'salt'>;
  token: string;
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const email = input.email.trim().toLowerCase();
    const userId = db.usersByEmail[email];
    const user = userId ? db.users[userId] : undefined;

    if (!user || !verifyPasswordHash(input.password || '', user.salt, user.passwordHash)) {
      throw new Error('Invalid email or password.');
    }

    const wallet = ensureWalletInDb(db, user.id);
    const now = new Date().toISOString();
    const sessionToken = `omni_sess_${crypto.randomBytes(24).toString('hex')}`;
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    const session: DbSession = {
      token: sessionToken,
      userId: user.id,
      email: user.email,
      name: user.name,
      createdAt: now,
      expiresAt,
    };
    db.sessions[sessionToken] = session;

    writeJsonDb(db);
    await Promise.all([syncWalletToSupabase(wallet), syncSessionToSupabase(session)]);

    const { passwordHash: _ph, salt: _s, ...publicUser } = user;
    return {
      user: publicUser,
      token: sessionToken,
      wallet,
      ledger: db.ledger[user.id] || [],
    };
  });
}

export async function getSessionContext(token?: string | null): Promise<{
  authenticated: boolean;
  user?: Omit<DbUser, 'passwordHash' | 'salt'>;
}> {
  if (!token) return { authenticated: false };
  const sb = getSupabaseClient();
  if (sb) {
    try {
      const { data: sbSession } = await sb
        .from('omni_sessions')
        .select('*')
        .eq('token', token)
        .maybeSingle();
      if (sbSession && new Date(sbSession.expires_at).getTime() >= Date.now()) {
        const { data: sbUser } = await sb
          .from('omni_users')
          .select('id,email,name,referral_code,referred_by,created_at')
          .eq('id', sbSession.user_id)
          .maybeSingle();
        if (sbUser) {
          return {
            authenticated: true,
            user: {
              id: sbUser.id,
              email: sbUser.email,
              name: sbUser.name,
              referralCode: sbUser.referral_code,
              referredBy: sbUser.referred_by || undefined,
              createdAt: sbUser.created_at,
            },
          };
        }
      }
    } catch {}
  }

  const db = readJsonDb();
  const sess = db.sessions[token];
  if (!sess) return { authenticated: false };
  if (new Date(sess.expiresAt).getTime() < Date.now()) {
    await withDbLock(async () => {
      const latest = readJsonDb();
      delete latest.sessions[token];
      writeJsonDb(latest);
    });
    return { authenticated: false };
  }
  const user = db.users[sess.userId];
  if (!user) return { authenticated: false };
  const { passwordHash: _ph, salt: _s, ...publicUser } = user;
  return { authenticated: true, user: publicUser };
}

export interface VerifiedSupabaseUserInfo {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  provider?: string;
  emailConfirmedAt?: string | null;
  referredBy?: string;
  createdAt: string;
}

export async function verifySupabaseAccessToken(token?: string | null): Promise<{
  configured: boolean;
  valid: boolean;
  verified: boolean;
  user?: VerifiedSupabaseUserInfo;
  error?: string;
}> {
  const cleanToken = (token || '').trim();
  if (!cleanToken) {
    return {
      configured: Boolean(getSupabaseAuthVerifierClient()),
      valid: false,
      verified: false,
      error: 'Missing Bearer access token.',
    };
  }

  const sb = getSupabaseAuthVerifierClient();
  if (!sb) {
    return {
      configured: false,
      valid: false,
      verified: false,
      error: 'Supabase authentication is not configured on the server (set SUPABASE_URL & VITE_SUPABASE_ANON_KEY or SUPABASE_SERVICE_ROLE_KEY).',
    };
  }

  try {
    const { data, error } = await sb.auth.getUser(cleanToken);
    if (error || !data?.user) {
      return {
        configured: true,
        valid: false,
        verified: false,
        error: error?.message || 'Invalid or expired Supabase access token.',
      };
    }

    const u = data.user;
    const emailConfirmedAt = u.email_confirmed_at || u.confirmed_at || null;
    const isVerified = Boolean(u.email_confirmed_at);
    const meta = u.user_metadata || {};
    const appMeta = u.app_metadata || {};
    const email = u.email || '';

    return {
      configured: true,
      valid: true,
      verified: isVerified,
      user: {
        id: u.id,
        email,
        name: String(
          meta.full_name ||
            meta.name ||
            meta.user_name ||
            meta.preferred_username ||
            (email ? email.split('@')[0] : 'Verified Operator')
        ),
        avatarUrl:
          typeof meta.avatar_url === 'string' && meta.avatar_url
            ? meta.avatar_url
            : typeof meta.picture === 'string' && meta.picture
            ? meta.picture
            : undefined,
        provider:
          typeof appMeta.provider === 'string' && appMeta.provider
            ? appMeta.provider
            : Array.isArray(appMeta.providers) && appMeta.providers[0]
            ? String(appMeta.providers[0])
            : 'email',
        emailConfirmedAt,
        referredBy: typeof meta.referral_code === 'string' ? meta.referral_code : undefined,
        createdAt: u.created_at || new Date().toISOString(),
      },
      error: isVerified ? undefined : 'Email address has not been verified yet.',
    };
  } catch (err: any) {
    return {
      configured: true,
      valid: false,
      verified: false,
      error: err?.message || 'Failed verifying Supabase session token.',
    };
  }
}

export async function ensureSupabaseUserWallet(supaUser: VerifiedSupabaseUserInfo): Promise<{
  user: Omit<DbUser, 'passwordHash' | 'salt'> & {
    emailConfirmedAt?: string | null;
    isVerified: boolean;
    avatarUrl?: string;
    provider?: string;
  };
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    let userRecord = db.users[supaUser.id];
    const cleanEmail = (supaUser.email || '').trim().toLowerCase();
    let userChanged = false;

    if (!userRecord) {
      const referralCode = generateReferralCode(db);
      const cleanRefBy = supaUser.referredBy?.trim().toUpperCase();
      userRecord = {
        id: supaUser.id,
        email: cleanEmail || `${supaUser.id}@oauth.local`,
        name: supaUser.name || 'Verified Operator',
        passwordHash: '',
        salt: '',
        referralCode,
        referredBy: cleanRefBy && cleanRefBy !== referralCode ? cleanRefBy : undefined,
        createdAt: supaUser.createdAt || new Date().toISOString(),
      };
      db.users[supaUser.id] = userRecord;
      if (cleanEmail) {
        db.usersByEmail[cleanEmail] = supaUser.id;
      }
      userChanged = true;
    } else if (
      (supaUser.name && userRecord.name !== supaUser.name) ||
      (cleanEmail && userRecord.email !== cleanEmail)
    ) {
      userRecord.name = supaUser.name || userRecord.name;
      if (cleanEmail) userRecord.email = cleanEmail;
      db.users[supaUser.id] = userRecord;
      userChanged = true;
    }

    const walletExisted = Boolean(db.wallets[supaUser.id]);
    const wallet = ensureWalletInDb(db, supaUser.id, userRecord.referredBy);

    if (userChanged || !walletExisted) {
      writeJsonDb(db);
      const syncTasks: Promise<unknown>[] = [syncWalletToSupabase(wallet)];
      if (userChanged) syncTasks.push(syncUserToSupabase(userRecord));
      if (!walletExisted && db.ledger[supaUser.id]?.[0]) {
        syncTasks.push(syncLedgerEntryToSupabase(db.ledger[supaUser.id][0]));
      }
      await Promise.all(syncTasks);
    }

    const { passwordHash: _ph, salt: _s, ...publicUser } = userRecord;
    return {
      user: {
        ...publicUser,
        emailConfirmedAt: supaUser.emailConfirmedAt,
        isVerified: Boolean(supaUser.emailConfirmedAt),
        avatarUrl: supaUser.avatarUrl,
        provider: supaUser.provider,
      },
      wallet,
      ledger: (db.ledger[supaUser.id] || []).slice(-150),
    };
  });
}

export async function revokeSession(token?: string | null): Promise<void> {
  if (!token) return;
  const sb = getSupabaseClient();
  if (sb) {
    try {
      await sb.from('omni_sessions').delete().eq('token', token);
    } catch {}
  }
  await withDbLock(async () => {
    const db = readJsonDb();
    if (db.sessions[token]) {
      delete db.sessions[token];
      writeJsonDb(db);
    }
  });
}

export async function getWalletAndLedger(userId: string): Promise<{
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const existed = Boolean(db.wallets[userId]);
    const wallet = ensureWalletInDb(db, userId);
    if (!existed) {
      writeJsonDb(db);
      await syncWalletToSupabase(wallet);
      if (db.ledger[userId]?.[0]) {
        await syncLedgerEntryToSupabase(db.ledger[userId][0]);
      }
    }
    return {
      wallet,
      ledger: (db.ledger[userId] || []).slice(-150),
    };
  });
}

export async function preflightQuotaCheck(
  userId: string,
  _prompt: string,
  estimatedBuffer: number = PROMPT_PLANNING_TOKEN_COST,
  exactRequiredTokens?: number
): Promise<{
  allowed: boolean;
  estimatedTokens: number;
  currentBalance: number;
  shortageTokens: number;
  shortageUsd: number;
  wallet: DbWallet;
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const existed = Boolean(db.wallets[userId]);
    const wallet = ensureWalletInDb(db, userId);
    if (!existed) {
      writeJsonDb(db);
    }

    const requiredTokens =
      typeof exactRequiredTokens === 'number' && exactRequiredTokens > 0
        ? Math.round(exactRequiredTokens)
        : Math.max(1, Math.round(estimatedBuffer || PROMPT_PLANNING_TOKEN_COST));
    const allowed = wallet.appTokenBalance >= requiredTokens && wallet.appTokenBalance > 0;
    const shortageTokens = allowed ? 0 : Math.max(0, requiredTokens - wallet.appTokenBalance);

    return {
      allowed,
      estimatedTokens: requiredTokens,
      currentBalance: wallet.appTokenBalance,
      shortageTokens,
      shortageUsd: Number((shortageTokens / SERVER_TOKENS_PER_DOLLAR).toFixed(4)),
      wallet,
    };
  });
}

export async function deductQuotaFromDb(input: {
  userId: string;
  workflowName?: string;
  tokenCount: number;
  promptSnippet?: string;
  stepsCount?: number;
  requireFullAmount?: boolean;
}): Promise<{
  success: boolean;
  allowed: boolean;
  tokensDeducted: number;
  remainingBalance: number;
  dollarDeducted: number;
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const wallet = ensureWalletInDb(db, input.userId);
    const requestedTokens = Math.max(1, Math.round(Number(input.tokenCount) || EXECUTION_STEP_TOKEN_COST));

    if (
      wallet.appTokenBalance <= 0 ||
      (input.requireFullAmount && wallet.appTokenBalance < requestedTokens)
    ) {
      return {
        success: false,
        allowed: false,
        tokensDeducted: 0,
        remainingBalance: wallet.appTokenBalance,
        dollarDeducted: 0,
        wallet,
        ledger: (db.ledger[input.userId] || []).slice(-150),
      };
    }

    const actualDeducted = Math.min(wallet.appTokenBalance, requestedTokens);
    const now = new Date().toISOString();
    wallet.appTokenBalance = Math.max(0, wallet.appTokenBalance - actualDeducted);
    wallet.lifetimeTokensUsed += actualDeducted;
    wallet.updatedAt = now;
    db.wallets[input.userId] = wallet;

    const dollarEquivalent = Number((actualDeducted / SERVER_TOKENS_PER_DOLLAR).toFixed(4));
    const entry: DbLedgerEntry = {
      id: `run-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      userId: input.userId,
      timestamp: now,
      type: 'AUTOMATION_RUN',
      workflowName: input.workflowName || 'Phone Automation Task',
      tokensDelta: -actualDeducted,
      balanceAfter: wallet.appTokenBalance,
      dollarEquivalent,
      reference: `steps:${input.stepsCount || 1}`,
      metadata: {
        promptSnippet: input.promptSnippet ? input.promptSnippet.slice(0, 70) : undefined,
        stepsCount: input.stepsCount,
        provider: 'OmniAgent Server Quota Ledger',
      },
    };

    const existingLedger = db.ledger[input.userId] || [];
    db.ledger[input.userId] = [...existingLedger, entry].slice(-150);

    writeJsonDb(db);
    await Promise.all([syncWalletToSupabase(wallet), syncLedgerEntryToSupabase(entry)]);

    return {
      success: true,
      allowed: true,
      tokensDeducted: actualDeducted,
      remainingBalance: wallet.appTokenBalance,
      dollarDeducted: dollarEquivalent,
      wallet,
      ledger: db.ledger[input.userId],
    };
  });
}

function findReferrerWalletId(db: OmniAgentJsonDb, referrerCode: string): string | null {
  const normalized = referrerCode.trim().toUpperCase();
  const refRecord = db.referrals[normalized];
  if (refRecord?.ownerUserId && db.wallets[refRecord.ownerUserId]) {
    return refRecord.ownerUserId;
  }
  for (const w of Object.values(db.wallets)) {
    if (w.referralCode.toUpperCase() === normalized) {
      return w.userId;
    }
  }
  return null;
}

export async function creditQuotaInDb(input: {
  userId: string;
  amountInDollars: number;
  paymentReference?: string;
  packageName?: string;
  provider?: string;
}): Promise<{
  success: boolean;
  deduplicated?: boolean;
  tokensAdded: number;
  newBalance: number;
  newDollarValue: number;
  referralBonusTriggered: boolean;
  wallet: DbWallet;
  ledger: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const maybeEmail = input.userId.trim().toLowerCase();
    const resolvedUserId =
      maybeEmail.includes('@') && db.usersByEmail[maybeEmail]
        ? db.usersByEmail[maybeEmail]
        : input.userId;

    const wallet = ensureWalletInDb(db, resolvedUserId);

    if (input.paymentReference && db.processedPaymentRefs[input.paymentReference]) {
      return {
        success: true,
        deduplicated: true,
        tokensAdded: 0,
        newBalance: wallet.appTokenBalance,
        newDollarValue: Number((wallet.appTokenBalance / SERVER_TOKENS_PER_DOLLAR).toFixed(4)),
        referralBonusTriggered: false,
        wallet,
        ledger: (db.ledger[resolvedUserId] || []).slice(-150),
      };
    }

    const dollars = Number(input.amountInDollars);
    const tokensToAdd = Math.round(dollars * SERVER_TOKENS_PER_DOLLAR);
    const now = new Date().toISOString();

    wallet.appTokenBalance += tokensToAdd;
    wallet.lifetimeTokensPurchased += tokensToAdd;
    wallet.lastTopupDate = now;
    wallet.updatedAt = now;

    let referralBonusTriggered = false;
    if (!wallet.hasMadeFirstQualifyingPurchase && dollars >= REFERRAL_QUALIFYING_PURCHASE_USD) {
      wallet.hasMadeFirstQualifyingPurchase = true;
      referralBonusTriggered = true;

      if (wallet.referredBy) {
        const refCode = wallet.referredBy.toUpperCase();
        const refRecord = db.referrals[refCode] || {
          referralCode: refCode,
          invites: [resolvedUserId],
          conversions: [],
          totalBonusTokens: 0,
        };

        const alreadyConverted = refRecord.conversions.some((c) => c.friendId === resolvedUserId);
        if (!alreadyConverted) {
          refRecord.conversions.push({
            friendId: resolvedUserId,
            timestamp: now,
            tokensAwarded: SERVER_REFERRAL_BONUS_TOKENS,
          });
          refRecord.totalBonusTokens += SERVER_REFERRAL_BONUS_TOKENS;
          db.referrals[refCode] = refRecord;

          const ownerId = findReferrerWalletId(db, refCode);
          if (ownerId && ownerId !== resolvedUserId) {
            const ownerWallet = ensureWalletInDb(db, ownerId);
            ownerWallet.appTokenBalance += SERVER_REFERRAL_BONUS_TOKENS;
            ownerWallet.referralConversionsCount += 1;
            ownerWallet.referralTokensEarned += SERVER_REFERRAL_BONUS_TOKENS;
            ownerWallet.updatedAt = now;
            db.wallets[ownerId] = ownerWallet;

            const bonusEntry: DbLedgerEntry = {
              id: `ref-bonus-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
              userId: ownerId,
              timestamp: now,
              type: 'REFERRAL_BONUS',
              workflowName: `5M Token Referral Reward (Friend Bought $${dollars.toFixed(0)} Pack)`,
              tokensDelta: SERVER_REFERRAL_BONUS_TOKENS,
              balanceAfter: ownerWallet.appTokenBalance,
              dollarEquivalent: Number((SERVER_REFERRAL_BONUS_TOKENS / SERVER_TOKENS_PER_DOLLAR).toFixed(4)),
              metadata: {
                provider: 'OmniAgent Referral Program',
                referredUser: resolvedUserId,
                referralCode: refCode,
              },
            };
            db.ledger[ownerId] = [...(db.ledger[ownerId] || []), bonusEntry].slice(-150);
            await syncWalletToSupabase(ownerWallet);
            await syncLedgerEntryToSupabase(bonusEntry);
          }
        }
      }
    }

    db.wallets[resolvedUserId] = wallet;
    if (input.paymentReference) {
      db.processedPaymentRefs[input.paymentReference] = now;
    }

    const entry: DbLedgerEntry = {
      id: `topup-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      userId: resolvedUserId,
      timestamp: now,
      type: 'TOPUP',
      workflowName: input.packageName || `Top-up ($${dollars.toFixed(2)})`,
      tokensDelta: tokensToAdd,
      balanceAfter: wallet.appTokenBalance,
      dollarEquivalent: dollars,
      amountInDollars: dollars,
      reference: input.paymentReference,
      metadata: {
        paymentReference: input.paymentReference,
        provider: input.provider || 'Secure Token Checkout',
        referralCode: wallet.referredBy,
      },
    };
    db.ledger[resolvedUserId] = [...(db.ledger[resolvedUserId] || []), entry].slice(-150);

    writeJsonDb(db);
    await Promise.all([syncWalletToSupabase(wallet), syncLedgerEntryToSupabase(entry)]);

    return {
      success: true,
      tokensAdded: tokensToAdd,
      newBalance: wallet.appTokenBalance,
      newDollarValue: Number((wallet.appTokenBalance / SERVER_TOKENS_PER_DOLLAR).toFixed(4)),
      referralBonusTriggered,
      wallet,
      ledger: db.ledger[resolvedUserId],
    };
  });
}

export async function recordReferralVisitInDb(
  referralCode: string,
  friendUserId: string
): Promise<{ success: boolean; referralCode: string; totalInvites: number }> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const code = referralCode.trim().toUpperCase();
    const existing: DbReferralRecord = db.referrals[code] || {
      referralCode: code,
      invites: [],
      conversions: [],
      totalBonusTokens: 0,
    };

    if (!existing.invites.includes(friendUserId)) {
      existing.invites.push(friendUserId);
      const ownerId = findReferrerWalletId(db, code);
      if (ownerId && db.wallets[ownerId]) {
        db.wallets[ownerId].referralInvitesCount += 1;
        db.wallets[ownerId].updatedAt = new Date().toISOString();
      }
    }
    db.referrals[code] = existing;

    if (
      db.wallets[friendUserId] &&
      !db.wallets[friendUserId].referredBy &&
      db.wallets[friendUserId].referralCode !== code
    ) {
      db.wallets[friendUserId].referredBy = code;
      db.wallets[friendUserId].updatedAt = new Date().toISOString();
    }

    writeJsonDb(db);
    return {
      success: true,
      referralCode: code,
      totalInvites: existing.invites.length,
    };
  });
}

export async function rewardReferralInDb(input: {
  referrerCode?: string;
  targetUserId?: string;
  friendUserId: string;
  qualifyingAmountUsd?: number;
}): Promise<{
  success: boolean;
  referralCode: string;
  bonusAwarded: number;
  totalBonusEarned: number;
  conversionsCount: number;
  wallet?: DbWallet;
  ledger?: DbLedgerEntry[];
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const walletByUser = input.targetUserId ? ensureWalletInDb(db, input.targetUserId) : undefined;
    const code = (input.referrerCode || walletByUser?.referralCode || 'OMNI-DIRECT')
      .trim()
      .toUpperCase();
    const friend = input.friendUserId || 'Anonymous Friend';
    const existing: DbReferralRecord = db.referrals[code] || {
      referralCode: code,
      ownerUserId: walletByUser?.userId,
      invites: [friend],
      conversions: [],
      totalBonusTokens: 0,
    };

    const alreadyConverted = existing.conversions.some((c) => c.friendId === friend);
    let updatedOwnerWallet: DbWallet | undefined = walletByUser;
    let updatedLedger: DbLedgerEntry[] | undefined;

    if (!alreadyConverted) {
      const now = new Date().toISOString();
      existing.conversions.push({
        friendId: friend,
        timestamp: now,
        tokensAwarded: SERVER_REFERRAL_BONUS_TOKENS,
      });
      existing.totalBonusTokens += SERVER_REFERRAL_BONUS_TOKENS;
      db.referrals[code] = existing;

      const ownerId = findReferrerWalletId(db, code) || input.targetUserId;
      if (ownerId) {
        const ownerWallet = ensureWalletInDb(db, ownerId);
        ownerWallet.appTokenBalance += SERVER_REFERRAL_BONUS_TOKENS;
        ownerWallet.referralConversionsCount += 1;
        ownerWallet.referralTokensEarned += SERVER_REFERRAL_BONUS_TOKENS;
        ownerWallet.updatedAt = now;
        db.wallets[ownerId] = ownerWallet;
        updatedOwnerWallet = ownerWallet;

        const entry: DbLedgerEntry = {
          id: `ref-bonus-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
          userId: ownerId,
          timestamp: now,
          type: 'REFERRAL_BONUS',
          workflowName: `5M Token Referral Reward (Friend: ${friend})`,
          tokensDelta: SERVER_REFERRAL_BONUS_TOKENS,
          balanceAfter: ownerWallet.appTokenBalance,
          dollarEquivalent: Number((SERVER_REFERRAL_BONUS_TOKENS / SERVER_TOKENS_PER_DOLLAR).toFixed(4)),
          reference: `friend:${friend},qualifyingUsd:${input.qualifyingAmountUsd || 8}`,
          metadata: {
            provider: 'OmniAgent Referral Program',
            referredUser: friend,
            referralCode: code,
          },
        };
        db.ledger[ownerId] = [...(db.ledger[ownerId] || []), entry].slice(-150);
        updatedLedger = db.ledger[ownerId];
        await syncWalletToSupabase(ownerWallet);
        await syncLedgerEntryToSupabase(entry);
      }
      writeJsonDb(db);
    }

    return {
      success: true,
      referralCode: code,
      bonusAwarded: SERVER_REFERRAL_BONUS_TOKENS,
      totalBonusEarned: existing.totalBonusTokens,
      conversionsCount: existing.conversions.length,
      wallet: updatedOwnerWallet,
      ledger: updatedLedger,
    };
  });
}

export function getReferralStatsFromDb(code: string): DbReferralRecord {
  const db = readJsonDb();
  const upper = code.trim().toUpperCase();
  return (
    db.referrals[upper] || {
      referralCode: upper,
      invites: [],
      conversions: [],
      totalBonusTokens: 0,
    }
  );
}

export async function addReviewToDb(review: DbReviewRecord): Promise<DbReviewRecord> {
  return withDbLock(async () => {
    const db = readJsonDb();
    db.reviews.push(review);
    writeJsonDb(db);
    await syncReviewToSupabase(review);
    return review;
  });
}

export function getReviewsFromDb(): DbReviewRecord[] {
  const db = readJsonDb();
  return db.reviews;
}

export function getWorkflowsFromDb(): DbWorkflowRecord[] {
  const db = readJsonDb();
  return db.workflows;
}

export async function upsertWorkflowInDb(wf: DbWorkflowRecord): Promise<DbWorkflowRecord> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const idx = db.workflows.findIndex((w) => w.id === wf.id || w.slug === wf.slug);
    if (idx >= 0) {
      db.workflows[idx] = { ...db.workflows[idx], ...wf };
    } else {
      db.workflows.unshift(wf);
    }
    writeJsonDb(db);
    await syncWorkflowToSupabase(wf);
    return wf;
  });
}

// ===============================================================================================
// STATELESS CLOUD FLEET PERSISTENCE (Supports 100,000+ Concurrent Cloud Slots with Pagination)
// ===============================================================================================
function resolveWorkerNodeForSlot(slotNumber: number): string {
  const shard = ((slotNumber - 1) % 32) + 1;
  return `worker-edge-${String(shard).padStart(2, '0')}`;
}

function resolveStreamUrlForSlot(slotId: string, platform: FleetSlotPlatform): string | undefined {
  const wsBase = (process.env.STREAM_WS_BASE_URL || '').trim().replace(/\/+$/, '');
  if (wsBase) {
    return `${wsBase}/stream/${encodeURIComponent(slotId)}?platform=${platform}`;
  }
  const webrtcBase = (process.env.WEBRTC_SIGNALING_URL || '').trim().replace(/\/+$/, '');
  if (webrtcBase) {
    return `${webrtcBase}/whep/${encodeURIComponent(slotId)}`;
  }
  return undefined;
}

function materializeVirtualBatchSlot(batch: FleetVirtualBatch, offset: number): DbFleetSlot {
  const slotNumber = batch.startSlotNumber + offset;
  const id = `slot-fleet-${slotNumber}`;
  const streamUrl = resolveStreamUrlForSlot(id, batch.platform);
  return {
    id,
    slotNumber,
    title: `Cloud Agent #${slotNumber.toLocaleString()}`,
    status: batch.status,
    platform: batch.platform,
    region: batch.region,
    workerNode: resolveWorkerNodeForSlot(slotNumber),
    streamUrl,
    currentApp: batch.platform === 'ios' ? 'chrome' : 'home',
    currentTaskSummary: batch.taskSummary || 'Standby for prompt dispatch',
    stepProgress: { current: batch.status === 'running' ? 2 : 1, total: 5 },
    memoryUsageMb: Number((38 + (slotNumber % 14) * 0.7).toFixed(1)),
    createdAt: batch.createdAt,
    updatedAt: batch.createdAt,
  };
}

export interface FleetStatusPageResult {
  slots: DbFleetSlot[];
  totalCount: number;
  runningCount: number;
  idleCount: number;
  hydratingCount: number;
  totalMemoryMb: number;
  page: number;
  limit: number;
  totalPages: number;
  storageMode: 'supabase' | 'json_file';
}

export function getFleetSummaryFromDb(): {
  totalCount: number;
  runningCount: number;
  hydratingCount: number;
  totalMemoryMb: number;
} {
  const db = readJsonDb();
  const explicitList = Object.values(db.fleetExplicitSlots);
  const explicitIds = new Set(explicitList.map((s) => s.id));

  let totalCount = explicitList.length;
  let runningCount = explicitList.filter((s) => s.status === 'running').length;
  let hydratingCount = explicitList.filter((s) => s.status === 'hydrating').length;
  let totalMemoryMb = explicitList.reduce((sum, s) => sum + (s.memoryUsageMb || 42), 0);

  for (const batch of db.fleetVirtualBatches) {
    // Subtract any slots already materialized in fleetExplicitSlots
    let overriddenInBatch = 0;
    for (const s of explicitList) {
      if (
        s.slotNumber >= batch.startSlotNumber &&
        s.slotNumber < batch.startSlotNumber + batch.count &&
        explicitIds.has(s.id)
      ) {
        overriddenInBatch += 1;
      }
    }
    const effectiveBatchCount = Math.max(0, batch.count - overriddenInBatch);
    totalCount += effectiveBatchCount;
    if (batch.status === 'running') runningCount += effectiveBatchCount;
    if (batch.status === 'hydrating') hydratingCount += effectiveBatchCount;
    totalMemoryMb += effectiveBatchCount * 42.4;
  }

  return {
    totalCount,
    runningCount,
    hydratingCount,
    totalMemoryMb: Number(totalMemoryMb.toFixed(1)),
  };
}

export async function getFleetStatusPaginated(params: {
  page?: number;
  limit?: number;
  search?: string;
  statusFilter?: string;
}): Promise<FleetStatusPageResult> {
  const page = Math.max(1, Math.round(Number(params.page) || 1));
  const limit = Math.min(100, Math.max(1, Math.round(Number(params.limit) || 50)));
  const search = (params.search || '').trim().toLowerCase();
  const statusFilter = (params.statusFilter || 'all').trim().toLowerCase();

  // Primary stateless query path when Supabase omni_fleet_slots is populated and no virtual-only offset needed
  const sb = getSupabaseClient();
  if (sb) {
    try {
      const from = (page - 1) * limit;
      const to = from + limit - 1;
      let q = sb
        .from('omni_fleet_slots')
        .select('*', { count: 'exact' })
        .order('slot_number', { ascending: true })
        .range(from, to);

      if (statusFilter && statusFilter !== 'all') {
        q = q.eq('status', statusFilter);
      }
      if (search) {
        q = q.or(`title.ilike.%${search}%,current_task_summary.ilike.%${search}%,id.ilike.%${search}%`);
      }

      const { data, count, error } = await q;
      if (!error && data && typeof count === 'number' && count > 0) {
        const mapped: DbFleetSlot[] = data.map((row: any) => ({
          id: row.id,
          slotNumber: row.slot_number,
          title: row.title,
          status: row.status,
          platform: row.platform || 'android',
          region: row.region || 'us-east-1',
          workerNode: row.worker_node || resolveWorkerNodeForSlot(row.slot_number),
          streamUrl: row.stream_url || undefined,
          webrtcUrl: row.webrtc_url || undefined,
          currentApp: row.current_app || 'home',
          currentTaskSummary: row.current_task_summary || 'Ready for instructions',
          stepProgress: row.step_progress || { current: 1, total: 1 },
          memoryUsageMb: Number(row.memory_usage_mb || 42.4),
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
        return {
          slots: mapped,
          totalCount: count,
          runningCount: mapped.filter((s) => s.status === 'running').length,
          idleCount: mapped.filter((s) => s.status === 'idle').length,
          hydratingCount: mapped.filter((s) => s.status === 'hydrating').length,
          totalMemoryMb: Number((count * 42.4).toFixed(1)),
          page,
          limit,
          totalPages: Math.max(1, Math.ceil(count / limit)),
          storageMode: 'supabase',
        };
      }
    } catch {}
  }

  const db = readJsonDb();
  const explicitByNum = new Map<number, DbFleetSlot>();
  for (const s of Object.values(db.fleetExplicitSlots)) {
    explicitByNum.set(s.slotNumber, s);
  }

  // Gather compact ordered ranges so pagination over 100,000+ slots is O(limit) without O(N) allocation
  const explicitSorted = Object.values(db.fleetExplicitSlots).sort(
    (a, b) => a.slotNumber - b.slotNumber
  );

  // If filtering with a search string or status, scan intelligently up to practical window
  const hasFilter = Boolean(search) || (statusFilter !== '' && statusFilter !== 'all');
  const startIdx = (page - 1) * limit;

  if (!hasFilter) {
    // Fast O(limit) exact window resolution across explicit slots + virtual batches
    const summary = getFleetSummaryFromDb();
    // Order: explicit slots whose slotNumber isn't inside any virtual batch, followed by batches in order
    const standaloneExplicit = explicitSorted.filter(
      (s) =>
        !db.fleetVirtualBatches.some(
          (b) => s.slotNumber >= b.startSlotNumber && s.slotNumber < b.startSlotNumber + b.count
        )
    );

    const results: DbFleetSlot[] = [];
    let cursor = startIdx;

    if (cursor < standaloneExplicit.length) {
      const take = Math.min(limit, standaloneExplicit.length - cursor);
      results.push(...standaloneExplicit.slice(cursor, cursor + take));
      cursor = 0;
    } else {
      cursor -= standaloneExplicit.length;
    }

    for (const batch of db.fleetVirtualBatches) {
      if (results.length >= limit) break;
      if (cursor >= batch.count) {
        cursor -= batch.count;
        continue;
      }
      const remainingNeeded = limit - results.length;
      const take = Math.min(remainingNeeded, batch.count - cursor);
      for (let i = 0; i < take; i++) {
        const slotNum = batch.startSlotNumber + cursor + i;
        const override = explicitByNum.get(slotNum);
        results.push(override || materializeVirtualBatchSlot(batch, cursor + i));
      }
      cursor = 0;
    }

    return {
      slots: results,
      totalCount: summary.totalCount,
      runningCount: summary.runningCount,
      idleCount: Math.max(0, summary.totalCount - summary.runningCount - summary.hydratingCount),
      hydratingCount: summary.hydratingCount,
      totalMemoryMb: summary.totalMemoryMb,
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(summary.totalCount / limit)),
      storageMode: getStorageMode(),
    };
  }

  // Filtered query mode
  const matches: DbFleetSlot[] = [];
  let runningCount = 0;
  let hydratingCount = 0;
  let totalMatches = 0;

  const matchesFilter = (slot: DbFleetSlot) => {
    if (statusFilter !== 'all' && slot.status !== statusFilter) return false;
    if (!search) return true;
    return (
      slot.id.toLowerCase().includes(search) ||
      slot.title.toLowerCase().includes(search) ||
      slot.currentTaskSummary.toLowerCase().includes(search) ||
      slot.region.toLowerCase().includes(search) ||
      slot.platform.toLowerCase().includes(search) ||
      `#${slot.slotNumber}`.includes(search)
    );
  };

  for (const s of explicitSorted) {
    if (
      !db.fleetVirtualBatches.some(
        (b) => s.slotNumber >= b.startSlotNumber && s.slotNumber < b.startSlotNumber + b.count
      )
    ) {
      if (matchesFilter(s)) {
        if (s.status === 'running') runningCount += 1;
        if (s.status === 'hydrating') hydratingCount += 1;
        if (totalMatches >= startIdx && matches.length < limit) {
          matches.push(s);
        }
        totalMatches += 1;
      }
    }
  }

  // Scan batches deterministically (handle large virtual batches smoothly if statusFilter matches)
  for (const batch of db.fleetVirtualBatches) {
    if (!search) {
      // Exact match check on batch status when no text search
      const effectiveStatusMatch = statusFilter === 'all' || batch.status === statusFilter;
      if (!effectiveStatusMatch) continue;
      if (totalMatches >= startIdx && matches.length < limit) {
        const offsetInBatch = Math.max(0, totalMatches - startIdx);
        const take = Math.min(limit - matches.length, batch.count);
        for (let i = 0; i < take; i++) {
          const slotNum = batch.startSlotNumber + i;
          matches.push(explicitByNum.get(slotNum) || materializeVirtualBatchSlot(batch, i));
        }
        void offsetInBatch;
      } else if (totalMatches + batch.count > startIdx && matches.length < limit) {
        const startInBatch = Math.max(0, startIdx - totalMatches);
        const take = Math.min(limit - matches.length, batch.count - startInBatch);
        for (let i = 0; i < take; i++) {
          const slotNum = batch.startSlotNumber + startInBatch + i;
          matches.push(
            explicitByNum.get(slotNum) || materializeVirtualBatchSlot(batch, startInBatch + i)
          );
        }
      }
      totalMatches += batch.count;
      if (batch.status === 'running') runningCount += batch.count;
      if (batch.status === 'hydrating') hydratingCount += batch.count;
    } else {
      // Check matching slotNumber shortcut e.g. search="5000"
      const numericSearch = parseInt(search.replace(/[^0-9]/g, ''), 10);
      if (!Number.isNaN(numericSearch) && search.replace(/[^0-9]/g, '') === String(numericSearch)) {
        if (
          numericSearch >= batch.startSlotNumber &&
          numericSearch < batch.startSlotNumber + batch.count
        ) {
          const slot =
            explicitByNum.get(numericSearch) ||
            materializeVirtualBatchSlot(batch, numericSearch - batch.startSlotNumber);
          if (matchesFilter(slot)) {
            if (totalMatches >= startIdx && matches.length < limit) matches.push(slot);
            totalMatches += 1;
          }
        }
      } else {
        // Sample / match batch-level fields cleanly up to full batch
        const sampleSlot = materializeVirtualBatchSlot(batch, 0);
        const batchLevelMatch =
          batch.region.toLowerCase().includes(search) ||
          batch.platform.toLowerCase().includes(search) ||
          batch.taskSummary.toLowerCase().includes(search) ||
          sampleSlot.title.toLowerCase().includes('cloud agent') && 'cloud agent'.includes(search);

        if (batchLevelMatch && (statusFilter === 'all' || batch.status === statusFilter)) {
          if (totalMatches + batch.count > startIdx && matches.length < limit) {
            const startInBatch = Math.max(0, startIdx - totalMatches);
            const take = Math.min(limit - matches.length, batch.count - startInBatch);
            for (let i = 0; i < take; i++) {
              const slotNum = batch.startSlotNumber + startInBatch + i;
              matches.push(
                explicitByNum.get(slotNum) || materializeVirtualBatchSlot(batch, startInBatch + i)
              );
            }
          }
          totalMatches += batch.count;
          if (batch.status === 'running') runningCount += batch.count;
          if (batch.status === 'hydrating') hydratingCount += batch.count;
        }
      }
    }
  }

  return {
    slots: matches,
    totalCount: totalMatches,
    runningCount,
    idleCount: Math.max(0, totalMatches - runningCount - hydratingCount),
    hydratingCount,
    totalMemoryMb: Number((totalMatches * 42.4).toFixed(1)),
    page,
    limit,
    totalPages: Math.max(1, Math.ceil(totalMatches / limit)),
    storageMode: getStorageMode(),
  };
}

export async function createSingleFleetSlotInDb(input: {
  id?: string;
  title?: string;
  platform?: FleetSlotPlatform;
  region?: string;
  currentTaskSummary?: string;
}): Promise<DbFleetSlot> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const slotNumber = db.fleetNextSlotNumber++;
    const id = input.id || `slot-${Date.now()}-${slotNumber}`;
    const now = new Date().toISOString();
    const platform = input.platform || 'android';
    const slot: DbFleetSlot = {
      id,
      slotNumber,
      title: input.title || `Prompt Slot #${slotNumber}: Autonomous Agent`,
      status: 'idle',
      platform,
      region: input.region || 'us-east-1',
      workerNode: resolveWorkerNodeForSlot(slotNumber),
      streamUrl: resolveStreamUrlForSlot(id, platform),
      currentApp: 'home',
      currentTaskSummary: input.currentTaskSummary || 'Ready for instructions',
      stepProgress: { current: 1, total: 1 },
      memoryUsageMb: Number((38 + Math.random() * 10).toFixed(1)),
      createdAt: now,
      updatedAt: now,
    };
    db.fleetExplicitSlots[id] = slot;
    writeJsonDb(db);

    const sb = getSupabaseClient();
    if (sb) {
      try {
        await sb.from('omni_fleet_slots').upsert({
          id: slot.id,
          slot_number: slot.slotNumber,
          title: slot.title,
          status: slot.status,
          platform: slot.platform,
          region: slot.region,
          worker_node: slot.workerNode,
          stream_url: slot.streamUrl || null,
          current_app: slot.currentApp,
          current_task_summary: slot.currentTaskSummary,
          step_progress: slot.stepProgress,
          memory_usage_mb: slot.memoryUsageMb,
          created_at: slot.createdAt,
          updated_at: slot.updatedAt,
        });
      } catch {}
    }

    return slot;
  });
}

export async function bulkSpawnFleetSlotsInDb(input: {
  count: number;
  platform?: FleetSlotPlatform;
  region?: string;
  taskSummary?: string;
  initialStatus?: FleetSlotStatus;
}): Promise<{
  batchId: string;
  startSlotNumber: number;
  spawnedCount: number;
  totalCount: number;
}> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const currentTotal = getFleetSummaryFromDb().totalCount;
    const allowedRemaining = Math.max(0, MAX_FLEET_VIRTUAL_SLOTS - currentTotal);
    const requested = Math.max(1, Math.min(100_000, Math.round(input.count || 1)));
    const count = Math.min(requested, allowedRemaining);
    if (count <= 0) {
      throw new Error(`Fleet capacity ceiling (${MAX_FLEET_VIRTUAL_SLOTS.toLocaleString()} slots) reached.`);
    }

    const batchId = `batch-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const startSlotNumber = db.fleetNextSlotNumber;
    const now = new Date().toISOString();
    const batch: FleetVirtualBatch = {
      id: batchId,
      startSlotNumber,
      count,
      platform: input.platform || 'android',
      region: input.region || 'us-east-1',
      taskSummary: input.taskSummary || 'Standby cloud container ready for dispatch',
      status: input.initialStatus || 'hydrating',
      createdAt: now,
    };

    db.fleetVirtualBatches.push(batch);
    db.fleetNextSlotNumber += count;
    writeJsonDb(db);

    const summary = getFleetSummaryFromDb();
    return {
      batchId,
      startSlotNumber,
      spawnedCount: count,
      totalCount: summary.totalCount,
    };
  });
}

export async function completeFleetBatchHydrationInDb(
  batchId: string,
  nextStatus: FleetSlotStatus = 'idle'
): Promise<boolean> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const batch = db.fleetVirtualBatches.find((b) => b.id === batchId);
    if (!batch) return false;
    batch.status = nextStatus;
    writeJsonDb(db);
    return true;
  });
}

export async function updateFleetSlotInDb(
  slotId: string,
  patch: Partial<DbFleetSlot>
): Promise<DbFleetSlot | null> {
  return withDbLock(async () => {
    const db = readJsonDb();
    const now = new Date().toISOString();
    let existing = db.fleetExplicitSlots[slotId];

    // If slot belongs to a virtual batch, materialize override seamlessly
    if (!existing && slotId.startsWith('slot-fleet-')) {
      const slotNum = parseInt(slotId.replace('slot-fleet-', ''), 10);
      const batch = db.fleetVirtualBatches.find(
        (b) => slotNum >= b.startSlotNumber && slotNum < b.startSlotNumber + b.count
      );
      if (batch) {
        existing = materializeVirtualBatchSlot(batch, slotNum - batch.startSlotNumber);
      }
    }

    if (!existing) return null;

    const updated: DbFleetSlot = {
      ...existing,
      ...patch,
      id: existing.id,
      slotNumber: existing.slotNumber,
      updatedAt: now,
    };
    db.fleetExplicitSlots[slotId] = updated;
    writeJsonDb(db);
    return updated;
  });
}

export async function deleteFleetSlotInDb(slotId: string): Promise<boolean> {
  return withDbLock(async () => {
    const db = readJsonDb();
    if (db.fleetExplicitSlots[slotId]) {
      delete db.fleetExplicitSlots[slotId];
      writeJsonDb(db);
      return true;
    }
    return false;
  });
}

// ===============================================================================================
// STATELESS iOS REGISTRY STORE (Migrated out of server.ts in-memory Map)
// ===============================================================================================
export async function upsertIosAppInDb(entry: IosRegisteredAppRecord): Promise<IosRegisteredAppRecord> {
  return withDbLock(async () => {
    const db = readJsonDb();
    db.iosApps[entry.bundleId] = entry;
    writeJsonDb(db);
    return entry;
  });
}

export function getIosAppFromDb(bundleId: string): IosRegisteredAppRecord | undefined {
  const db = readJsonDb();
  return db.iosApps[bundleId];
}

export function getIosAppCountFromDb(): number {
  const db = readJsonDb();
  return Object.keys(db.iosApps).length;
}

export function getIosActiveMetaFromDb(): { bundleId?: string; appName?: string; launchUrl?: string } {
  const db = readJsonDb();
  return db.iosActiveLaunchMeta || {};
}

export async function setIosActiveMetaInDb(meta: {
  bundleId?: string;
  appName?: string;
  launchUrl?: string;
}): Promise<void> {
  return withDbLock(async () => {
    const db = readJsonDb();
    db.iosActiveLaunchMeta = meta;
    writeJsonDb(db);
  });
}

// ===============================================================================================
// API KEY ROTATORS (Round-Robin Multi-Key Support with Quota Failover)
// ===============================================================================================
let geminiKeyIndex = 0;
let openRouterKeyIndex = 0;

export function getGeminiKeyPool(): string[] {
  const combined = [
    ...(process.env.GEMINI_API_KEYS || '').split(','),
    process.env.GEMINI_API_KEY || '',
  ]
    .map((k) => k.trim())
    .filter((k) => k.length > 0 && k !== 'MY_GEMINI_API_KEY');
  return Array.from(new Set(combined));
}

export function getNextGeminiKey(offset: number = 0): string | null {
  const pool = getGeminiKeyPool();
  if (pool.length === 0) return null;
  const idx = (geminiKeyIndex + offset) % pool.length;
  if (offset === 0) {
    geminiKeyIndex = (geminiKeyIndex + 1) % pool.length;
  }
  return pool[idx];
}

export function getOpenRouterKeyPool(requestOverride?: string): string[] {
  const combined = [
    ...(requestOverride ? [requestOverride] : []),
    ...(process.env.OPENROUTER_API_KEYS || '').split(','),
    process.env.OPENROUTER_API_KEY || '',
  ]
    .map((k) => k.trim())
    .filter((k) => k.length > 0);
  return Array.from(new Set(combined));
}

export function getNextOpenRouterKey(requestOverride?: string): string | null {
  const pool = getOpenRouterKeyPool(requestOverride);
  if (pool.length === 0) return null;
  if (requestOverride && requestOverride.trim().length > 0) {
    return requestOverride.trim();
  }
  const key = pool[openRouterKeyIndex % pool.length];
  openRouterKeyIndex = (openRouterKeyIndex + 1) % pool.length;
  return key;
}

export function getLedgerCountFromDb(): number {
  const db = readJsonDb();
  return Object.values(db.ledger).reduce((sum, list) => sum + list.length, 0);
}
