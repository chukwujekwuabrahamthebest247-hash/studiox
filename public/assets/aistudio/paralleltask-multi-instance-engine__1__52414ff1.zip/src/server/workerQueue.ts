/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Redis from 'ioredis';
import { Queue, Worker, Job } from 'bullmq';
import crypto from 'node:crypto';
import {
  completeFleetBatchHydrationInDb,
  getNextOpenRouterKey,
} from './db';

export interface AgentPlanJobPayload {
  prompt: string;
  currentApp?: string;
  serperKey?: string;
  tavilyKey?: string;
  openRouterKey?: string;
  openRouterModel?: string;
  slotId?: string;
}

export interface AgentPlanJobResult {
  fallbackToLocal?: boolean;
  webResearch?: {
    provider: string;
    query: string;
    answer: string;
  } | null;
  reasoning?: string;
  replyMessage?: string;
  steps?: any[];
  provider?: string;
  modelUsed?: string;
  queuedVia?: 'bullmq_redis' | 'in_process_async_queue';
  durationMs?: number;
}

export interface FleetHydrationJobPayload {
  batchId: string;
  spawnedCount: number;
  platform: string;
  region: string;
}

export interface TrackedJobRecord {
  jobId: string;
  queue: 'agent-automation-plan' | 'fleet-container-hydration';
  status: 'queued' | 'active' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  result?: any;
  error?: string;
}

const MAX_TRACKED_JOBS = 500;
const trackedJobs = new Map<string, TrackedJobRecord>();

function recordJobState(record: TrackedJobRecord): void {
  if (trackedJobs.size >= MAX_TRACKED_JOBS && !trackedJobs.has(record.jobId)) {
    const oldestKey = trackedJobs.keys().next().value;
    if (oldestKey) trackedJobs.delete(oldestKey);
  }
  trackedJobs.set(record.jobId, record);
}

// Execute actual AI planning + web research task (shared by BullMQ worker & in-process fallback worker)
async function processAgentPlanTask(payload: AgentPlanJobPayload): Promise<AgentPlanJobResult> {
  const startedAt = Date.now();
  const { prompt, currentApp, serperKey, tavilyKey, openRouterKey, openRouterModel } = payload;

  let webResearch: AgentPlanJobResult['webResearch'] = null;
  if (tavilyKey && typeof tavilyKey === 'string' && tavilyKey.trim().length > 0) {
    try {
      const tavilyRes = await fetch('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          api_key: tavilyKey.trim(),
          query: prompt,
          search_depth: 'basic',
          include_answer: true,
          max_results: 3,
        }),
      });
      if (tavilyRes.ok) {
        const tData = await tavilyRes.json();
        webResearch = {
          provider: 'Tavily AI',
          query: prompt,
          answer:
            tData.answer ||
            (tData.results?.[0]?.content
              ? tData.results[0].content.slice(0, 160)
              : 'Synthesized online research'),
        };
      }
    } catch (tErr) {
      console.warn('[WORKER] Tavily research note:', tErr);
    }
  }

  if (!webResearch && serperKey && typeof serperKey === 'string' && serperKey.trim().length > 0) {
    try {
      const serperRes = await fetch('https://google.serper.dev/search', {
        method: 'POST',
        headers: {
          'X-API-KEY': serperKey.trim(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ q: prompt, num: 3 }),
      });
      if (serperRes.ok) {
        const sData = await serperRes.json();
        const topSnippet =
          sData.organic?.[0]?.snippet || sData.knowledgeGraph?.description || 'Google Search verified';
        webResearch = {
          provider: 'Serper (Google)',
          query: prompt,
          answer: topSnippet,
        };
      }
    } catch (sErr) {
      console.warn('[WORKER] Serper search note:', sErr);
    }
  }

  const rotatedOpenRouterKey = getNextOpenRouterKey(
    typeof openRouterKey === 'string' ? openRouterKey : undefined
  );
  if (rotatedOpenRouterKey) {
    try {
      const openRouterModelName = openRouterModel || 'nvidia/nemotron-3.5-super-vl:free';
      const orRes = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${rotatedOpenRouterKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://aistudio.google.com',
          'X-Title': 'OmniPhone Automation',
        },
        body: JSON.stringify({
          model: openRouterModelName,
          messages: [
            {
              role: 'system',
              content:
                'You are an autonomous smartphone agent planner. Produce JSON containing replyMessage, reasoning, and steps array. Do EXACTLY what the user instructed without adding unprompted clicks or navigations.',
            },
            {
              role: 'user',
              content: `Prompt: "${prompt}". Current App: "${currentApp || 'home'}".`,
            },
          ],
          response_format: { type: 'json_object' },
          temperature: 0.2,
        }),
      });
      if (orRes.ok) {
        const orData = await orRes.json();
        const content = orData.choices?.[0]?.message?.content;
        if (content) {
          try {
            const parsed = JSON.parse(content);
            return {
              ...parsed,
              provider: 'OpenRouter',
              modelUsed: openRouterModelName,
              webResearch,
              durationMs: Date.now() - startedAt,
            };
          } catch {}
        }
      }
    } catch (orErr) {
      console.warn('[WORKER] OpenRouter planner note:', orErr);
    }
  }

  return {
    fallbackToLocal: true,
    webResearch,
    reasoning: 'Formulated precise automation sequence for instruction.',
    durationMs: Date.now() - startedAt,
  };
}

async function processFleetHydrationTask(payload: FleetHydrationJobPayload): Promise<{
  batchId: string;
  hydratedCount: number;
  completedAt: string;
}> {
  // Async yield so Express event loop stays free during batch hydration
  await new Promise((resolve) => setTimeout(resolve, 60));
  await completeFleetBatchHydrationInDb(payload.batchId, 'idle');
  return {
    batchId: payload.batchId,
    hydratedCount: payload.spawnedCount,
    completedAt: new Date().toISOString(),
  };
}

// ===============================================================================================
// BULLMQ + IOREDIS WORKER TIER (With Automatic Safe In-Process Async Queue Fallback)
// ===============================================================================================
let redisConnection: Redis | null = null;
let redisConnected = false;
let agentPlanQueue: Queue<AgentPlanJobPayload> | null = null;
let fleetHydrationQueue: Queue<FleetHydrationJobPayload> | null = null;
let agentPlanWorker: Worker<AgentPlanJobPayload> | null = null;
let fleetHydrationWorker: Worker<FleetHydrationJobPayload> | null = null;

let totalQueuedCount = 0;
let totalCompletedCount = 0;
let totalFailedCount = 0;
let activeInProcessCount = 0;

const REDIS_URL = (process.env.REDIS_URL || '').trim();

if (REDIS_URL) {
  try {
    redisConnection = new Redis(REDIS_URL, {
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
      retryStrategy(times) {
        if (times > 5) return null;
        return Math.min(times * 500, 3000);
      },
    });

    redisConnection.on('ready', () => {
      redisConnected = true;
      console.log('[QUEUE] Connected to Redis for BullMQ distributed background workers.');
    });

    redisConnection.on('error', (err) => {
      redisConnected = false;
      console.warn('[QUEUE] Redis connection notice (falling back to in-process async queue):', err.message);
    });

    redisConnection.on('close', () => {
      redisConnected = false;
    });

    const connectionOpt = redisConnection as any;
    agentPlanQueue = new Queue<AgentPlanJobPayload>('agent-automation-plan', {
      connection: connectionOpt,
      defaultJobOptions: {
        removeOnComplete: 200,
        removeOnFail: 100,
        attempts: 2,
      },
    });

    fleetHydrationQueue = new Queue<FleetHydrationJobPayload>('fleet-container-hydration', {
      connection: connectionOpt,
      defaultJobOptions: {
        removeOnComplete: 200,
        removeOnFail: 100,
        attempts: 2,
      },
    });

    agentPlanWorker = new Worker<AgentPlanJobPayload>(
      'agent-automation-plan',
      async (job: Job<AgentPlanJobPayload>) => {
        const res = await processAgentPlanTask(job.data);
        totalCompletedCount += 1;
        return { ...res, queuedVia: 'bullmq_redis' };
      },
      { connection: connectionOpt, concurrency: 16 }
    );
    agentPlanWorker.on('error', (err) => {
      console.warn('[QUEUE] Agent worker note:', err.message);
    });

    fleetHydrationWorker = new Worker<FleetHydrationJobPayload>(
      'fleet-container-hydration',
      async (job: Job<FleetHydrationJobPayload>) => {
        const res = await processFleetHydrationTask(job.data);
        totalCompletedCount += 1;
        return res;
      },
      { connection: connectionOpt, concurrency: 8 }
    );
    fleetHydrationWorker.on('error', (err) => {
      console.warn('[QUEUE] Fleet worker note:', err.message);
    });
  } catch (err: any) {
    console.warn('[QUEUE] BullMQ initialization notice (using in-process async queue):', err?.message || err);
    redisConnection = null;
    agentPlanQueue = null;
    fleetHydrationQueue = null;
  }
} else {
  console.log('[QUEUE] REDIS_URL not set; running decoupled in-process async worker queue fallback.');
}

export async function enqueueAgentPlanJob(
  payload: AgentPlanJobPayload,
  waitForResult: boolean = false
): Promise<{ jobId: string; result?: AgentPlanJobResult }> {
  const jobId = `job-plan-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  totalQueuedCount += 1;

  if (agentPlanQueue && redisConnected) {
    const bullJob = await agentPlanQueue.add('plan', payload, { jobId });
    recordJobState({
      jobId: bullJob.id || jobId,
      queue: 'agent-automation-plan',
      status: 'queued',
      createdAt: new Date().toISOString(),
    });
    if (waitForResult) {
      const result = await processAgentPlanTask(payload);
      return { jobId: bullJob.id || jobId, result: { ...result, queuedVia: 'bullmq_redis' } };
    }
    return { jobId: bullJob.id || jobId };
  }

  recordJobState({
    jobId,
    queue: 'agent-automation-plan',
    status: 'queued',
    createdAt: new Date().toISOString(),
  });

  const runPromise = (async (): Promise<AgentPlanJobResult> => {
    activeInProcessCount += 1;
    recordJobState({
      jobId,
      queue: 'agent-automation-plan',
      status: 'active',
      createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
    });
    try {
      const result = await processAgentPlanTask(payload);
      totalCompletedCount += 1;
      const finalResult: AgentPlanJobResult = {
        ...result,
        queuedVia: 'in_process_async_queue',
      };
      recordJobState({
        jobId,
        queue: 'agent-automation-plan',
        status: 'completed',
        createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
        completedAt: new Date().toISOString(),
        result: finalResult,
      });
      return finalResult;
    } catch (err: any) {
      totalFailedCount += 1;
      recordJobState({
        jobId,
        queue: 'agent-automation-plan',
        status: 'failed',
        createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
        completedAt: new Date().toISOString(),
        error: err?.message || 'Agent plan worker failed',
      });
      throw err;
    } finally {
      activeInProcessCount = Math.max(0, activeInProcessCount - 1);
    }
  })();

  if (waitForResult) {
    const result = await runPromise;
    return { jobId, result };
  }

  void runPromise.catch(() => {});
  return { jobId };
}

export async function enqueueFleetHydrationJob(
  payload: FleetHydrationJobPayload
): Promise<{ jobId: string; mode: 'redis_bullmq' | 'in_process_fallback' }> {
  const jobId = `job-fleet-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  totalQueuedCount += 1;

  if (fleetHydrationQueue && redisConnected) {
    await fleetHydrationQueue.add('hydrate', payload, { jobId });
    recordJobState({
      jobId,
      queue: 'fleet-container-hydration',
      status: 'queued',
      createdAt: new Date().toISOString(),
    });
    return { jobId, mode: 'redis_bullmq' };
  }

  recordJobState({
    jobId,
    queue: 'fleet-container-hydration',
    status: 'queued',
    createdAt: new Date().toISOString(),
  });

  setImmediate(async () => {
    activeInProcessCount += 1;
    recordJobState({
      jobId,
      queue: 'fleet-container-hydration',
      status: 'active',
      createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
    });
    try {
      const result = await processFleetHydrationTask(payload);
      totalCompletedCount += 1;
      recordJobState({
        jobId,
        queue: 'fleet-container-hydration',
        status: 'completed',
        createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
        completedAt: new Date().toISOString(),
        result,
      });
    } catch (err: any) {
      totalFailedCount += 1;
      recordJobState({
        jobId,
        queue: 'fleet-container-hydration',
        status: 'failed',
        createdAt: trackedJobs.get(jobId)?.createdAt || new Date().toISOString(),
        completedAt: new Date().toISOString(),
        error: err?.message || 'Fleet hydration failed',
      });
    } finally {
      activeInProcessCount = Math.max(0, activeInProcessCount - 1);
    }
  });

  return { jobId, mode: 'in_process_fallback' };
}

export async function getQueueJobStatus(jobId: string): Promise<TrackedJobRecord | null> {
  const localRecord = trackedJobs.get(jobId);
  if (localRecord) return localRecord;

  if (redisConnected && agentPlanQueue && fleetHydrationQueue) {
    try {
      const planJob = await agentPlanQueue.getJob(jobId);
      if (planJob) {
        const state = await planJob.getState();
        return {
          jobId,
          queue: 'agent-automation-plan',
          status:
            state === 'completed'
              ? 'completed'
              : state === 'failed'
              ? 'failed'
              : state === 'active'
              ? 'active'
              : 'queued',
          createdAt: new Date(planJob.timestamp).toISOString(),
          completedAt: planJob.finishedOn ? new Date(planJob.finishedOn).toISOString() : undefined,
          result: planJob.returnvalue,
          error: planJob.failedReason || undefined,
        };
      }

      const fleetJob = await fleetHydrationQueue.getJob(jobId);
      if (fleetJob) {
        const state = await fleetJob.getState();
        return {
          jobId,
          queue: 'fleet-container-hydration',
          status:
            state === 'completed'
              ? 'completed'
              : state === 'failed'
              ? 'failed'
              : state === 'active'
              ? 'active'
              : 'queued',
          createdAt: new Date(fleetJob.timestamp).toISOString(),
          completedAt: fleetJob.finishedOn ? new Date(fleetJob.finishedOn).toISOString() : undefined,
          result: fleetJob.returnvalue,
          error: fleetJob.failedReason || undefined,
        };
      }
    } catch {}
  }

  return null;
}

export async function getWorkerQueueMetrics(): Promise<{
  mode: 'redis_bullmq' | 'in_process_fallback';
  redisConfigured: boolean;
  redisConnected: boolean;
  totals: {
    queued: number;
    completed: number;
    failed: number;
    activeInProcess: number;
    trackedJobsCount: number;
  };
  queues: Record<string, any>;
}> {
  let queueCounts: Record<string, any> = {
    agentPlan: { active: activeInProcessCount },
    fleetHydration: { active: activeInProcessCount },
  };

  if (redisConnected && agentPlanQueue && fleetHydrationQueue) {
    try {
      const [planCounts, fleetCounts] = await Promise.all([
        agentPlanQueue.getJobCounts(),
        fleetHydrationQueue.getJobCounts(),
      ]);
      queueCounts = {
        agentPlan: planCounts,
        fleetHydration: fleetCounts,
      };
    } catch {}
  }

  return {
    mode: redisConnected ? 'redis_bullmq' : 'in_process_fallback',
    redisConfigured: Boolean(REDIS_URL),
    redisConnected,
    totals: {
      queued: totalQueuedCount,
      completed: totalCompletedCount,
      failed: totalFailedCount,
      activeInProcess: activeInProcessCount,
      trackedJobsCount: trackedJobs.size,
    },
    queues: queueCounts,
  };
}
