/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Custom Business Token Pricing Configuration:
 * Strictly $8.00 USD = 20,000,000 App Tokens ($1.00 USD = 2,500,000 App Tokens)
 * Stored as pure integers to prevent floating-point rounding errors.
 */
export const DEFAULT_INITIAL_BALANCE = 0; // Zero welcome grant: new accounts start with 0 tokens
export const TOKENS_PER_DOLLAR = 2_500_000;
export const STANDARD_PACKAGE_DOLLARS = 8;
export const STANDARD_PACKAGE_TOKENS = 20_000_000;
export const LOW_QUOTA_ALERT_THRESHOLD = 250_000; // $0.10 value
export const AUTOMATION_MARKUP_MULTIPLIER = 1;

// Strict Action-Based Token Deduction Rates
export const APP_INSTALL_TOKEN_COST = 25_000;
export const PROMPT_PLANNING_TOKEN_COST = 5_000;
export const EXECUTION_STEP_TOKEN_COST = 1_500;

// 5M Token Referral Program: 5,000,000 Free Tokens whenever invited friend buys first $8 pack
export const REFERRAL_BONUS_TOKENS = 5_000_000; // ~$0.50 operating cost
export const REFERRAL_QUALIFYING_PURCHASE_USD = 8;

export interface AuthenticatedUser {
  id: string;
  email: string;
  name: string;
  referralCode: string;
  referredBy?: string;
  createdAt: string;
  emailConfirmedAt?: string | null;
  isVerified?: boolean;
  avatarUrl?: string;
  provider?: string;
}

export interface QuotaLedgerEntry {
  id: string;
  timestamp: string;
  type: 'TOPUP' | 'AUTOMATION_RUN' | 'REFUND' | 'REFERRAL_BONUS';
  workflowName: string;
  tokensDelta: number; // positive for topup/referral, negative for deduction (exact integer)
  balanceAfter: number; // exact integer balance
  dollarEquivalent: number;
  metadata?: {
    promptSnippet?: string;
    stepsCount?: number;
    paymentReference?: string;
    provider?: string;
    referralCode?: string;
    referredUser?: string;
    friendName?: string;
  };
}

export interface UserTokenWallet {
  userId: string;
  referralCode: string; // Unique personal referral code (e.g. "OMNI-78A2")
  referredBy?: string; // Referral code of the person who invited this user
  hasMadeFirstQualifyingPurchase: boolean; // True once user buys their first $8+ pack
  referralInvitesCount: number; // Count of friends who joined via link
  referralConversionsCount: number; // Count of friends who bought first $8 pack
  referralTokensEarned: number; // Total 5M bonuses received (exact integer)
  appTokenBalance: number; // Exact integer token balance
  lifetimeTokensUsed: number; // Exact integer total tokens consumed
  lifetimeTokensPurchased: number; // Exact integer total tokens added
  lastTopupDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TokenTopupPackage {
  id: string;
  name: string;
  priceUsd: number;
  tokens: number;
  isPopular?: boolean;
  tagline: string;
}

export const TOKEN_TOPUP_PACKAGES: TokenTopupPackage[] = [
  {
    id: 'pack_starter',
    name: 'Starter Pack',
    priceUsd: 4,
    tokens: 10_000_000,
    tagline: 'Great for occasional automation testing',
  },
  {
    id: 'pack_standard',
    name: 'Standard Pack',
    priceUsd: 8,
    tokens: 20_000_000,
    isPopular: true,
    tagline: 'Most Popular: $8 for 20 Million Tokens',
  },
  {
    id: 'pack_pro',
    name: 'Pro Automation Pack',
    priceUsd: 16,
    tokens: 40_000_000,
    tagline: 'High-frequency parallel process workers',
  },
  {
    id: 'pack_enterprise',
    name: 'Enterprise Ultra Pack',
    priceUsd: 32,
    tokens: 80_000_000,
    tagline: 'Continuous 24/7 autonomous agent pipelines',
  },
];

export function tokensToUsd(tokens: number): number {
  return Number((tokens / TOKENS_PER_DOLLAR).toFixed(4));
}

export function usdToTokens(dollars: number): number {
  return Math.round(dollars * TOKENS_PER_DOLLAR);
}

export function formatTokenCount(tokens: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(tokens));
}
