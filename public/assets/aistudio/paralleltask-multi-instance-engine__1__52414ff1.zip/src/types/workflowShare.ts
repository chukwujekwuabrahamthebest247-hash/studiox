/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PhoneAppType } from './phone';

export interface PublicWorkflowTemplate {
  id: string;
  slug: string;
  title: string;
  description: string;
  prompt: string;
  targetApp: PhoneAppType | 'all';
  author: string;
  authorEmail?: string;
  createdAt: string;
  runCount: number;
  cloneCount: number;
  estimatedTokens: number;
  estimatedSeconds: number;
  tags: string[];
  isFeatured?: boolean;
}

export interface PublishWorkflowRequest {
  title: string;
  description: string;
  prompt: string;
  targetApp?: PhoneAppType | 'all';
  authorName?: string;
  tags?: string[];
}
