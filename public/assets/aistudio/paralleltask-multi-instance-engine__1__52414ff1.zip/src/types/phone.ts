/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PhoneAppType =
  | 'home'
  | 'social'
  | 'food'
  | 'messages'
  | 'notes'
  | 'settings'
  | 'browser'
  | 'gallery'
  | 'banking'
  | 'sheets'
  | 'quickbooks'
  | 'whatsapp'
  | 'telegram'
  | 'discord'
  | 'slack'
  | 'twitter'
  | 'linkedin'
  | 'instagram'
  | 'gmail'
  | 'googledocs'
  | 'googlesheets'
  | 'googledrive'
  | 'msexcel'
  | 'msword'
  | 'notion'
  | 'shopify'
  | 'ebay'
  | 'amazon'
  | 'chrome'
  | 'firefox'
  | 'tiktok'
  | 'tinder'
  | 'cryptowallet'
  | (string & {});

export interface InstalledAppItem {
  id: string;
  name: string;
  icon: string;
  bg: string;
  packageType: 'apk' | 'ipa' | 'exe' | 'app';
  platform?: 'android' | 'ios' | 'both';
  version?: string;
  size?: string;
  description?: string;
  isCustom?: boolean;
  storeUrl?: string;
  packageName?: string;
  adbTarget?: string;
  bundleId?: string;
  launchUrl?: string;
  iosEngineMode?: 'webkit_linux' | 'xcode_simulator';
  iosEngineLabel?: string;
  fileHash?: string;
  deduplicated?: boolean;
  installedAt?: string;
  streamUrl?: string;
  webrtcUrl?: string;
}

export interface AgentStep {
  id?: string;
  action:
    | 'navigate_app'
    | 'go_home'
    | 'tap'
    | 'type_text'
    | 'swipe_up'
    | 'swipe_down'
    | 'wait'
    | 'biometric_auth'
    | 'guardrail_approval';
  detail?: string;
  targetApp?: PhoneAppType;
  targetName?: string;
  x?: number;
  y?: number;
  value?: string;
  distance?: number;
  duration?: number;
  status?: 'pending' | 'running' | 'completed' | 'failed';
  requiresBiometric?: boolean;
  biometricPrompt?: string;
  requiresApproval?: boolean;
  guardrailType?: string;
  approvalDetail?: string;
}

export interface TelemetryLog {
  id: string;
  timestamp: string;
  level:
    | 'SENSOR'
    | 'PLANNER'
    | 'ACTUATOR'
    | 'VERIFIER'
    | 'SYSTEM'
    | 'VISION_MONITOR'
    | 'AI_TOOL'
    | 'RESEARCH'
    | 'GUARDRAIL'
    | 'VAULT';
  message: string;
  meta?: any;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
  reasoning?: string;
  steps?: AgentStep[];
  isRunning?: boolean;
  latestScreenshotUrl?: string;
  missingApp?: {
    appName: string;
    appKey?: string;
    storeQuery?: string;
    icon?: string;
    originalPrompt: string;
    resolved?: boolean;
  };
  verification?: {
    goal: string;
    passed: boolean;
    checks: Array<{ label: string; passed: boolean; details?: string }>;
    autoCorrected?: boolean;
    correctionDetails?: string;
    confidence: number;
    timestamp: string;
  };
  visionObservations?: VisionObservation[];
  takeoverEngaged?: boolean;
  takeoverReason?: string;
  takeoverToolCalls?: AIToolCall[];
  webResearch?: {
    query: string;
    provider: string;
    answer: string;
  };
  thinkingOutsideTheBox?: {
    creativeStrategy: string;
  };
  appliedKnowledge?: string;
}

export interface SocialPost {
  id: string;
  author: string;
  handle: string;
  avatar: string;
  image: string;
  caption: string;
  likes: number;
  isLiked: boolean;
  commentsCount: number;
  bookmarked: boolean;
  timeAgo: string;
}

export interface FoodItem {
  id: string;
  name: string;
  category: string;
  price: number;
  rating: number;
  prepTime: string;
  image: string;
  description: string;
  calories: number;
}

export interface CartItem {
  item: FoodItem;
  quantity: number;
}

export interface ContactThread {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'offline';
  lastMessage: string;
  time: string;
  unreadCount: number;
  messages: Array<{
    id: string;
    sender: 'me' | 'them';
    text: string;
    time: string;
  }>;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  updatedAt: string;
  category: string;
}

export interface PhoneSettings {
  darkMode: boolean;
  wifi: boolean;
  bluetooth: boolean;
  lowPower: boolean;
  volume: number;
  brightness: number;
  notifications: boolean;
}

export interface ScreenshotFrame {
  id: string;
  timestamp: string;
  dataUrl: string;
  elementCount: number;
  detectedApp: string;
}

export interface VisionObservation {
  id: string;
  timestamp: string;
  stepIndex: number;
  actionExecuted: string;
  screenshotUrl: string;
  observationText: string;
  matchesInstruction: boolean;
  discrepancyReason?: string;
  reorderedPlan?: any;
  difficultyScore: number;
  takeoverRecommended: boolean;
  takeoverReason?: string;
  latency?: number;
}

export interface AIToolCall {
  id: string;
  tool: string;
  params: any;
  timestamp: string;
  status: 'executing' | 'success' | 'failed';
  output?: string;
  reasoning?: string;
  screenshotBefore?: string;
}

export interface TakeoverState {
  isActive: boolean;
  reason?: string;
  toolCalls: AIToolCall[];
  currentTool: AIToolCall | null;
  stage: 'idle' | 'operating_tools' | 'resolved';
  autonomousMode: boolean;
}

export interface ObstacleState {
  active: boolean;
  type: string;
  title: string;
  message: string;
  actionLabel: string;
}

export interface InternalAutomationState {
  currentInstructionPointer: number;
  callStack: any[];
  domResolverTrace: any;
  memoryStoreDump: InternalMemoryStoreDump;
  eventDispatcher: {
    queueLength: number;
    dispatchedEventsCount: number;
    droppedEventsCount: number;
    lastEventDispatched: string;
  };
  internalInterventions: any[];
}

export interface InternalMemoryStoreDump {
  app: PhoneAppType;
  cartCount: number;
  cartSubtotal: number;
  activeMessageThread: string | null;
  messageDraftBuffer: string;
  unreadTotal: number;
  notesCount: number;
  noteDraftTitle: string;
  darkMode: boolean;
  wifi: boolean;
  bluetooth: boolean;
  lowPower: boolean;
  searchQuery: string;
  browserQuery: string;
  [key: string]: any;
}

export interface ActionGuardrailState {
  id: string;
  stepIndex: number;
  title: string;
  category: string;
  severity: 'low' | 'medium' | 'high';
  amount?: string;
  recipientOrVendor?: string;
  consequence?: string;
  details?: string[];
  rawStep?: any;
}

export interface BiometricPromptState {
  id: string;
  stepIndex: number;
  type: 'face_id' | 'touch_id';
  appName: string;
  reason: string;
}

export interface CrossAppTemplate {
  id: string;
  title: string;
  prompt: string;
  apps: PhoneAppType[];
  description: string;
}
