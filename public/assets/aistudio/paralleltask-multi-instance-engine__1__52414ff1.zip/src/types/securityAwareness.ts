/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AppSecurityProfile {
  id: string;
  name: string;
  securityTier: 'TIER_1_CRITICAL' | 'TIER_2_RESTRICTED' | 'TIER_3_STANDARD';
  riskScore: number;
  requiresBiometricAuth: boolean;
  vaultMaskingActive: boolean;
  researchSource: string;
  guardrailRules: {
    requiresApprovalForTransactions: boolean;
  };
}
