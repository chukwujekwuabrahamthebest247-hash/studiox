/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep } from './phone';

export interface InterruptedAutomationState {
  isInterrupted: boolean;
  interruptedApp: string;
  interruptedAppName: string;
  stepIndex: number;
  totalSteps: number;
  stepDetail: string;
  timestamp: string;
  reason: string;
  pendingSteps: AgentStep[];
  allSteps: AgentStep[];
  goalSummary: string;
  planReasoning: string;
}
