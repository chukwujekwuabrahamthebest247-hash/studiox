/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  ChatMessage,
  AgentStep,
  TelemetryLog,
  ScreenshotFrame,
  VisionObservation,
  TakeoverState,
  ObstacleState,
  InternalAutomationState,
  PhoneAppType,
  CrossAppTemplate,
} from '../../types/phone';
import { OpenRouterConfig, SerperConfig, TavilyConfig } from '../modals/OpenRouterModal';
import { AppSecurityProfile } from '../../types/securityAwareness';
import { SupportedLanguage } from '../../utils/multilingualSlang';
import { BandwidthMode } from '../../utils/lowBandwidthOptimizer';
import { InterruptedAutomationState } from '../../types/sandboxedApps';
import {
  Send,
  Square,
  Play,
  Pause,
  Bot,
  User,
  Zap,
  Eye,
  Volume2,
  VolumeX,
  Camera,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  Activity,
  Layers,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Globe,
  Radio,
  Mic,
  MicOff,
  Share2,
  Compass,
  Download,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { sounds } from '../../utils/soundEffects';

interface AgentChatProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isExecuting: boolean;
  queuedPromptsCount: number;
  isPaused: boolean;
  onTogglePause: () => void;
  onAbort: () => void;
  speed: number;
  onSpeedChange: (speed: number) => void;
  agentVisionMode: boolean;
  onToggleAgentVision: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  telemetryLogs: TelemetryLog[];
  currentStepIndex: number;
  currentSteps: AgentStep[];
  openRouterConfig: OpenRouterConfig;
  onOpenRouterClick: () => void;
  serperConfig: SerperConfig;
  onSerperClick: () => void;
  tavilyConfig: TavilyConfig;
  onTavilyClick: () => void;
  screenshotFrames: ScreenshotFrame[];
  latestScreenshot: string | null;
  visionObservations: VisionObservation[];
  takeoverState: TakeoverState;
  onTriggerTakeover: () => void;
  obstacle: ObstacleState | null;
  onSimulateObstacle: () => void;
  onClearObstacle: () => void;
  onCaptureScreenshot: (forceFull?: boolean) => Promise<string | null>;
  onTakeScreenshotAndCheck: () => void;
  isCapturing: boolean;
  isContinuousMonitoring: boolean;
  onToggleContinuousMonitoring: () => void;
  internalState: InternalAutomationState;
  onTriggerInternalControl: (tool: string, params: any) => void;
  onSimulateInternalDrift: () => void;
  currentSecurityProfile: AppSecurityProfile | null;
  currentApp: PhoneAppType;
  onOpenAppInPhone: (app: string) => void;
  onProbeApp: (target: string) => Promise<AppSecurityProfile | null>;
  onRunCrossAppTemplate: (tmpl: CrossAppTemplate) => void;
  selectedLanguage: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onOpenLanguageModal: () => void;
  bandwidthMode: BandwidthMode;
  onBandwidthChange: (mode: BandwidthMode) => void;
  interruptedAutomation: InterruptedAutomationState | null;
  onResumeInterruptedAutomation: () => void;
  onRestartInterruptedAutomation: () => void;
  onDismissInterruptedAutomation: () => void;
  onBlockedUnauthorizedAppAttempt: (appName?: string) => void;
  onShareWorkflow?: (data: { title: string; prompt: string; app?: PhoneAppType }) => void;
  onOpenTemplatesModal?: () => void;
  phonePlatform?: 'android' | 'ios';
  onDownloadMissingApp?: (appName: string, originalPrompt: string) => void;
}

export const AgentChat: React.FC<AgentChatProps> = ({
  messages,
  onSendMessage,
  isExecuting,
  queuedPromptsCount,
  isPaused,
  onTogglePause,
  onAbort,
  speed,
  onSpeedChange,
  agentVisionMode,
  onToggleAgentVision,
  soundEnabled,
  onToggleSound,
  telemetryLogs,
  currentStepIndex,
  currentSteps,
  screenshotFrames,
  latestScreenshot,
  visionObservations,
  takeoverState,
  onTriggerTakeover,
  obstacle,
  onSimulateObstacle,
  onClearObstacle,
  onTakeScreenshotAndCheck,
  isContinuousMonitoring,
  onToggleContinuousMonitoring,
  onRunCrossAppTemplate,
  onShareWorkflow,
  onOpenTemplatesModal,
  currentApp = 'home',
  phonePlatform = 'android',
  onDownloadMissingApp,
}) => {
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'chat' | 'telemetry' | 'vision'>('chat');
  const [isPromptsOpen, setIsPromptsOpen] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const isListeningRef = useRef(false);
  isListeningRef.current = isListening;

  const [audioLevel, setAudioLevel] = useState<number>(0);
  const speechRecognitionRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const typeIntervalRef = useRef<any>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, visionObservations, telemetryLogs]);

  const stopListeningSession = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.onend = null;
        speechRecognitionRef.current.onerror = null;
        speechRecognitionRef.current.stop();
      } catch {}
      speechRecognitionRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (typeIntervalRef.current) {
      clearInterval(typeIntervalRef.current);
      typeIntervalRef.current = null;
    }
    setIsListening(false);
    setAudioLevel(0);
  };

  // Clean up voice sessions when unmounting
  useEffect(() => {
    return () => {
      stopListeningSession();
    };
  }, []);

  // Types given text character-by-character live into the prompt place so user sees what is being typed
  const typeSpokenPromptLive = (textToType: string) => {
    if (typeIntervalRef.current) {
      clearInterval(typeIntervalRef.current);
    }
    let currentIdx = 0;
    setInputText('');
    inputRef.current?.focus();

    typeIntervalRef.current = setInterval(() => {
      currentIdx += 2;
      const slice = textToType.slice(0, currentIdx);
      setInputText(slice);
      sounds.playKeypress();

      if (currentIdx >= textToType.length) {
        clearInterval(typeIntervalRef.current);
        typeIntervalRef.current = null;
        sounds.playSuccess();
      }
    }, 45);
  };

  const toggleListening = async () => {
    if (isListening) {
      stopListeningSession();
      sounds.playTap();
      return;
    }

    // Activate voice listening mode immediately so button starts on tap without delay
    setIsListening(true);
    sounds.playNotification();
    inputRef.current?.focus();

    // 1. Initialize real microphone capture and audio level metering
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          source.connect(analyser);

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const updateMeter = () => {
            if (!isListeningRef.current) return;
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            // Scale to 0-100 range with sensitivity boost
            setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
            animFrameRef.current = requestAnimationFrame(updateMeter);
          };
          updateMeter();
        }
      } catch (micErr) {
        console.warn('Microphone stream access notice:', micErr);
        // Start simulated organic voice wave if mic access is blocked by iframe security
        let angle = 0;
        const simInterval = setInterval(() => {
          if (!isListeningRef.current) {
            clearInterval(simInterval);
            return;
          }
          angle += 0.2;
          const waveVal = Math.round(35 + Math.sin(angle) * 25 + Math.cos(angle * 2) * 15);
          setAudioLevel(waveVal);
        }, 120);
      }
    }

    // 2. Initialize SpeechRecognition for real-time live typing
    const SpeechRec =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRec) {
      try {
        const recognition = new SpeechRec();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
          setIsListening(true);
        };

        recognition.onresult = (event: any) => {
          let fullTranscript = '';
          for (let i = 0; i < event.results.length; i++) {
            fullTranscript += event.results[i][0].transcript;
          }
          if (fullTranscript) {
            // Live typing inside the prompt place as the user speaks (ChatGPT style)
            setInputText(fullTranscript);
            sounds.playKeypress();
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition warning/iframe sandbox notice:', event?.error);
          // CRITICAL: DO NOT call setIsListening(false). Keep listening active!
        };

        recognition.onend = () => {
          // Restart gracefully if still in listening mode
          if (isListeningRef.current) {
            try {
              recognition.start();
            } catch {}
          }
        };

        speechRecognitionRef.current = recognition;
        recognition.start();
      } catch (err) {
        console.warn('Native speech recognition initialization note:', err);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    if (isListening) {
      stopListeningSession();
    }
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const quickStartPrompts: string[] = [
    'Open WhatsApp and send a message to Sarah saying I am on my way',
    'Grab the latest unread inboxes in my Gmail and summarize them',
    'Open TikTok and scroll through the top 5 trending videos',
    'Open Instagram and like the latest post on my feed',
    'Open BiteDash and add a Pepperoni Pizza to my cart',
    'Search Google for top AI startups in 2026 and save results to Notes',
    'Open Telegram and check my unread channel updates',
    'Open Apex Bank and audit my account for weird recurring charges',
    'Open QuickBooks and prepare invoice #INV-2026-104 for review',
    'Open Settings and switch my phone to Dark Mode',
    'Open YouTube and search for AI automation tutorials',
    'Open Spotify and play my daily focus playlist',
    "Open Notes and create a new checklist for today's meetings",
    'Open X (Twitter) and check trending tech topics',
    'Open Crypto Wallet and check my current portfolio balance',
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-900 overflow-hidden text-slate-100">
      {/* Subheader Toolbar */}
      <div className="h-11 px-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-3 py-1 rounded-lg font-medium transition ${
              activeTab === 'chat'
                ? 'bg-slate-800 text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Agent Chat
          </button>
          <button
            onClick={() => setActiveTab('telemetry')}
            className={`px-3 py-1 rounded-lg font-medium transition flex items-center gap-1.5 ${
              activeTab === 'telemetry'
                ? 'bg-slate-800 text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Telemetry</span>
            <span className="text-[10px] font-mono opacity-60">({telemetryLogs.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('vision')}
            className={`px-3 py-1 rounded-lg font-medium transition flex items-center gap-1.5 ${
              activeTab === 'vision'
                ? 'bg-slate-800 text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Vision Monitor</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio toggle */}
          <button
            onClick={onToggleSound}
            className={`p-1.5 rounded-lg border transition ${
              soundEnabled
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
            title="Toggle Synthesizer Sound"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>
          {/* On-Demand Screenshot Check */}
          <button
            onClick={onTakeScreenshotAndCheck}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-medium text-slate-300 flex items-center gap-1"
          >
            <Camera className="w-3 h-3 text-cyan-400" />
            <span>Verify Screen</span>
          </button>
        </div>
      </div>

      {/* Main Content Pane */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {activeTab === 'chat' && (
          <div className="space-y-4">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-3 text-xs ${
                  m.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {m.sender === 'agent' && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center text-slate-950 font-bold shrink-0 shadow-md">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 space-y-2 ${
                    m.sender === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-none'
                      : 'bg-slate-800/90 text-slate-200 border border-slate-700/60 rounded-bl-none shadow-md'
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-line">{m.text}</p>

                  {/* Plan Steps Checklist */}
                  {m.steps && m.steps.length > 0 && (
                    <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-2.5 space-y-1.5 mt-2">
                      <div className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1">
                        <Activity className="w-3 h-3" />
                        <span>Execution Sequence ({m.steps.length} Steps)</span>
                      </div>
                      <div className="space-y-1">
                        {m.steps.map((st, sIdx) => {
                          const isDone = m.isRunning ? sIdx < currentStepIndex : true;
                          const isCurrent = m.isRunning && sIdx === currentStepIndex;
                          return (
                            <div
                              key={st.id || sIdx}
                              className={`flex items-center gap-2 text-[11px] p-1 rounded-lg ${
                                isCurrent
                                  ? 'bg-emerald-950/60 text-emerald-300 font-bold'
                                  : isDone
                                  ? 'text-slate-300'
                                  : 'text-slate-500'
                              }`}
                            >
                              <span className="font-mono text-[9px] w-4">
                                {isDone ? '✓' : isCurrent ? '⚡' : `${sIdx + 1}.`}
                              </span>
                              <span className="truncate">{st.detail || st.action}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Missing App Auto-Detection Action Card */}
                  {m.missingApp && (
                    <div className="bg-slate-950 border border-amber-500/40 rounded-xl p-3 space-y-2 mt-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-sm shrink-0">
                            {m.missingApp.icon || '📦'}
                          </span>
                          <div className="min-w-0">
                            <p className="font-bold text-xs text-amber-300 truncate">
                              Missing App Detected: Download {m.missingApp.appName}
                            </p>
                            <p className="text-[10px] text-slate-400">
                              Target Store:{' '}
                              {phonePlatform === 'ios' ? 'Apple App Store (iOS)' : 'Google Play Store (Android)'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {m.missingApp.resolved ? (
                        <div className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>{m.missingApp.appName} installed — task resumed.</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          data-agent-target="btn-chat-download-missing-app"
                          onClick={() => {
                            sounds.playTap();
                            onDownloadMissingApp?.(
                              m.missingApp!.storeQuery || m.missingApp!.appName,
                              m.missingApp!.originalPrompt
                            );
                          }}
                          className={`w-full py-2 px-3 rounded-lg text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-md whitespace-nowrap ${
                            phonePlatform === 'ios'
                              ? 'bg-blue-600 hover:bg-blue-500'
                              : 'bg-emerald-600 hover:bg-emerald-500'
                          }`}
                        >
                          <Download className="w-3.5 h-3.5 shrink-0" />
                          <span>
                            Download Now ({phonePlatform === 'ios' ? 'Apple App Store' : 'Google Play Store'})
                          </span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Verification Result Badge */}
                  {m.verification && (
                    <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-2.5 text-[11px] text-emerald-300 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Results Checker: 100% Verified</span>
                      </div>
                      <p className="text-[10px] text-slate-300">
                        Objective fulfilled: "{m.verification.goal}"
                      </p>
                    </div>
                  )}

                  {/* 1-Click "Share Workflow" Link Trigger */}
                  {onShareWorkflow && (m.verification || (m.steps && m.steps.length > 0)) && (
                    <button
                      type="button"
                      onClick={() => {
                        sounds.playTap();
                        const userPrompt = messages
                          .slice(0, messages.findIndex((msg) => msg.id === m.id))
                          .reverse()
                          .find((msg) => msg.sender === 'user')?.text || m.verification?.goal || m.text;
                        onShareWorkflow({
                          title: m.verification?.goal || 'Automated Mobile Task',
                          prompt: userPrompt,
                          app: currentApp,
                        });
                      }}
                      className="mt-2 w-full py-1.5 px-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 hover:border-emerald-500/60 text-emerald-300 hover:text-white text-[11px] font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-98 shadow-xs"
                      title="Publish this automation as a 1-click shareable public link (e.g. 'Copy my Automated Lead Scraper')"
                    >
                      <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>1-Click "Share Workflow" Link</span>
                    </button>
                  )}

                  <span className="text-[9px] opacity-60 block text-right font-mono mt-1">
                    {m.timestamp}
                  </span>
                </div>
                {m.sender === 'user' && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center font-bold shrink-0 border border-slate-700">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Telemetry Tab */}
        {activeTab === 'telemetry' && (
          <div className="font-mono text-[10px] space-y-1.5 bg-slate-950 p-4 rounded-2xl border border-slate-800 max-h-full overflow-y-auto">
            {telemetryLogs.map((log) => (
              <div key={log.id} className="flex gap-2">
                <span className="text-slate-500">{log.timestamp}</span>
                <span
                  className={`font-bold ${
                    log.level === 'ACTUATOR'
                      ? 'text-cyan-400'
                      : log.level === 'PLANNER'
                      ? 'text-purple-400'
                      : log.level === 'VERIFIER'
                      ? 'text-emerald-400'
                      : log.level === 'GUARDRAIL'
                      ? 'text-amber-400'
                      : 'text-slate-400'
                  }`}
                >
                  [{log.level}]
                </span>
                <span className="text-slate-300">{log.message}</span>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Vision Monitor Tab */}
        {activeTab === 'vision' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">Gemini Continuous Vision QA</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 font-bold">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>Prompt Fidelity 100%</span>
                </span>
                <button
                  onClick={onToggleContinuousMonitoring}
                  className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                    isContinuousMonitoring
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {isContinuousMonitoring ? 'Monitoring Active' : 'Paused'}
                </button>
              </div>
            </div>

            {latestScreenshot ? (
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                  <span>Continuous Phone Screenshot Stream</span>
                  <span className="text-emerald-400 font-bold">● LIVE INGESTION</span>
                </div>
                <img
                  src={latestScreenshot}
                  alt="Phone Frame"
                  className="w-full max-h-60 object-contain rounded-xl border border-slate-800 shadow-md bg-slate-900"
                />
                <p className="text-[10px] text-slate-400 leading-tight">
                  Screenshots are continuously captured and fed into the AI Model perception engine while automation is executing for a given prompt.
                </p>
              </div>
            ) : (
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-dashed border-slate-800 text-center space-y-2">
                <Camera className="w-8 h-8 mx-auto text-slate-600" />
                <p className="text-xs font-semibold text-slate-300">
                  Screenshots Standby
                </p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  The AI model will only take screenshots once a prompt has been given and automation starts executing.
                </p>
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h5 className="font-bold text-xs text-slate-300">Prompt Alignment Observations</h5>
                <span className="text-[10px] font-mono text-emerald-400">Zero Divergence Guarantee</span>
              </div>
              {visionObservations.slice(-6).map((obs) => (
                <div
                  key={obs.id}
                  className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] space-y-1"
                >
                  <div className="flex justify-between items-center text-slate-500 font-mono text-[9px]">
                    <span className="text-emerald-400 font-bold">Step #{obs.stepIndex + 1}: {obs.actionExecuted}</span>
                    <span>{obs.timestamp} ({obs.latency}ms)</span>
                  </div>
                  <p className="text-slate-300">{obs.observationText}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Curated Quick Start Prompts (15) Scrollable Drawer */}
      <div className="bg-slate-900/90 border-t border-slate-800/80 shrink-0">
        <button
          type="button"
          onClick={() => setIsPromptsOpen((o) => !o)}
          className="w-full px-4 py-1.5 flex items-center justify-between text-[11px] font-semibold text-slate-300 hover:text-white transition cursor-pointer"
        >
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Quick Start Prompts (15)</span>
          </span>
          <span className="flex items-center gap-1 text-[10px] font-mono text-slate-400">
            <span>{isPromptsOpen ? 'Collapse' : 'Expand'}</span>
            {isPromptsOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </span>
        </button>

        {isPromptsOpen && (
          <div className="px-4 pb-2.5 max-h-32 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {quickStartPrompts.map((p, i) => (
              <button
                key={i}
                type="button"
                data-agent-target={`quick-prompt-${i + 1}`}
                onClick={() => onSendMessage(p)}
                title={p}
                className="text-left px-2.5 py-1.5 bg-slate-950/90 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/40 rounded-xl text-[11px] text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-2 min-w-0"
              >
                <span className="font-mono tabular-nums text-[10px] text-emerald-400 font-bold shrink-0 w-4">
                  {i + 1}.
                </span>
                <span className="truncate">{p}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Chat Input & Controls Bar */}
      <div className="p-3 bg-slate-950 border-t border-slate-800">
        {/* ChatGPT Style Live Voice Dictation Wave Status */}
        {isListening && (
          <div className="p-3 mb-2.5 bg-gradient-to-r from-emerald-950/95 via-slate-900 to-teal-950/95 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                {/* Audio-reactive Voice Equalizer Waveform */}
                <div className="flex items-center gap-1 h-5 px-1 bg-emerald-950/80 rounded-md border border-emerald-500/30">
                  <span
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(6, Math.min(20, 6 + (audioLevel * 0.14)))}px` }}
                  />
                  <span
                    className="w-1 bg-emerald-300 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(10, Math.min(22, 10 + (audioLevel * 0.22)))}px` }}
                  />
                  <span
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(14, Math.min(24, 14 + (audioLevel * 0.26)))}px` }}
                  />
                  <span
                    className="w-1 bg-emerald-300 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(8, Math.min(18, 8 + (audioLevel * 0.18)))}px` }}
                  />
                  <span
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(5, Math.min(15, 5 + (audioLevel * 0.12)))}px` }}
                  />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-[11px] text-white tracking-wide">
                      ChatGPT Voice Mode
                    </span>
                    <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  </div>
                  <p className="text-[10px] text-emerald-300/90">
                    {inputText
                      ? 'Live typing spoken words into the prompt place below...'
                      : 'Speak now — your voice writes directly into the prompt place...'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {inputText && (
                  <button
                    type="button"
                    onClick={() => setInputText('')}
                    className="text-[10px] font-medium px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md transition cursor-pointer"
                  >
                    Clear
                  </button>
                )}
                <button
                  type="button"
                  onClick={stopListeningSession}
                  className="text-[10px] font-bold px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md transition cursor-pointer shadow-sm"
                >
                  Stop Voice
                </button>
              </div>
            </div>

            {/* Quick voice dictation phrases that type live into the prompt */}
            <div className="pt-1 border-t border-emerald-900/50 flex items-center gap-1.5 overflow-x-auto text-[10px] text-slate-300">
              <span className="text-emerald-400/80 font-mono text-[9px] uppercase tracking-wider shrink-0">
                Spoken Dictation:
              </span>
              {[
                'Search for Lionel Messi',
                'Order a Pepperoni Pizza on BiteDash',
                'Like the latest post on Social',
                'Toggle Dark Mode in Settings',
                'Send Sarah Chen a message',
              ].map((phrase, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => typeSpokenPromptLive(phrase)}
                  className="px-2 py-0.5 bg-slate-900/90 hover:bg-emerald-900/50 border border-emerald-500/30 rounded-md text-emerald-200 hover:text-white shrink-0 transition cursor-pointer"
                  title="Click to dictate this phrase live into the prompt"
                >
                  "{phrase}"
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Quick Public Workflow Templates Bar */}
        <div className="flex items-center justify-between text-[10px] text-slate-400 pb-1.5 px-0.5">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-slate-500 font-semibold shrink-0">1-Click Template:</span>
            {[
              { label: '🔍 Lead Scraper', prompt: 'Open SearchGlobe browser, search for top AI startups in San Francisco, extract founder contact details and save into a note titled "AI Startup Leads".' },
              { label: '📱 Social Poster', prompt: 'Open Social app, create a new trending post about autonomous AI screen agents with hashtag #TechTrends2026, and publish.' },
              { label: '🍕 Food Basket', prompt: 'Open Food Delivery app, find popular artisan dishes, add 2 items under $25 to cart and proceed to review.' },
            ].map((tmpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setInputText(tmpl.prompt)}
                className="px-2 py-0.5 rounded-md bg-slate-900 hover:bg-emerald-950/40 border border-slate-800 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-300 shrink-0 transition cursor-pointer"
                title="Load template prompt"
              >
                {tmpl.label}
              </button>
            ))}
          </div>

          {onOpenTemplatesModal && (
            <button
              type="button"
              onClick={onOpenTemplatesModal}
              className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 shrink-0 ml-2 cursor-pointer"
            >
              <Compass className="w-3 h-3" />
              <span className="hidden sm:inline">Templates</span>
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2 items-center">
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              isListening
                ? "🎙️ Listening... speak and your voice will write here in real time (ChatGPT style)..."
                : "Type or use voice to give phone automation instruction..."
            }
            className={`flex-1 bg-slate-900 border rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-hidden transition ${
              isListening
                ? 'border-emerald-500 ring-2 ring-emerald-500/30 shadow-emerald-500/10 shadow-lg bg-slate-900/90'
                : 'border-slate-800 focus:border-emerald-500'
            }`}
          />

          {/* Voice Dictation (ChatGPT style) Button */}
          <button
            type="button"
            onClick={toggleListening}
            className={`p-2.5 rounded-xl transition cursor-pointer flex items-center justify-center shrink-0 ${
              isListening
                ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/30 shadow-lg scale-105'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 hover:bg-slate-850'
            }`}
            title={isListening ? 'Stop Voice Input' : 'Voice Input (ChatGPT Style Dictation)'}
          >
            {isListening ? (
              <div className="flex items-center gap-0.5 px-0.5">
                <span className="w-1 h-3.5 bg-slate-950 rounded-full animate-pulse" />
                <span className="w-1 h-4.5 bg-slate-950 rounded-full animate-bounce" />
                <span className="w-1 h-2.5 bg-slate-950 rounded-full animate-pulse" />
              </div>
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>

          {isExecuting ? (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={onTogglePause}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl border border-slate-700 cursor-pointer"
                title={isPaused ? 'Resume' : 'Pause'}
              >
                {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4 fill-current" />}
              </button>
              <button
                type="button"
                onClick={onAbort}
                className="p-2.5 bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white rounded-xl border border-rose-500/50 cursor-pointer"
                title="Emergency Stop"
              >
                <Square className="w-4 h-4 fill-current" />
              </button>
            </div>
          ) : (
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl transition shadow-md cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
