/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  TimeSavedMetrics,
  getTimeSavedMetrics,
  subscribeToTimeSavedMetrics,
  formatHoursSaved,
} from '../../utils/timeSavedTracker';
import { Clock, Zap, CheckCircle2, X } from 'lucide-react';

interface TimeSavedModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TimeSavedModal: React.FC<TimeSavedModalProps> = ({ isOpen, onClose }) => {
  const [metrics, setMetrics] = useState<TimeSavedMetrics>(getTimeSavedMetrics());

  useEffect(() => {
    setMetrics(getTimeSavedMetrics());
    const unsub = subscribeToTimeSavedMetrics((m) => setMetrics(m));
    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const hoursSaved = formatHoursSaved(metrics.monthlySecondsSaved);
  const minutesSaved = Math.round(metrics.monthlySecondsSaved / 60);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl text-slate-200 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">The Time-Saved Tracker</h3>
              <p className="text-[11px] text-slate-400">
                Accurate monthly telemetry ({metrics.monthKey})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-gradient-to-tr from-emerald-950/60 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 text-center space-y-2">
          <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 font-bold">
            THIS MONTH ({metrics.monthKey})
          </span>
          <div className="text-4xl font-extrabold text-white font-mono tracking-tight">
            {hoursSaved} Hours
          </div>
          <p className="text-xs font-semibold text-emerald-200 leading-relaxed pt-1">
            This app has saved you {hoursSaved} hours of manual tapping
          </p>
          <p className="text-[11px] text-slate-400 font-mono">
            ({metrics.monthlySecondsSaved}s • {minutesSaved} min total manual effort automated)
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Automated Tasks</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">{metrics.totalTasksCompleted}</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Taps Automated</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">{metrics.totalTapsAutomated}</div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-600/30 cursor-pointer"
        >
          Close Analytics
        </button>
      </div>
    </div>
  );
};
