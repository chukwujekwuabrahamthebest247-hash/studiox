/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Search,
  Plus,
  Monitor,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  RefreshCw,
  Server,
  Layers,
  Radio,
  ShieldCheck,
} from 'lucide-react';
import {
  dispatchOpenAuthModal,
  getAuthHeaders,
  subscribeToAuthChanges,
} from '../../utils/tokenQuotaManager';

export interface FleetSlotRecord {
  id: string;
  slotNumber: number;
  title: string;
  status: 'idle' | 'running' | 'paused' | 'completed' | 'hydrating';
  platform: 'android' | 'ios' | 'linux' | 'windows';
  region: string;
  workerNode: string;
  streamUrl?: string;
  webrtcUrl?: string;
  currentApp: string;
  currentTaskSummary: string;
  stepProgress: { current: number; total: number };
  memoryUsageMb: number;
  createdAt: string;
  updatedAt: string;
}

interface FleetStatusResponse {
  slots: FleetSlotRecord[];
  totalCount: number;
  runningCount: number;
  idleCount: number;
  hydratingCount: number;
  totalMemoryMb: number;
  page: number;
  limit: number;
  totalPages: number;
  storageMode: 'supabase' | 'json_file';
}

interface FleetGridViewProps {
  pinnedSlotIds: string[];
  maxPinnedViewports: number;
  onInspectLiveSlot: (slot: FleetSlotRecord) => void;
  onFleetSummaryChange?: (summary: {
    totalCount: number;
    runningCount: number;
    hydratingCount: number;
  }) => void;
}

const PAGE_LIMIT = 50;

export const FleetGridView: React.FC<FleetGridViewProps> = ({
  pinnedSlotIds,
  maxPinnedViewports,
  onInspectLiveSlot,
  onFleetSummaryChange,
}) => {
  const [page, setPage] = useState<number>(1);
  const [searchInput, setSearchInput] = useState<string>('');
  const [debouncedSearch, setDebouncedSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState<boolean>(true);
  const [fleetData, setFleetData] = useState<FleetStatusResponse | null>(null);
  const [spawnCount, setSpawnCount] = useState<number>(100);
  const [spawnPlatform, setSpawnPlatform] = useState<'android' | 'ios' | 'linux' | 'windows'>('android');
  const [isSpawning, setIsSpawning] = useState<boolean>(false);
  const [spawnNotice, setSpawnNotice] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Debounce search text
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setPage(1);
      setDebouncedSearch(searchInput.trim());
    }, 220);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const fetchFleetPage = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        page: String(page),
        limit: String(PAGE_LIMIT),
        status: statusFilter,
      });
      if (debouncedSearch) {
        qs.set('search', debouncedSearch);
      }
      const res = await fetch(`/api/fleet/status?${qs.toString()}`, {
        cache: 'no-store',
        headers: getAuthHeaders(),
      });
      if (res.status === 401 || res.status === 403 || res.status === 503) {
        const errJson = await res.json().catch(() => ({}));
        setAuthError(
          errJson?.error ||
            'Verified email or OAuth sign-in is required to view or spawn Cloud Fleet containers.'
        );
        setFleetData(null);
        return;
      }
      if (!res.ok) return;
      const json: FleetStatusResponse = await res.json();
      setAuthError(null);
      setFleetData(json);
      onFleetSummaryChange?.({
        totalCount: json.totalCount,
        runningCount: json.runningCount,
        hydratingCount: json.hydratingCount,
      });
    } catch (err) {
      console.warn('Fleet status load error:', err);
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter, debouncedSearch, onFleetSummaryChange]);

  useEffect(() => {
    void fetchFleetPage();
  }, [fetchFleetPage]);

  useEffect(() => {
    return subscribeToAuthChanges(() => {
      void fetchFleetPage();
    });
  }, [fetchFleetPage]);

  const handleBulkSpawn = async (overrideCount?: number) => {
    const countToSpawn = Math.max(1, Math.min(100_000, Math.round(overrideCount ?? spawnCount)));
    setIsSpawning(true);
    setSpawnNotice(null);
    try {
      const res = await fetch('/api/fleet/bulk-spawn', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          count: countToSpawn,
          platform: spawnPlatform,
          region: 'us-east-1',
          taskSummary: `Cloud ${spawnPlatform.toUpperCase()} worker pool ready for automation`,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401 || res.status === 403 || res.status === 503) {
        const msg =
          data?.error ||
          'Sign in and verify your email before spawning cloud container slots.';
        setAuthError(msg);
        setSpawnNotice(msg);
        dispatchOpenAuthModal();
        return;
      }
      if (!res.ok) {
        setSpawnNotice(data.error || 'Failed spawning cloud batch.');
        return;
      }
      setSpawnNotice(
        `Queued ${Number(data.spawnedCount || countToSpawn).toLocaleString()} ${spawnPlatform.toUpperCase()} slots via ${
          data.queueMode === 'redis_bullmq' ? 'BullMQ Worker' : 'Async Queue'
        } (Job ${data.jobId}).`
      );
      await fetchFleetPage();

      // Single follow-up refresh after async hydration finishes
      window.setTimeout(() => {
        void fetchFleetPage();
      }, 250);
    } catch (err: any) {
      setSpawnNotice(err?.message || 'Network error spawning fleet batch.');
    } finally {
      setIsSpawning(false);
    }
  };

  const slots = fleetData?.slots || [];
  const totalCount = fleetData?.totalCount || 0;
  const totalPages = fleetData?.totalPages || 1;
  const startRow = totalCount === 0 ? 0 : (page - 1) * PAGE_LIMIT + 1;
  const endRow = Math.min(totalCount, page * PAGE_LIMIT);

  return (
    <div className="h-full w-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden">
      {/* Top Toolbar & Fleet Summary Strip */}
      <div className="border-b border-slate-800 bg-slate-900/70 px-5 py-3 flex flex-col gap-3 shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span>FLEET CONTROL</span>
              <span>/</span>
              <span className="text-slate-200">PAGINATED CONTAINER REGISTRY</span>
            </div>
            <h1 className="text-base font-bold text-white tracking-tight mt-0.5">
              Cloud Slot Fleet Command ({totalCount.toLocaleString()} Provisioned)
            </h1>
          </div>

          {/* KPI Counters — Tabular Numerals, Unboxed Flat Dividers */}
          <div className="flex items-center gap-5 border border-slate-800 bg-slate-950/80 rounded-lg px-4 py-2 text-xs">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-400">
                Total Fleet
              </span>
              <span className="font-mono tabular-nums font-bold text-sm text-white">
                {totalCount.toLocaleString()}
              </span>
            </div>
            <div className="h-6 w-[1px] bg-slate-800" />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-400">
                Running
              </span>
              <span className="font-mono tabular-nums font-bold text-sm text-emerald-400">
                {(fleetData?.runningCount || 0).toLocaleString()}
              </span>
            </div>
            <div className="h-6 w-[1px] bg-slate-800" />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-400">
                Hydrating
              </span>
              <span className="font-mono tabular-nums font-bold text-sm text-amber-400">
                {(fleetData?.hydratingCount || 0).toLocaleString()}
              </span>
            </div>
            <div className="h-6 w-[1px] bg-slate-800" />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-400">
                Live Viewports Pinned
              </span>
              <span className="font-mono tabular-nums font-bold text-sm text-cyan-400">
                {pinnedSlotIds.length} / {maxPinnedViewports} Max
              </span>
            </div>
            <div className="h-6 w-[1px] bg-slate-800 hidden md:block" />
            <div className="hidden md:flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-400">
                Storage Tier
              </span>
              <span className="font-mono text-xs font-semibold text-slate-200 uppercase">
                {fleetData?.storageMode === 'supabase' ? 'Supabase PG' : 'Stateless Disk'}
              </span>
            </div>
          </div>
        </div>

        {/* Search, Status Filters, and Bulk Worker Provisioning */}
        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search slot #, ID, task, region..."
                className="pl-8 pr-3 py-1.5 w-64 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/70"
              />
            </div>

            {/* Segmented Status Tabs */}
            <div className="flex items-center border border-slate-800 bg-slate-950 rounded-lg p-0.5 text-xs">
              {(['all', 'running', 'idle', 'hydrating'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => {
                    setStatusFilter(st);
                    setPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-md capitalize font-medium transition cursor-pointer whitespace-nowrap shrink-0 ${
                    statusFilter === st
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => void fetchFleetPage()}
              disabled={loading}
              className="px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-xs text-slate-300 flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shrink-0"
              title="Refresh current page"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          {/* Bulk Worker Provisioner */}
          <div className="flex flex-wrap items-center gap-1.5">
            <select
              value={spawnPlatform}
              onChange={(e) => setSpawnPlatform(e.target.value as any)}
              className="px-2 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 font-medium focus:outline-none focus:border-emerald-500/70"
            >
              <option value="android">Android</option>
              <option value="ios">iOS</option>
              <option value="linux">Linux</option>
              <option value="windows">Windows</option>
            </select>

            {[10, 100, 1000, 10000].map((preset) => (
              <button
                key={preset}
                type="button"
                disabled={isSpawning}
                onClick={() => {
                  setSpawnCount(preset);
                  void handleBulkSpawn(preset);
                }}
                className="px-2 py-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-xs font-mono tabular-nums text-slate-300 hover:text-white transition cursor-pointer whitespace-nowrap shrink-0"
              >
                +{preset.toLocaleString()}
              </button>
            ))}

            <div className="flex items-center border border-slate-800 bg-slate-950 rounded-lg overflow-hidden">
              <input
                type="number"
                min={1}
                max={100000}
                value={spawnCount}
                onChange={(e) => setSpawnCount(Math.max(1, Math.min(100000, Number(e.target.value) || 1)))}
                className="w-20 px-2 py-1.5 bg-transparent text-xs font-mono tabular-nums text-white focus:outline-none"
              />
              <button
                type="button"
                disabled={isSpawning}
                onClick={() => void handleBulkSpawn()}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isSpawning ? 'Queueing...' : 'Bulk Spawn'}</span>
              </button>
            </div>
          </div>
        </div>

        {spawnNotice && (
          <div className="text-xs font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-800/70 rounded-lg px-3 py-1.5 flex items-center justify-between">
            <span>{spawnNotice}</span>
            <button
              type="button"
              onClick={() => setSpawnNotice(null)}
              className="text-slate-400 hover:text-white text-xs ml-3 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Windowed Paginated Table (Strictly 50 DOM Rows Max) */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead className="sticky top-0 z-10 bg-slate-900 border-b border-slate-800 text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
            <tr>
              <th className="py-2.5 px-4 w-24">Slot #</th>
              <th className="py-2.5 px-3">Container / Instance</th>
              <th className="py-2.5 px-3 w-28">Platform</th>
              <th className="py-2.5 px-3 w-40">Worker & Stream</th>
              <th className="py-2.5 px-3 w-28">Status</th>
              <th className="py-2.5 px-3 w-24 text-right">Step</th>
              <th className="py-2.5 px-3 w-24 text-right">Memory</th>
              <th className="py-2.5 px-4 w-44 text-right">Live Viewport</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/70">
            {authError ? (
              <tr>
                <td colSpan={8} className="py-16 text-center text-slate-300">
                  <div className="flex flex-col items-center gap-3 max-w-md mx-auto">
                    <ShieldCheck className="w-8 h-8 text-emerald-400" />
                    <p className="text-sm font-bold text-white">Verified Sign-In Required</p>
                    <p className="text-xs text-slate-400 leading-relaxed">{authError}</p>
                    <button
                      type="button"
                      onClick={dispatchOpenAuthModal}
                      className="mt-1 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Sign In & Verify Email / OAuth</span>
                    </button>
                  </div>
                </td>
              </tr>
            ) : loading && slots.length === 0 ? (
              Array.from({ length: 12 }).map((_, idx) => (
                <tr key={idx} className="h-10 bg-slate-950">
                  <td colSpan={8} className="px-4 py-2">
                    <div className="h-5 bg-slate-900 rounded animate-pulse w-full" />
                  </td>
                </tr>
              ))
            ) : slots.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-16 text-center text-slate-400">
                  <div className="flex flex-col items-center gap-2.5 max-w-sm mx-auto">
                    <Layers className="w-7 h-7 text-slate-500" />
                    <p className="text-sm font-semibold text-slate-200">
                      No matching cloud slots on this filter
                    </p>
                    <p className="text-xs text-slate-400">
                      Clear filters or spawn new background worker containers into the fleet registry.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchInput('');
                        setStatusFilter('all');
                        void handleBulkSpawn(50);
                      }}
                      className="mt-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Spawn +50 Slots</span>
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              slots.map((slot) => {
                const isPinned = pinnedSlotIds.includes(slot.id);
                const statusColor =
                  slot.status === 'running'
                    ? 'text-emerald-400'
                    : slot.status === 'hydrating'
                    ? 'text-amber-400'
                    : slot.status === 'paused'
                    ? 'text-cyan-400'
                    : 'text-slate-400';

                return (
                  <tr
                    key={slot.id}
                    className={`h-10 transition-colors ${
                      isPinned ? 'bg-emerald-950/20 hover:bg-emerald-950/30' : 'hover:bg-slate-900/70'
                    }`}
                  >
                    <td className="px-4 py-2 font-mono tabular-nums text-slate-300 font-semibold">
                      #{slot.slotNumber.toLocaleString()}
                    </td>
                    <td className="px-3 py-2 max-w-[320px]">
                      <div className="font-semibold text-slate-100 truncate">{slot.title}</div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {slot.currentTaskSummary}
                      </div>
                    </td>
                    <td className="px-3 py-2 font-mono text-slate-300 uppercase text-[11px]">
                      {slot.platform} • {slot.region}
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-slate-400">
                      <div className="flex items-center gap-1.5 truncate">
                        <Server className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="truncate">{slot.workerNode}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] text-slate-500 truncate">
                        <Radio className="w-2.5 h-2.5 shrink-0" />
                        <span className="truncate">
                          {slot.webrtcUrl
                            ? 'WebRTC Direct'
                            : slot.streamUrl
                            ? 'WebSocket Direct'
                            : 'Event Snapshot'}
                        </span>
                      </div>
                    </td>
                    <td className={`px-3 py-2 font-mono uppercase text-[11px] font-semibold ${statusColor}`}>
                      {slot.status}
                    </td>
                    <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-300">
                      {slot.stepProgress.current}/{slot.stepProgress.total}
                    </td>
                    <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-300">
                      {slot.memoryUsageMb.toFixed(1)} MB
                    </td>
                    <td className="px-4 py-2 text-right">
                      <button
                        type="button"
                        onClick={() => onInspectLiveSlot(slot)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shrink-0 ${
                          isPinned
                            ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        }`}
                      >
                        <Monitor className="w-3.5 h-3.5" />
                        <span>{isPinned ? 'Focus Live' : 'Inspect Live Screen'}</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="h-11 border-t border-slate-800 bg-slate-900/80 px-5 flex items-center justify-between text-xs shrink-0">
        <div className="text-slate-400 font-mono tabular-nums flex items-center gap-3">
          <span>
            Showing <strong className="text-slate-200">{startRow.toLocaleString()}</strong>–
            <strong className="text-slate-200">{endRow.toLocaleString()}</strong> of{' '}
            <strong className="text-white">{totalCount.toLocaleString()}</strong> slots
          </span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-500">
            DOM Cap: {PAGE_LIMIT} rows/page, {maxPinnedViewports} live viewports max
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={page <= 1 || loading}
            onClick={() => setPage(1)}
            className="p-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 disabled:opacity-40 text-slate-300 cursor-pointer"
            title="First page"
          >
            <ChevronsLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={page <= 1 || loading}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-2.5 py-1 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 disabled:opacity-40 text-slate-300 flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Prev</span>
          </button>
          <span className="px-2.5 font-mono tabular-nums text-slate-300">
            Page <strong className="text-white">{page.toLocaleString()}</strong> /{' '}
            {totalPages.toLocaleString()}
          </span>
          <button
            type="button"
            disabled={page >= totalPages || loading}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="px-2.5 py-1 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 disabled:opacity-40 text-slate-300 flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
          >
            <span>Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={page >= totalPages || loading}
            onClick={() => setPage(totalPages)}
            className="p-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 disabled:opacity-40 text-slate-300 cursor-pointer"
            title="Last page"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
