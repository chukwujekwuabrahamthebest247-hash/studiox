/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneAppType,
  SocialPost,
  FoodItem,
  CartItem,
  ContactThread,
  NoteItem,
  PhoneSettings,
  ObstacleState,
  TakeoverState,
  InstalledAppItem,
} from '../../types/phone';
import { AppSecurityProfile } from '../../types/securityAwareness';
import { InterruptedAutomationState } from '../../types/sandboxedApps';
import { SerperConfig, TavilyConfig } from '../modals/OpenRouterModal';
import { AppInstallerModal } from '../modals/AppInstallerModal';
import { ReviewModal } from '../modals/ReviewModal';
import { sounds } from '../../utils/soundEffects';
import {
  loadInstalledAppsFromVault,
  removeInstalledAppFromVault,
  saveAllInstalledAppsToVault,
  saveInstalledAppToVault,
} from '../../utils/browserFileVault';
import {
  CHROME_PROVIDER_META,
  InPhoneChromeChatEntry,
  InPhoneChromeConfig,
  InPhoneChromeProvider,
  clearInPhoneChromeFeed,
  getInPhoneChromeFeed,
  subscribeToInPhoneChromeFeed,
} from '../../utils/inPhoneChromeEngine';
import {
  Star,
  Apple,
  Sparkles,
  Download,
  Smartphone,
  Search,
  Heart,
  Bookmark,
  MessageCircle,
  Plus,
  Send,
  Trash2,
  Check,
  ChevronLeft,
  Moon,
  Sun,
  Wifi,
  Bluetooth,
  Battery,
  ShoppingBag,
  ExternalLink,
  Shield,
  FileText,
  AlertCircle,
  Play,
  RotateCcw,
  X,
  CreditCard,
  Briefcase,
  Grid,
  Lock,
  RotateCw,
  Home,
  Eye,
  Cpu,
  Chrome,
} from 'lucide-react';

interface PhoneDeviceProps {
  currentApp: PhoneAppType;
  onNavigateApp: (app: PhoneAppType) => void;
  cursorPos: { x: number; y: number };
  cursorVisible: boolean;
  cursorGesture: 'idle' | 'moving' | 'tapping' | 'swiping_up' | 'swiping_down' | 'typing';
  cursorLabel?: string;
  agentStatusText?: string;
  isAgentRunning: boolean;
  agentVisionMode: boolean;
  speed: number;
  socialPosts: SocialPost[];
  onToggleLike: (postId: string) => void;
  onToggleBookmark: (postId: string) => void;
  foodItems: FoodItem[];
  foodCart: CartItem[];
  onAddToCart: (item: FoodItem) => void;
  onUpdateCartQty: (itemId: string, delta: number) => void;
  onClearCart: () => void;
  foodSearchQuery: string;
  onFoodSearchChange: (q: string) => void;
  messageThreads: ContactThread[];
  activeMessageThreadId: string | null;
  onSelectMessageThread: (id: string | null) => void;
  onSendMessage: (threadId: string, text: string) => void;
  messageInputDraft: string;
  onMessageInputDraftChange: (d: string) => void;
  notes: NoteItem[];
  onSaveNote: (note: { title: string; content: string; category?: string }) => void;
  onDeleteNote: (id: string) => void;
  isCreatingNote: boolean;
  setIsCreatingNote: (val: boolean) => void;
  noteDraftTitle: string;
  setNoteDraftTitle: (val: string) => void;
  noteDraftBody: string;
  setNoteDraftBody: (val: string) => void;
  settings: PhoneSettings;
  onUpdateSettings: (settings: Partial<PhoneSettings>) => void;
  scrollRef: React.RefObject<HTMLDivElement | null>;
  phoneContainerRef: React.RefObject<HTMLDivElement | null>;
  screenCaptureRef: React.RefObject<HTMLDivElement | null>;
  currentTime: string;
  obstacle: ObstacleState | null;
  onDismissObstacle: () => void;
  takeoverState: TakeoverState;
  isSnappingScreenshot: boolean;
  serperConfig?: SerperConfig;
  tavilyConfig?: TavilyConfig;
  homeSearchQuery: string;
  onHomeSearchQueryChange: (q: string) => void;
  browserQuery: string;
  onBrowserSearchChange: (q: string) => void;
  selectedFoodCategory: string;
  onSelectFoodCategory: (cat: string) => void;
  selectedBrowserResultIndex: number | null;
  onSelectBrowserResultIndex: (idx: number | null) => void;
  onTakeScreenshotAndCheck?: () => void;
  securityProfile: AppSecurityProfile | null;
  isStatementExported: boolean;
  onExportStatement: () => void;
  isWeirdChargeFlagged: boolean;
  onFlagWeirdCharges: () => void;
  isQuickBooksInvoiceSent: boolean;
  onSendQuickBooksInvoice: () => void;
  interruptedAutomation: InterruptedAutomationState | null;
  onResumeInterruptedAutomation: () => void;
  onRestartInterruptedAutomation: () => void;
  onDismissInterruptedAutomation: () => void;
  onUserCollisionDetected: (app: string) => void;
  onAttemptUnauthorizedDownload: (app?: string) => void;
  instanceId?: string;
  inPhoneChromeConfig?: InPhoneChromeConfig;
  onUpdateInPhoneChromeConfig?: (config: InPhoneChromeConfig) => void;
  onChromeInstalledChange?: (installed: boolean) => void;
  installAndLaunchChromeTrigger?: number;
  onSubmitPromptFromChrome?: (prompt: string) => void;
  onInstalledAppsChange?: (apps: InstalledAppItem[]) => void;
  onPlatformChange?: (platform: 'android' | 'ios') => void;
  streamUrl?: string;
  webrtcUrl?: string;
  missingAppPrompt?: {
    appName: string;
    storeQuery?: string;
    icon?: string;
    originalPrompt: string;
  } | null;
  onDownloadMissingApp?: (appName: string, originalPrompt: string) => void;
  onDismissMissingApp?: () => void;
  externalInstallerOpenRequest?: { appName: string; nonce: number } | null;
  onAppInstalledNotify?: (app: InstalledAppItem) => void;
  onOpenBillingModal?: () => void;
}

export const MAX_INSTALLED_APPS = 40;

const DEFAULT_INSTALLED_APPS: InstalledAppItem[] = [
  {
    id: 'chrome',
    packageName: 'com.android.chrome',
    name: 'Chrome',
    icon: '🌐',
    bg: 'from-blue-500 via-emerald-500 to-amber-500',
    packageType: 'apk',
    platform: 'both',
    size: '68.4 MB',
    version: 'v131.0',
    description:
      'Google Chrome mobile browser with integrated In-Phone AI Web Session Engine (Gemini Web, ChatGPT Web, Claude Web).',
    isCustom: false,
  },
  {
    id: 'whatsapp',
    packageName: 'com.whatsapp',
    name: 'WhatsApp',
    icon: '💬',
    bg: 'from-emerald-500 to-green-600',
    packageType: 'apk',
    platform: 'both',
    size: '42.6 MB',
    version: 'v2.24.8',
    description: 'End-to-end encrypted messaging, voice calls, and media sharing.',
    isCustom: false,
  },
  {
    id: 'telegram',
    packageName: 'org.telegram.messenger',
    name: 'Telegram',
    icon: '✈️',
    bg: 'from-sky-400 to-blue-600',
    packageType: 'apk',
    platform: 'both',
    size: '48.1 MB',
    version: 'v10.9.1',
    description: 'Fast, secure cloud messaging and broadcast channels.',
    isCustom: false,
  },
];

const BUILTIN_SIMULATOR_VIEWS = new Set([
  'home',
  'food',
  'social',
  'messages',
  'notes',
  'browser',
  'chrome',
  'banking',
  'quickbooks',
  'settings',
]);

export const PhoneDevice: React.FC<PhoneDeviceProps> = ({
  currentApp,
  onNavigateApp,
  cursorPos,
  cursorVisible,
  cursorGesture,
  cursorLabel,
  agentStatusText,
  isAgentRunning,
  agentVisionMode,
  speed,
  socialPosts,
  onToggleLike,
  onToggleBookmark,
  foodItems,
  foodCart,
  onAddToCart,
  onUpdateCartQty,
  onClearCart,
  foodSearchQuery,
  onFoodSearchChange,
  messageThreads,
  activeMessageThreadId,
  onSelectMessageThread,
  onSendMessage,
  messageInputDraft,
  onMessageInputDraftChange,
  notes,
  onSaveNote,
  onDeleteNote,
  isCreatingNote,
  setIsCreatingNote,
  noteDraftTitle,
  setNoteDraftTitle,
  noteDraftBody,
  setNoteDraftBody,
  settings,
  onUpdateSettings,
  scrollRef,
  phoneContainerRef,
  screenCaptureRef,
  currentTime,
  obstacle,
  onDismissObstacle,
  takeoverState,
  isSnappingScreenshot,
  homeSearchQuery,
  onHomeSearchQueryChange,
  browserQuery,
  onBrowserSearchChange,
  selectedFoodCategory,
  onSelectFoodCategory,
  selectedBrowserResultIndex,
  onSelectBrowserResultIndex,
  securityProfile,
  isStatementExported,
  onExportStatement,
  isWeirdChargeFlagged,
  onFlagWeirdCharges,
  isQuickBooksInvoiceSent,
  onSendQuickBooksInvoice,
  interruptedAutomation,
  onResumeInterruptedAutomation,
  onRestartInterruptedAutomation,
  onDismissInterruptedAutomation,
  onUserCollisionDetected,
  instanceId = 'slot-1',
  inPhoneChromeConfig,
  onUpdateInPhoneChromeConfig,
  onChromeInstalledChange,
  installAndLaunchChromeTrigger = 0,
  onSubmitPromptFromChrome,
  onInstalledAppsChange,
  onPlatformChange,
  streamUrl: propStreamUrl,
  webrtcUrl: propWebrtcUrl,
  missingAppPrompt = null,
  onDownloadMissingApp,
  onDismissMissingApp,
  externalInstallerOpenRequest = null,
  onAppInstalledNotify,
  onOpenBillingModal,
}) => {
  const [phonePlatform, setPhonePlatform] = useState<'android' | 'ios'>('android');
  const [platformToast, setPlatformToast] = useState<string | null>(null);
  const [installedApps, setInstalledApps] = useState<InstalledAppItem[]>(DEFAULT_INSTALLED_APPS);
  const vaultLoadedRef = useRef(false);
  const [isInstallerModalOpen, setIsInstallerModalOpen] = useState(false);
  const [installerInitialSearchQuery, setInstallerInitialSearchQuery] = useState<string | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [chromePromptDraft, setChromePromptDraft] = useState('');
  const [chromeFeed, setChromeFeed] = useState<InPhoneChromeChatEntry[]>(() =>
    getInPhoneChromeFeed(instanceId)
  );
  const chromeFeedEndRef = useRef<HTMLDivElement | null>(null);
  const activeThread = messageThreads.find((t) => t.id === activeMessageThreadId);

  // Sync external missing-app install requests directly to the Play Store / App Store modal
  const lastExternalInstallerNonceRef = useRef<number>(0);
  useEffect(() => {
    if (
      externalInstallerOpenRequest &&
      externalInstallerOpenRequest.nonce > lastExternalInstallerNonceRef.current
    ) {
      lastExternalInstallerNonceRef.current = externalInstallerOpenRequest.nonce;
      setInstallerInitialSearchQuery(externalInstallerOpenRequest.appName);
      setIsInstallerModalOpen(true);
    }
  }, [externalInstallerOpenRequest]);

  // Real Live Container Viewport State (Android ADB / Redroid OR Hybrid iOS WebKit / Xcode)
  const [liveScreenUrl, setLiveScreenUrl] = useState<string | null>(null);
  const liveScreenUrlRef = useRef<string | null>(null);
  const [liveScreenSize, setLiveScreenSize] = useState<{ width: number; height: number }>({
    width: 1080,
    height: 1920,
  });
  const [liveContainerStatus, setLiveContainerStatus] = useState<
    'idle' | 'launching' | 'connected' | 'offline'
  >('idle');
  const [liveContainerMessage, setLiveContainerMessage] = useState<string | null>(null);
  const [liveDockerHint, setLiveDockerHint] = useState<string | null>(null);
  const [liveIosEngineLabel, setLiveIosEngineLabel] = useState<string>(
    'iOS WebKit Engine (Free Cloud)'
  );
  const [liveIosCurrentUrl, setLiveIosCurrentUrl] = useState<string | null>(null);
  const [liveInputDraft, setLiveInputDraft] = useState('');
  const [liveRetryNonce, setLiveRetryNonce] = useState(0);
  const [liveTapMarker, setLiveTapMarker] = useState<{ xPct: number; yPct: number } | null>(null);
  const [directStreamTransport, setDirectStreamTransport] = useState<'none' | 'webrtc' | 'websocket'>('none');
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const liveCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const isRealContainerAppActive = !BUILTIN_SIMULATOR_VIEWS.has(currentApp);
  const activeInstalledApp = installedApps.find((a) => a.id === currentApp);
  const isActiveAppIos =
    isRealContainerAppActive &&
    (phonePlatform === 'ios' ||
      activeInstalledApp?.packageType === 'ipa' ||
      activeInstalledApp?.platform === 'ios');
  const activeAdbPackageName =
    activeInstalledApp?.packageName ||
    (currentApp.includes('.') ? currentApp : undefined);
  const activeIosBundleId =
    activeInstalledApp?.bundleId ||
    (isActiveAppIos ? currentApp : undefined);

  const fetchLiveScreenFrame = async (iosMode: boolean): Promise<boolean> => {
    try {
      const endpoint = iosMode ? `/api/ios/screen?t=${Date.now()}` : `/api/adb/screen?t=${Date.now()}`;
      const res = await fetch(endpoint, { cache: 'no-store' });
      if (!res.ok) {
        let errJson: any = {};
        try {
          errJson = await res.json();
        } catch {}
        setLiveContainerStatus('offline');
        setLiveContainerMessage(
          errJson.error ||
            `${iosMode ? 'iOS' : 'ADB'} screen capture unavailable (HTTP ${res.status}).`
        );
        if (errJson.dockerHint) setLiveDockerHint(errJson.dockerHint);
        if (errJson.engineLabel) setLiveIosEngineLabel(errJson.engineLabel);
        return false;
      }

      const w = parseInt(res.headers.get('X-Screen-Width') || '0', 10);
      const h = parseInt(res.headers.get('X-Screen-Height') || '0', 10);
      if (w > 0 && h > 0) {
        setLiveScreenSize({ width: w, height: h });
      } else if (iosMode) {
        setLiveScreenSize({ width: 393, height: 852 });
      }

      if (iosMode) {
        const engineHeader = res.headers.get('X-iOS-Engine');
        if (engineHeader === 'xcode_simulator') {
          setLiveIosEngineLabel('Native Xcode Simulator (Mac Host)');
        } else if (engineHeader === 'webkit_linux') {
          setLiveIosEngineLabel('iOS WebKit Engine (Free Cloud)');
        }
        const iosUrlHeader = res.headers.get('X-iOS-URL');
        if (iosUrlHeader) {
          try {
            setLiveIosCurrentUrl(decodeURIComponent(iosUrlHeader));
          } catch {}
        }
      }

      const blob = await res.blob();
      const nextUrl = URL.createObjectURL(blob);
      const prevUrl = liveScreenUrlRef.current;
      liveScreenUrlRef.current = nextUrl;
      setLiveScreenUrl(nextUrl);
      if (prevUrl) {
        URL.revokeObjectURL(prevUrl);
      }
      setLiveContainerStatus('connected');
      setLiveContainerMessage(null);
      setLiveDockerHint(null);
      return true;
    } catch (err: any) {
      setLiveContainerStatus('offline');
      setLiveContainerMessage(
        err?.message ||
          `Failed reaching backend ${iosMode ? '/api/ios/screen' : '/api/adb/screen'} endpoint.`
      );
      return false;
    }
  };

  const activeDirectWebrtcUrl = activeInstalledApp?.webrtcUrl || propWebrtcUrl;
  const activeDirectStreamUrl = activeInstalledApp?.streamUrl || propStreamUrl;

  // Direct WebRTC / WebSocket stream connection OR event-driven single-frame snapshot (zero polling loop)
  useEffect(() => {
    if (!isRealContainerAppActive) {
      setLiveContainerStatus('idle');
      setDirectStreamTransport('none');
      return;
    }

    let cancelled = false;
    let peerConn: RTCPeerConnection | null = null;
    let wsConn: WebSocket | null = null;

    const connectDirectWebRtc = async (endpointUrl: string): Promise<boolean> => {
      if (typeof RTCPeerConnection === 'undefined') return false;
      try {
        peerConn = new RTCPeerConnection({
          iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
        });
        peerConn.addTransceiver('video', { direction: 'recvonly' });
        peerConn.ontrack = (ev) => {
          if (cancelled || !liveVideoRef.current) return;
          const stream = ev.streams?.[0] || new MediaStream([ev.track]);
          liveVideoRef.current.srcObject = stream;
          void liveVideoRef.current.play().catch(() => {});
          setDirectStreamTransport('webrtc');
          setLiveContainerStatus('connected');
          setLiveContainerMessage(null);
        };

        const offer = await peerConn.createOffer();
        await peerConn.setLocalDescription(offer);
        const res = await fetch(endpointUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/sdp' },
          body: offer.sdp,
        });
        if (!res.ok) throw new Error(`WebRTC signaling HTTP ${res.status}`);
        const answerSdp = await res.text();
        if (!cancelled && peerConn) {
          await peerConn.setRemoteDescription({ type: 'answer', sdp: answerSdp });
          return true;
        }
      } catch (err) {
        console.warn('[WebRTC] Direct stream unavailable, checking fallback:', err);
        peerConn?.close();
        peerConn = null;
      }
      return false;
    };

    const connectDirectWebSocket = (wsUrl: string): boolean => {
      try {
        wsConn = new WebSocket(wsUrl);
        wsConn.binaryType = 'blob';
        wsConn.onopen = () => {
          if (cancelled) return;
          setDirectStreamTransport('websocket');
          setLiveContainerStatus('connected');
          setLiveContainerMessage(null);
        };
        wsConn.onmessage = async (event) => {
          if (cancelled || !liveCanvasRef.current) return;
          if (event.data instanceof Blob) {
            const bitmap = await createImageBitmap(event.data).catch(() => null);
            if (!bitmap || !liveCanvasRef.current || cancelled) return;
            const canvas = liveCanvasRef.current;
            if (canvas.width !== bitmap.width || canvas.height !== bitmap.height) {
              canvas.width = bitmap.width;
              canvas.height = bitmap.height;
              setLiveScreenSize({ width: bitmap.width, height: bitmap.height });
            }
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(bitmap, 0, 0);
            bitmap.close();
          }
        };
        wsConn.onerror = () => {
          if (!cancelled && directStreamTransport === 'none') {
            void fetchLiveScreenFrame(isActiveAppIos);
          }
        };
        return true;
      } catch {
        return false;
      }
    };

    const startContainerSession = async () => {
      setLiveContainerStatus('launching');
      setDirectStreamTransport('none');
      setLiveDockerHint(null);

      // 1. Direct WebRTC (<video>) stream if container worker provides a signaling/WHEP URL
      if (activeDirectWebrtcUrl && /^https?:\/\//i.test(activeDirectWebrtcUrl)) {
        const ok = await connectDirectWebRtc(activeDirectWebrtcUrl);
        if (ok || cancelled) return;
      }

      // 2. Direct Binary WebSocket (<canvas>) stream if container worker provides a ws:// / wss:// URL
      if (activeDirectStreamUrl && /^wss?:\/\//i.test(activeDirectStreamUrl)) {
        const connectedWs = connectDirectWebSocket(activeDirectStreamUrl);
        if (connectedWs) return;
      }

      if (isActiveAppIos) {
        setLiveScreenSize({ width: 393, height: 852 });
        if (activeInstalledApp?.iosEngineLabel) {
          setLiveIosEngineLabel(activeInstalledApp.iosEngineLabel);
        }
        setLiveContainerMessage(
          `Launching ${activeInstalledApp?.name || currentApp} inside iOS Engine...`
        );

        try {
          const launchRes = await fetch('/api/ios/launch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              bundleId: activeIosBundleId,
              launchUrl: activeInstalledApp?.launchUrl,
              appName: activeInstalledApp?.name || currentApp,
            }),
          });
          const launchJson = await launchRes.json().catch(() => ({}));
          if (!launchRes.ok && !cancelled) {
            setLiveContainerStatus('offline');
            setLiveContainerMessage(
              launchJson.error || `Failed to launch iOS app (HTTP ${launchRes.status}).`
            );
            if (launchJson.engineLabel) setLiveIosEngineLabel(launchJson.engineLabel);
            return;
          }
          if (!cancelled) {
            if (launchJson.engineLabel) setLiveIosEngineLabel(launchJson.engineLabel);
            if (launchJson.launchUrl) setLiveIosCurrentUrl(launchJson.launchUrl);
          }
        } catch (err: any) {
          if (!cancelled) {
            setLiveContainerStatus('offline');
            setLiveContainerMessage(err?.message || 'Network error calling /api/ios/launch.');
          }
          return;
        }
      } else {
        setLiveScreenSize({ width: 1080, height: 1920 });
        setLiveContainerMessage(
          activeAdbPackageName
            ? `Launching ${activeAdbPackageName} via ADB...`
            : 'Connecting to live Android container screen...'
        );

        if (activeAdbPackageName) {
          try {
            const launchRes = await fetch('/api/adb/launch', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ packageName: activeAdbPackageName }),
            });
            if (!launchRes.ok && !cancelled) {
              let launchErr: any = {};
              try {
                launchErr = await launchRes.json();
              } catch {}
              setLiveContainerStatus('offline');
              setLiveContainerMessage(
                launchErr.error ||
                  `Failed to launch ${activeAdbPackageName} (HTTP ${launchRes.status}).`
              );
              if (launchErr.dockerHint) setLiveDockerHint(launchErr.dockerHint);
              return;
            }
          } catch (err: any) {
            if (!cancelled) {
              setLiveContainerStatus('offline');
              setLiveContainerMessage(err?.message || 'Network error calling /api/adb/launch.');
            }
            return;
          }
        }
      }

      // Event-driven single frame capture on launch (no 450ms/550ms polling loop)
      if (!cancelled) {
        await fetchLiveScreenFrame(isActiveAppIos);
      }
    };

    void startContainerSession();

    return () => {
      cancelled = true;
      if (peerConn) {
        peerConn.close();
        peerConn = null;
      }
      if (wsConn) {
        wsConn.close();
        wsConn = null;
      }
      if (liveScreenUrlRef.current) {
        URL.revokeObjectURL(liveScreenUrlRef.current);
        liveScreenUrlRef.current = null;
        setLiveScreenUrl(null);
      }
    };
  }, [
    isRealContainerAppActive,
    isActiveAppIos,
    currentApp,
    activeAdbPackageName,
    activeIosBundleId,
    activeInstalledApp?.launchUrl,
    activeInstalledApp?.name,
    activeInstalledApp?.iosEngineLabel,
    activeDirectWebrtcUrl,
    activeDirectStreamUrl,
    liveRetryNonce,
  ]);

  const sendLiveInputCommand = async (payload: Record<string, unknown>) => {
    const endpoint = isActiveAppIos ? '/api/ios/input' : '/api/adb/input';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setLiveContainerStatus('offline');
        setLiveContainerMessage(
          errData.error || `${isActiveAppIos ? 'iOS' : 'ADB'} input error (HTTP ${res.status}).`
        );
        if (errData.dockerHint) setLiveDockerHint(errData.dockerHint);
        return;
      }
      await fetchLiveScreenFrame(isActiveAppIos);
    } catch (err: any) {
      setLiveContainerStatus('offline');
      setLiveContainerMessage(
        err?.message || `Failed sending ${isActiveAppIos ? 'iOS' : 'ADB'} input.`
      );
    }
  };

  // Sync live In-Phone Chrome chat feed
  useEffect(() => {
    setChromeFeed(getInPhoneChromeFeed(instanceId));
    const unsub = subscribeToInPhoneChromeFeed(() => {
      setChromeFeed(getInPhoneChromeFeed(instanceId));
    });
    return () => unsub();
  }, [instanceId]);

  useEffect(() => {
    if (currentApp === 'chrome' && chromeFeedEndRef.current) {
      chromeFeedEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chromeFeed.length, currentApp]);

  // Hydrate persisted installed apps from Browser IndexedDB Vault on mount
  useEffect(() => {
    let active = true;
    loadInstalledAppsFromVault().then((persistedApps) => {
      if (!active) return;
      vaultLoadedRef.current = true;
      if (persistedApps === null) {
        saveAllInstalledAppsToVault(DEFAULT_INSTALLED_APPS);
      } else {
        setInstalledApps(persistedApps.slice(0, MAX_INSTALLED_APPS));
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // Notify parent when Chrome or installed apps list changes
  const isChromeInstalled = installedApps.some((a) => a.id === 'chrome');
  useEffect(() => {
    onChromeInstalledChange?.(isChromeInstalled);
    onInstalledAppsChange?.(installedApps);
  }, [isChromeInstalled, installedApps, onChromeInstalledChange, onInstalledAppsChange]);

  // Handle 1-click "Install & Launch Chrome on Phone" trigger from parent/OpenRouterModal
  const lastLaunchTriggerRef = useRef(installAndLaunchChromeTrigger);
  useEffect(() => {
    if (installAndLaunchChromeTrigger > lastLaunchTriggerRef.current) {
      lastLaunchTriggerRef.current = installAndLaunchChromeTrigger;
      setInstalledApps((prev) => {
        if (prev.some((a) => a.id === 'chrome')) return prev;
        if (prev.length >= MAX_INSTALLED_APPS) {
          setPlatformToast(`Storage limit reached (${MAX_INSTALLED_APPS}/${MAX_INSTALLED_APPS}). Uninstall an app to install Chrome.`);
          return prev;
        }
        const chromeApp: InstalledAppItem = {
          id: 'chrome',
          name: 'Chrome',
          icon: '🌐',
          bg: 'from-blue-500 via-emerald-500 to-amber-500',
          packageType: phonePlatform === 'ios' ? 'ipa' : 'apk',
          platform: 'both',
          size: '68.4 MB',
          version: 'v131.0',
          description: 'Google Chrome mobile browser with integrated In-Phone AI Web Session Engine.',
          isCustom: false,
          installedAt: new Date().toISOString(),
        };
        void saveInstalledAppToVault(chromeApp);
        return [chromeApp, ...prev].slice(0, MAX_INSTALLED_APPS);
      });
      onNavigateApp('chrome');
    }
  }, [installAndLaunchChromeTrigger, phonePlatform, onNavigateApp]);

  // Platform switcher: when switching, uninstall all apps incompatible with the selected platform
  const handlePlatformChange = (newPlatform: 'android' | 'ios') => {
    if (newPlatform === phonePlatform) return;
    setPhonePlatform(newPlatform);
    onPlatformChange?.(newPlatform);

    let uninstalledCount = 0;
    setInstalledApps((prev) => {
      const kept = prev.filter((app) => {
        if (app.platform === 'both') return true;
        const isCompatible =
          newPlatform === 'android'
            ? app.platform === 'android' || app.packageType === 'apk'
            : app.platform === 'ios' || app.packageType === 'ipa';
        if (!isCompatible) uninstalledCount++;
        return isCompatible;
      });
      void saveAllInstalledAppsToVault(kept);
      return kept;
    });

    // If active running app was removed, navigate back to home
    if (typeof currentApp === 'string' && currentApp !== 'home') {
      const running = installedApps.find((a) => a.id === currentApp);
      if (running) {
        const isIncompatible =
          newPlatform === 'android'
            ? running.platform === 'ios' || running.packageType === 'ipa'
            : running.platform === 'android' || running.packageType === 'apk';
        if (isIncompatible) {
          onNavigateApp('home');
        }
      }
    }

    const toastMsg =
      newPlatform === 'android'
        ? `Switched to Android (APK). ${uninstalledCount > 0 ? `${uninstalledCount} incompatible iOS app(s) uninstalled.` : 'Ready.'}`
        : `Switched to Apple iOS (IPA). ${uninstalledCount > 0 ? `${uninstalledCount} incompatible Android app(s) uninstalled.` : 'Ready.'}`;
    setPlatformToast(toastMsg);
    setTimeout(() => setPlatformToast(null), 3500);
    sounds.playSuccess();
  };

  return (
    <div className="relative w-full max-w-[390px] h-[740px] select-none flex flex-col items-center">
      {/* Smartphone Outer Hardware Shell */}
      <div
        ref={phoneContainerRef}
        className="relative w-full h-full bg-slate-950 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800/80 border-[5px] border-slate-800 flex flex-col overflow-hidden"
      >
        {/* Screen Bezel & Dynamic Island Area */}
        <div
          ref={screenCaptureRef}
          className={`relative w-full h-full rounded-[40px] flex flex-col overflow-hidden transition-colors duration-300 ${
            settings.darkMode ? 'bg-slate-900 text-slate-100' : 'bg-slate-100 text-slate-900'
          }`}
        >
          {/* Top Status Bar */}
          <div className="h-10 px-6 pt-2 flex items-center justify-between text-xs font-semibold z-20 shrink-0">
            <span className="font-mono">{currentTime}</span>
            {/* Dynamic Island Pill */}
            <div className="w-24 h-5 bg-black rounded-full flex items-center justify-center gap-1.5 px-2">
              <span className="w-2 h-2 rounded-full bg-slate-900 ring-1 ring-slate-700/80" />
              {isAgentRunning && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </div>
            <div className="flex items-center gap-1.5 text-[11px]">
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>

          {/* Screenshot Flash animation overlay */}
          {isSnappingScreenshot && (
            <div className="absolute inset-0 bg-white/30 z-40 pointer-events-none transition-opacity duration-75" />
          )}

          {/* Interrupted Automation Yield Notice */}
          {interruptedAutomation && (
            <div className="absolute top-11 left-3 right-3 z-30 bg-amber-500/95 text-slate-950 p-2.5 rounded-2xl shadow-xl flex items-center justify-between text-xs font-semibold">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span className="line-clamp-1">AI Yielded Control to You</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={onResumeInterruptedAutomation}
                  className="px-2 py-1 bg-slate-950 text-white rounded-lg text-[10px] font-bold flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Resume</span>
                </button>
                <button
                  onClick={onDismissInterruptedAutomation}
                  className="p-1 hover:bg-black/10 rounded-lg text-slate-950"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Missing App Auto-Detection Phone Screen Card */}
          {missingAppPrompt && (
            <div className="absolute inset-0 z-30 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-5">
              <div className="bg-slate-900 border border-amber-500/50 rounded-3xl p-4 shadow-2xl max-w-xs w-full space-y-3 text-left">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-lg shrink-0">
                      {missingAppPrompt.icon || '📦'}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-xs text-amber-300 leading-tight">
                        Missing App Detected: Download {missingAppPrompt.appName}
                      </h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {phonePlatform === 'ios' ? 'Apple App Store (iOS)' : 'Google Play Store (Android)'}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onDismissMissingApp}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer shrink-0"
                    title="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  <strong>{missingAppPrompt.appName}</strong> is not installed on this device yet. Install it to automatically resume your prompt.
                </p>

                <button
                  type="button"
                  data-agent-target="btn-phone-download-missing-app"
                  onClick={() => {
                    sounds.playTap();
                    if (onDownloadMissingApp) {
                      onDownloadMissingApp(
                        missingAppPrompt.storeQuery || missingAppPrompt.appName,
                        missingAppPrompt.originalPrompt
                      );
                    } else {
                      setInstallerInitialSearchQuery(
                        missingAppPrompt.storeQuery || missingAppPrompt.appName
                      );
                      setIsInstallerModalOpen(true);
                    }
                  }}
                  className={`w-full py-2.5 px-3 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-lg whitespace-nowrap ${
                    phonePlatform === 'ios'
                      ? 'bg-blue-600 hover:bg-blue-500'
                      : 'bg-emerald-600 hover:bg-emerald-500'
                  }`}
                >
                  <Download className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    Download Now ({phonePlatform === 'ios' ? 'App Store' : 'Play Store'})
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* Obstacle Dialog Overlay */}
          {obstacle?.active && (
            <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-xs flex items-center justify-center p-6">
              <div className="bg-slate-900 border border-slate-700 rounded-3xl p-5 text-center shadow-2xl max-w-xs w-full space-y-3">
                <div className="w-10 h-10 mx-auto rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <AlertCircle className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-white">{obstacle.title}</h4>
                <p className="text-xs text-slate-400">{obstacle.message}</p>
                <button
                  onClick={onDismissObstacle}
                  data-agent-target="dismiss-obstacle-btn"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition"
                >
                  {obstacle.actionLabel}
                </button>
              </div>
            </div>
          )}

          {/* App Viewport Container */}
          <div
            ref={scrollRef}
            data-scroll-container="true"
            className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col"
          >
            {/* 1. HOME APP */}
            {currentApp === 'home' && (
              <div className="flex-1 px-6 pt-4 pb-4 flex flex-col justify-between overflow-y-auto">
                <div className="space-y-4">
                  {/* Platform Selector Switch (Android vs iOS) */}
                  <div className="flex items-center justify-between gap-1.5 bg-slate-950/70 p-1.5 rounded-2xl border border-slate-800 shadow-xs">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        data-agent-target="toggle-platform-android"
                        onClick={() => handlePlatformChange('android')}
                        className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                          phonePlatform === 'android'
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                        title="Switch to Android (APK) mode"
                      >
                        <Smartphone className="w-3 h-3 text-emerald-300" />
                        <span>Android</span>
                      </button>
                      <button
                        type="button"
                        data-agent-target="toggle-platform-ios"
                        onClick={() => handlePlatformChange('ios')}
                        className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                          phonePlatform === 'ios'
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                        title="Switch to Apple iOS (IPA) mode"
                      >
                        <Apple className="w-3 h-3 text-blue-300" />
                        <span>iOS</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[9px] font-mono px-2 py-0.5 rounded-xl font-bold border ${
                          installedApps.length >= MAX_INSTALLED_APPS
                            ? 'bg-rose-950/80 text-rose-300 border-rose-500/60 animate-pulse'
                            : installedApps.length >= MAX_INSTALLED_APPS - 5
                            ? 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                            : 'bg-slate-900 text-slate-400 border-slate-800'
                        }`}
                        title={`Installed apps: ${installedApps.length} of ${MAX_INSTALLED_APPS} maximum limit`}
                      >
                        {installedApps.length}/{MAX_INSTALLED_APPS} Apps
                      </span>

                      <button
                        type="button"
                        data-agent-target="btn-get-apps-shortcut"
                        onClick={() => setIsInstallerModalOpen(true)}
                        className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 border transition cursor-pointer ${
                          phonePlatform === 'android'
                            ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60'
                            : 'bg-blue-950/60 border-blue-500/50 text-blue-300 hover:bg-blue-900/60'
                        }`}
                        title="Open Official App Store and download apps"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Get Apps</span>
                      </button>
                    </div>
                  </div>

                  {/* Platform Switch Status Notification Toast */}
                  {platformToast && (
                    <div className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 text-slate-200 text-[10px] font-medium flex items-center gap-1.5 animate-in fade-in">
                      <Check className="w-3 h-3 text-emerald-400 shrink-0" />
                      <span className="truncate">{platformToast}</span>
                    </div>
                  )}

                  {/* OmniSearch Bar */}
                  <div
                    data-agent-target="home-omnisearch-input"
                    className="flex items-center gap-2.5 bg-slate-800/80 px-4 py-2.5 rounded-2xl border border-slate-700/60 shadow-xs"
                  >
                    <Search className="w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={homeSearchQuery}
                      onChange={(e) => onHomeSearchQueryChange(e.target.value)}
                      placeholder="Search apps, web, & contacts..."
                      className="bg-transparent border-none text-xs w-full focus:outline-hidden text-white placeholder-slate-400"
                    />
                  </div>

                  {/* Sandbox Demo Apps Header */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">
                      Sandbox Demo Apps
                    </span>
                    <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-slate-800/90 text-slate-400 border border-slate-700/80">
                      Built-in React Simulators
                    </span>
                  </div>

                  {/* Built-in Sandbox Demo App Grid */}
                  <div className="grid grid-cols-4 gap-x-6 gap-y-5">
                    {[
                      { id: 'food', name: 'BiteDash', icon: '🍕', bg: 'from-orange-500 to-amber-500' },
                      { id: 'social', name: 'Pulse', icon: '📸', bg: 'from-pink-500 to-rose-500' },
                      { id: 'messages', name: 'Messages', icon: '💬', bg: 'from-emerald-500 to-teal-500' },
                      { id: 'notes', name: 'Notes', icon: '📝', bg: 'from-yellow-500 to-amber-500' },
                      { id: 'browser', name: 'SearchGlobe', icon: '🌐', bg: 'from-cyan-500 to-blue-500' },
                      { id: 'banking', name: 'Apex Bank', icon: '🏦', bg: 'from-indigo-500 to-violet-500' },
                      { id: 'quickbooks', name: 'QuickBooks', icon: '💼', bg: 'from-emerald-600 to-green-600' },
                      { id: 'settings', name: 'Settings', icon: '⚙️', bg: 'from-slate-600 to-slate-700' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        data-agent-target={`app-icon-${item.id}`}
                        onClick={() => {
                          onUserCollisionDetected(item.id);
                          onNavigateApp(item.id as PhoneAppType);
                        }}
                        title={`${item.name} (Sandbox Demo App)`}
                        className="flex flex-col items-center gap-1.5 group cursor-pointer relative"
                      >
                        <div
                          className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${item.bg} flex items-center justify-center text-xl shadow-md group-hover:scale-105 active:scale-95 transition relative`}
                        >
                          {item.icon}
                          <span className="absolute -top-1 -right-1 px-1 py-0.2 rounded-md text-[6.5px] font-mono font-bold uppercase bg-slate-900/95 text-slate-300 border border-slate-600">
                            DEMO
                          </span>
                        </div>
                        <span className="text-[10.5px] font-medium text-slate-300 group-hover:text-white transition tracking-tight text-center max-w-[64px] truncate">
                          {item.name}
                        </span>
                      </button>
                    ))}
                  </div>

                  {/* Installed Real Android / iOS Apps Section */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/70">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-emerald-400">
                      {phonePlatform === 'ios' ? 'Real iOS / WebKit Apps' : 'Real Android / APK Apps'}
                    </span>
                    <span className="text-[8px] font-mono text-slate-400">
                      {installedApps.length} installed
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-x-6 gap-y-5">
                    {/* Installed / Sideloaded Apps (APK or IPA) */}
                    {installedApps.map((item) => (
                      <button
                        key={item.id}
                        data-agent-target={`app-icon-${item.id}`}
                        onClick={() => {
                          onUserCollisionDetected(item.id);
                          onNavigateApp(item.id as PhoneAppType);
                        }}
                        className="flex flex-col items-center gap-1.5 group cursor-pointer relative"
                        title={`${item.name} (${(item.packageType || 'apk').toUpperCase()})`}
                      >
                        <div
                          className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${item.bg} flex items-center justify-center text-xl shadow-md group-hover:scale-105 active:scale-95 transition relative`}
                        >
                          {item.icon}
                          <span
                            className={`absolute -top-1 -right-1 px-1 py-0.2 rounded-md text-[7px] font-mono font-black uppercase shadow-xs ${
                              item.packageType === 'ipa' || item.platform === 'ios'
                                ? 'bg-blue-500 text-white ring-1 ring-blue-300'
                                : 'bg-emerald-500 text-slate-950 ring-1 ring-emerald-300'
                            }`}
                          >
                            {item.packageType === 'ipa' || item.platform === 'ios' ? 'IPA' : 'APK'}
                          </span>
                        </div>
                        <span className="text-[10.5px] font-medium text-slate-300 group-hover:text-white transition tracking-tight truncate max-w-[64px] text-center">
                          {item.name}
                        </span>
                      </button>
                    ))}

                    {/* PLUS BUTTON: Add any App or APK/IPA (Capped at MAX_INSTALLED_APPS = 40) */}
                    <button
                      data-agent-target="app-icon-add-install-app"
                      onClick={() => {
                        if (installedApps.length >= MAX_INSTALLED_APPS) {
                          setPlatformToast(`Storage full: Maximum limit of ${MAX_INSTALLED_APPS} apps reached. Please uninstall an app first.`);
                          sounds.playNotification();
                        }
                        setIsInstallerModalOpen(true);
                      }}
                      className="flex flex-col items-center gap-1.5 group cursor-pointer"
                      title={
                        installedApps.length >= MAX_INSTALLED_APPS
                          ? `Storage limit reached: ${installedApps.length}/${MAX_INSTALLED_APPS} apps`
                          : `Add App or Sideload (${installedApps.length}/${MAX_INSTALLED_APPS})`
                      }
                    >
                      <div
                        className={`w-12 h-12 rounded-2xl border-2 border-dashed flex items-center justify-center shadow-md group-hover:scale-105 active:scale-95 transition ${
                          installedApps.length >= MAX_INSTALLED_APPS
                            ? 'bg-rose-500/10 border-rose-400/60 text-rose-400'
                            : phonePlatform === 'android'
                            ? 'bg-emerald-500/10 border-emerald-400/60 group-hover:border-emerald-400 group-hover:bg-emerald-500/20 text-emerald-400'
                            : 'bg-blue-500/10 border-blue-400/60 group-hover:border-blue-400 group-hover:bg-blue-500/20 text-blue-400'
                        }`}
                      >
                        <Plus className="w-5 h-5 stroke-[2.5]" />
                      </div>
                      <span
                        className={`text-[10px] font-bold transition tracking-tight text-center ${
                          installedApps.length >= MAX_INSTALLED_APPS
                            ? 'text-rose-400'
                            : phonePlatform === 'android'
                            ? 'text-emerald-400 group-hover:text-emerald-300'
                            : 'text-blue-400 group-hover:text-blue-300'
                        }`}
                      >
                        + Add App
                        <span className="text-[8px] font-mono opacity-80 block">
                          ({installedApps.length}/{MAX_INSTALLED_APPS})
                        </span>
                      </span>
                    </button>
                  </div>
                </div>

                {/* Bottom Dock */}
                <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700/60 rounded-3xl p-3 flex justify-around items-center mt-6">
                  <button
                    data-agent-target="dock-messages"
                    onClick={() => onNavigateApp('messages')}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center text-xl shadow-xs"
                  >
                    💬
                  </button>
                  <button
                    data-agent-target="dock-browser"
                    onClick={() => onNavigateApp('browser')}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center text-xl shadow-xs"
                  >
                    🌐
                  </button>
                  <button
                    data-agent-target="dock-food"
                    onClick={() => onNavigateApp('food')}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-xl shadow-xs"
                  >
                    🍕
                  </button>
                  <button
                    data-agent-target="dock-settings"
                    onClick={() => onNavigateApp('settings')}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-slate-600 to-slate-700 flex items-center justify-center text-xl shadow-xs"
                  >
                    ⚙️
                  </button>
                </div>
              </div>
            )}

            {/* 2. FOOD / BITEDASH APP */}
            {currentApp === 'food' && (
              <div className="flex-1 flex flex-col p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-base text-white flex items-center gap-2">
                    <span>BiteDash Food</span>
                  </h3>
                  <button
                    data-agent-target="food-header-cart-button"
                    className="relative p-2 bg-slate-800 text-slate-200 rounded-xl"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    {foodCart.length > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-slate-950 rounded-full text-[10px] font-bold flex items-center justify-center">
                        {foodCart.length}
                      </span>
                    )}
                  </button>
                </div>

                {/* Categories */}
                <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
                  {['all', 'pizza', 'burger', 'sushi', 'drinks'].map((cat) => (
                    <button
                      key={cat}
                      data-agent-target={`category-${cat}`}
                      data-category-id={cat}
                      onClick={() => onSelectFoodCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl font-semibold capitalize shrink-0 transition ${
                        selectedFoodCategory === cat
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Food Catalog */}
                <div className="space-y-2.5">
                  {foodItems
                    .filter((item) => selectedFoodCategory === 'all' || item.category === selectedFoodCategory)
                    .map((item) => (
                      <div
                        key={item.id}
                        data-agent-target={`food-item-${item.id}`}
                        className="bg-slate-800/80 border border-slate-700/60 rounded-2xl p-3 flex gap-3 items-center"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 rounded-xl object-cover shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-xs text-white truncate">{item.name}</h4>
                          <p className="text-[10px] text-slate-400 line-clamp-1">{item.description}</p>
                          <div className="flex items-center justify-between mt-1.5">
                            <span className="font-mono font-bold text-emerald-400 text-xs">
                              ${item.price.toFixed(2)}
                            </span>
                            <button
                              data-agent-target="add-pizza-to-cart"
                              onClick={() => onAddToCart(item)}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition flex items-center gap-1"
                            >
                              <Plus className="w-3 h-3" />
                              <span>Add</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>

                {/* Floating Cart bar if items added */}
                {foodCart.length > 0 && (
                  <div
                    data-agent-target="food-floating-cart"
                    className="mt-auto bg-emerald-600 text-white p-3 rounded-2xl flex items-center justify-between text-xs font-bold shadow-lg"
                  >
                    <span>{foodCart.reduce((s, c) => s + c.quantity, 0)} item(s) in Cart</span>
                    <span>
                      ${foodCart.reduce((s, c) => s + c.item.price * c.quantity, 0).toFixed(2)} ➔
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* 3. SOCIAL APP */}
            {currentApp === 'social' && (
              <div className="flex-1 p-3 space-y-4">
                <div className="flex justify-between items-center px-1">
                  <h3 className="font-bold text-base text-white">Pulse Social</h3>
                </div>
                {socialPosts.map((post, idx) => (
                  <div key={post.id} className="bg-slate-800/70 border border-slate-700/60 rounded-2xl overflow-hidden">
                    <div className="p-2.5 flex items-center gap-2">
                      <img src={post.avatar} className="w-7 h-7 rounded-full object-cover" />
                      <div>
                        <h5 className="font-bold text-xs text-white leading-tight">{post.author}</h5>
                        <span className="text-[10px] text-slate-400">{post.handle}</span>
                      </div>
                    </div>
                    <img src={post.image} className="w-full h-44 object-cover" />
                    <div className="p-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <button
                            data-agent-target={`post-like-button-${idx}`}
                            onClick={() => onToggleLike(post.id)}
                            className="flex items-center gap-1 text-xs"
                          >
                            <Heart
                              className={`w-4 h-4 ${
                                post.isLiked ? 'text-rose-500 fill-current' : 'text-slate-400'
                              }`}
                            />
                            <span className="font-mono text-[11px] text-slate-300">{post.likes}</span>
                          </button>
                          <span className="text-slate-400 text-xs flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            <span className="font-mono text-[11px]">{post.commentsCount}</span>
                          </span>
                        </div>
                        <button onClick={() => onToggleBookmark(post.id)}>
                          <Bookmark
                            className={`w-4 h-4 ${
                              post.bookmarked ? 'text-amber-400 fill-current' : 'text-slate-400'
                            }`}
                          />
                        </button>
                      </div>
                      <p className="text-xs text-slate-200 line-clamp-2">{post.caption}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 4. MESSAGES APP */}
            {currentApp === 'messages' && (
              <div className="flex-1 flex flex-col p-3">
                {activeThread ? (
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                        <button
                          onClick={() => onSelectMessageThread(null)}
                          className="p-1 text-slate-400 hover:text-white"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <img src={activeThread.avatar} className="w-7 h-7 rounded-full object-cover" />
                        <h4 className="font-bold text-xs text-white">{activeThread.name}</h4>
                      </div>
                      <div className="space-y-2 py-3 overflow-y-auto max-h-[460px]">
                        {activeThread.messages.map((m) => (
                          <div
                            key={m.id}
                            className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div
                              className={`max-w-[78%] px-3.5 py-2 rounded-2xl text-xs ${
                                m.sender === 'me'
                                  ? 'bg-emerald-600 text-white rounded-br-none'
                                  : 'bg-slate-800 text-slate-200 rounded-bl-none'
                              }`}
                            >
                              <p>{m.text}</p>
                              <span className="text-[9px] opacity-70 block text-right mt-1 font-mono">
                                {m.time}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    {/* Draft Input */}
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                      <input
                        type="text"
                        value={messageInputDraft}
                        onChange={(e) => onMessageInputDraftChange(e.target.value)}
                        placeholder="iMessage / SMS..."
                        data-agent-target="messages-input-field"
                        className="flex-1 bg-slate-800 text-xs px-3.5 py-2 rounded-xl text-white focus:outline-hidden"
                      />
                      <button
                        data-agent-target="send-message-btn"
                        onClick={() => onSendMessage(activeThread.id, messageInputDraft)}
                        className="p-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-500"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <h3 className="font-bold text-base text-white px-1">Messages</h3>
                    {messageThreads.map((thread) => (
                      <div
                        key={thread.id}
                        data-agent-target={`thread-${thread.name.toLowerCase().split(' ')[0]}`}
                        onClick={() => onSelectMessageThread(thread.id)}
                        className="p-3 bg-slate-800/70 border border-slate-700/60 rounded-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-800"
                      >
                        <img src={thread.avatar} className="w-10 h-10 rounded-full object-cover shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <h5 className="font-bold text-xs text-white">{thread.name}</h5>
                            <span className="text-[10px] text-slate-400 font-mono">{thread.time}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">{thread.lastMessage}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 5. NOTES APP */}
            {currentApp === 'notes' && (
              <div className="flex-1 p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-base text-white">Notes</h3>
                  <button
                    data-agent-target="new-note-button"
                    onClick={() => setIsCreatingNote(true)}
                    className="p-2 bg-emerald-600 text-white rounded-xl text-xs flex items-center gap-1 font-semibold"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New</span>
                  </button>
                </div>

                {isCreatingNote ? (
                  <div className="bg-slate-800 p-4 rounded-2xl space-y-2 border border-slate-700">
                    <input
                      type="text"
                      value={noteDraftTitle}
                      onChange={(e) => setNoteDraftTitle(e.target.value)}
                      placeholder="Note Title"
                      data-agent-target="note-title-input"
                      className="w-full bg-slate-900 px-3 py-2 rounded-xl text-xs text-white font-bold"
                    />
                    <textarea
                      value={noteDraftBody}
                      onChange={(e) => setNoteDraftBody(e.target.value)}
                      placeholder="Note Content..."
                      data-agent-target="note-body-input"
                      rows={4}
                      className="w-full bg-slate-900 p-3 rounded-xl text-xs text-slate-200"
                    />
                    <button
                      data-agent-target="save-note-button"
                      onClick={() => {
                        onSaveNote({ title: noteDraftTitle || 'New Note', content: noteDraftBody });
                        setNoteDraftTitle('');
                        setNoteDraftBody('');
                        setIsCreatingNote(false);
                      }}
                      className="w-full py-2 bg-emerald-600 text-white rounded-xl text-xs font-semibold"
                    >
                      Save Note
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {notes.map((n) => (
                      <div key={n.id} className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-2xl">
                        <div className="flex justify-between items-center">
                          <h4 className="font-bold text-xs text-white">{n.title}</h4>
                          <span className="text-[10px] text-slate-400 font-mono">{n.updatedAt}</span>
                        </div>
                        <p className="text-[11px] text-slate-300 mt-1 whitespace-pre-line">{n.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 6. BROWSER / SEARCHGLOBE */}
            {currentApp === 'browser' && (
              <div className="flex-1 flex flex-col p-3 space-y-3">
                <div className="flex items-center gap-2 bg-slate-800 p-2 rounded-2xl border border-slate-700">
                  <button
                    data-agent-target="browser-back-btn"
                    onClick={() => onSelectBrowserResultIndex(null)}
                    className="p-1 text-slate-400 hover:text-white"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <input
                    type="text"
                    value={browserQuery}
                    onChange={(e) => onBrowserSearchChange(e.target.value)}
                    data-agent-target="browser-search-input"
                    className="bg-transparent text-xs text-white w-full focus:outline-hidden"
                  />
                </div>

                {selectedBrowserResultIndex !== null ? (
                  <div className="bg-slate-800 p-4 rounded-2xl space-y-2 text-xs">
                    <span className="text-[10px] text-emerald-400 font-mono uppercase">
                      Authoritative Source Verified
                    </span>
                    <h4 className="font-bold text-sm text-white">
                      Deep Dive: {browserQuery} (Article #{selectedBrowserResultIndex + 1})
                    </h4>
                    <p className="text-slate-300 leading-relaxed text-[11px]">
                      {browserQuery.toLowerCase().includes('messi')
                        ? 'Lionel Messi is an Argentine professional footballer who plays as a forward and captains both Major League Soccer club Inter Miami and the Argentina national team. Widely regarded as one of the greatest players in the history of the sport, he has won a record eight Ballon d’Or awards and led Argentina to victory at the 2022 FIFA World Cup.'
                        : `Comprehensive overview of "${browserQuery}". Detailed exploration of core concepts, verified data points, and technical documentation.`}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {(() => {
                      const q = (browserQuery || 'AI Phone Agents & Automation').trim();
                      const isMessi = q.toLowerCase().includes('messi');
                      const results = isMessi
                        ? [
                            {
                              url: 'https://en.wikipedia.org/wiki/Lionel_Messi',
                              title: 'Lionel Messi — Official Career Statistics, Records & World Cup Champion',
                              desc: 'Argentine professional footballer widely regarded as one of the greatest players in the history of the sport. Captain of the Argentina national team and 8-time Ballon d’Or winner.',
                            },
                            {
                              url: 'https://www.fifa.com/messi-profile',
                              title: 'Lionel Messi: News, Match Schedule, Goals & Inter Miami CF Highlights',
                              desc: 'Complete coverage of Lionel Messi matches, goals, assist tallies, and upcoming fixtures in Major League Soccer and international tournaments.',
                            },
                            {
                              url: 'https://sports.espn.com/messi-tributes',
                              title: 'The Legacy of Lionel Messi: Trophies, Tactics & Masterclass Plays',
                              desc: 'In-depth tactical analysis and retrospectives celebrating Messi’s historic career milestones, playmaking mastery, and iconic championship moments.',
                            },
                          ]
                        : [
                            {
                              url: `https://verified.search.org/query/${encodeURIComponent(q)}/overview`,
                              title: `${q} — Latest Updates, Verified Research & Analysis`,
                              desc: `Comprehensive overview and curated authoritative findings on "${q}". Detailed breakdown of recent milestones and verified facts.`,
                            },
                            {
                              url: `https://encyclopedia.web/topics/${encodeURIComponent(q)}`,
                              title: `In-Depth Guide: Everything You Need to Know About ${q}`,
                              desc: `Detailed reference documentation, key historical context, and comprehensive statistical data regarding ${q}.`,
                            },
                            {
                              url: `https://news.globe.net/articles/${encodeURIComponent(q)}`,
                              title: `${q} in 2026: Key Developments, Trends & Expert Commentary`,
                              desc: `Recent developments, community discussions, and forward-looking analysis centered on ${q}.`,
                            },
                          ];

                      return results.map((res, i) => (
                        <div
                          key={i}
                          data-agent-target={`browser-result-${i}`}
                          onClick={() => onSelectBrowserResultIndex(i)}
                          className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-2xl cursor-pointer hover:border-emerald-500/50"
                        >
                          <span className="text-[10px] text-emerald-400 truncate block">{res.url}</span>
                          <h5 className="font-bold text-xs text-white mt-0.5">{res.title}</h5>
                          <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{res.desc}</p>
                        </div>
                      ));
                    })()}
                  </div>
                )}
              </div>
            )}

            {/* 7. BANKING / APEX BANK */}
            {currentApp === 'banking' && (
              <div className="flex-1 p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-base text-white">Apex Secure Bank</h3>
                  <Shield className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="bg-gradient-to-tr from-emerald-950 to-slate-900 border border-emerald-500/40 p-4 rounded-2xl">
                  <span className="text-[10px] text-emerald-400 font-mono">Total Liquid Balance</span>
                  <div className="text-2xl font-bold font-mono text-white mt-1">$24,850.12</div>
                </div>
                <div className="flex gap-2">
                  <button
                    data-agent-target="bank-export-btn"
                    onClick={onExportStatement}
                    className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs text-emerald-400 font-semibold rounded-xl"
                  >
                    {isStatementExported ? '✓ Exported' : 'Export Statement'}
                  </button>
                  <button
                    data-agent-target="bank-flag-btn"
                    onClick={onFlagWeirdCharges}
                    className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs text-amber-400 font-semibold rounded-xl"
                  >
                    {isWeirdChargeFlagged ? '✓ Flagged (1)' : 'Audit Charges'}
                  </button>
                </div>
              </div>
            )}

            {/* 8. QUICKBOOKS */}
            {currentApp === 'quickbooks' && (
              <div className="flex-1 p-4 space-y-3">
                <h3 className="font-bold text-base text-white">QuickBooks Online</h3>
                <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Invoice:</span>
                    <span className="font-bold text-white">#INV-2026-104</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Client:</span>
                    <span className="font-bold text-white">Alex Rivera</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Total:</span>
                    <span className="font-mono font-bold text-emerald-400">$1,800.00</span>
                  </div>
                </div>
                <button
                  data-agent-target="quickbooks-send-btn"
                  onClick={onSendQuickBooksInvoice}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold"
                >
                  {isQuickBooksInvoiceSent ? '✓ Invoice Dispatched' : 'Verify & Send Invoice'}
                </button>
              </div>
            )}

            {/* 9. SETTINGS */}
            {currentApp === 'settings' && (
              <div className="flex-1 p-4 space-y-3">
                <h3 className="font-bold text-base text-white">System Settings</h3>
                <div className="space-y-2">
                  <div
                    data-agent-target="settings-darkmode-toggle"
                    onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
                    className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-2xl flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 text-xs text-white">
                      <Moon className="w-4 h-4 text-cyan-400" />
                      <span>Dark Theme</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-emerald-400">
                      {settings.darkMode ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <div
                    onClick={() => onUpdateSettings({ wifi: !settings.wifi })}
                    className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-2xl flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 text-xs text-white">
                      <Wifi className="w-4 h-4 text-emerald-400" />
                      <span>Wi-Fi Network</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-emerald-400">
                      {settings.wifi ? 'CONNECTED' : 'OFF'}
                    </span>
                  </div>
                  <div
                    onClick={() => onUpdateSettings({ lowPower: !settings.lowPower })}
                    className="p-3 bg-slate-800/80 border border-slate-700/60 rounded-2xl flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 text-xs text-white">
                      <Battery className="w-4 h-4 text-amber-400" />
                      <span>Low Power Mode</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-emerald-400">
                      {settings.lowPower ? 'ON' : 'OFF'}
                    </span>
                  </div>

                  {/* Rate & Review App Feedback row */}
                  <div
                    data-agent-target="settings-rate-review-btn"
                    onClick={() => setIsReviewModalOpen(true)}
                    className="p-3 bg-gradient-to-r from-amber-500/15 to-yellow-500/10 border border-amber-500/40 hover:border-amber-400 rounded-2xl flex items-center justify-between cursor-pointer transition active:scale-98"
                  >
                    <div className="flex items-center gap-2.5 text-xs text-amber-200 font-semibold">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                      <span>Write App Review</span>
                    </div>
                    <span className="text-[10px] font-mono text-amber-300 font-bold bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30">
                      SUBMIT FEEDBACK
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* 10. GOOGLE CHROME MOBILE AI BROWSER ENGINE VIEW */}
            {currentApp === 'chrome' && (() => {
              const activeProvider: InPhoneChromeProvider =
                inPhoneChromeConfig?.aiModel || 'gemini_web';
              const activeVisualMode = inPhoneChromeConfig?.visualMode || 'headless';
              const meta = CHROME_PROVIDER_META[activeProvider] || CHROME_PROVIDER_META.gemini_web;

              const handleSwitchChromeProvider = (prov: InPhoneChromeProvider) => {
                sounds.playTap();
                if (onUpdateInPhoneChromeConfig) {
                  onUpdateInPhoneChromeConfig({
                    enabled: inPhoneChromeConfig?.enabled ?? true,
                    aiModel: prov,
                    visualMode: activeVisualMode,
                    autoSwitchTabs: inPhoneChromeConfig?.autoSwitchTabs ?? true,
                  });
                }
              };

              const handleToggleVisualMode = () => {
                sounds.playTap();
                if (onUpdateInPhoneChromeConfig) {
                  onUpdateInPhoneChromeConfig({
                    enabled: inPhoneChromeConfig?.enabled ?? true,
                    aiModel: activeProvider,
                    visualMode: activeVisualMode === 'headless' ? 'live_split' : 'headless',
                    autoSwitchTabs: inPhoneChromeConfig?.autoSwitchTabs ?? true,
                  });
                }
              };

              const handleSendInsideChrome = (e?: React.FormEvent) => {
                e?.preventDefault();
                const text = chromePromptDraft.trim();
                if (!text) return;
                sounds.playTap();
                setChromePromptDraft('');
                if (onSubmitPromptFromChrome) {
                  onSubmitPromptFromChrome(text);
                }
              };

              return (
                <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-hidden">
                  {/* Top Chrome Omnibox & Toolbar */}
                  <div className="bg-slate-900 border-b border-slate-800 px-3 py-2 space-y-2 shrink-0">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        data-agent-target="chrome-home-btn"
                        onClick={() => onNavigateApp('home')}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                        title="Back to Home Screen"
                      >
                        <Home className="w-3.5 h-3.5" />
                      </button>

                      {/* Address Bar */}
                      <div className="flex-1 flex items-center gap-1.5 bg-slate-950 border border-slate-700/80 rounded-full px-2.5 py-1 text-[10.5px]">
                        <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span className="font-mono text-slate-200 truncate flex-1">
                          {meta.url}
                        </span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shrink-0">
                          {inPhoneChromeConfig?.enabled ? 'AI ON' : 'PAUSED'}
                        </span>
                      </div>

                      {/* Tab Count Badge */}
                      <div
                        className="w-5 h-5 rounded-md border border-slate-600 text-[9px] font-mono font-bold flex items-center justify-center text-slate-300 bg-slate-800 shrink-0"
                        title="Active AI Web Tab"
                      >
                        3
                      </div>

                      <button
                        type="button"
                        onClick={() => clearInPhoneChromeFeed(instanceId)}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-300 hover:bg-slate-800 transition cursor-pointer"
                        title="Clear Chrome Session Feed"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Quick Tabs Switcher (Gemini Web / ChatGPT Web / Claude Web) + Execution Mode Toggle */}
                    <div className="flex items-center justify-between gap-1.5">
                      <div className="flex items-center gap-1 overflow-x-auto">
                        {(['gemini_web', 'chatgpt_web', 'claude_web'] as const).map((provId) => {
                          const pMeta = CHROME_PROVIDER_META[provId];
                          const isSelected = activeProvider === provId;
                          return (
                            <button
                              key={provId}
                              type="button"
                              data-agent-target={`chrome-tab-${provId}`}
                              onClick={() => handleSwitchChromeProvider(provId)}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 border transition cursor-pointer shrink-0 ${
                                isSelected
                                  ? pMeta.accentClass
                                  : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white'
                              }`}
                            >
                              <Chrome className="w-2.5 h-2.5" />
                              <span>{pMeta.label}</span>
                            </button>
                          );
                        })}
                      </div>

                      <button
                        type="button"
                        data-agent-target="chrome-visual-mode-toggle"
                        onClick={handleToggleVisualMode}
                        className={`px-2 py-1 rounded-lg text-[9px] font-mono font-bold border flex items-center gap-1 shrink-0 cursor-pointer transition ${
                          activeVisualMode === 'live_split'
                            ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                            : 'bg-slate-800 border-slate-700 text-slate-300'
                        }`}
                        title="Toggle Background Headless Tab vs. Live Split/Tab View"
                      >
                        <Eye className="w-2.5 h-2.5" />
                        <span>{activeVisualMode === 'live_split' ? 'Live Tab' : 'Headless'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Chrome AI Web Session Header Banner */}
                  <div className="px-3 py-1.5 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-[10px] shrink-0">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="font-semibold">{meta.badgeText}</span>
                      <span className="text-slate-500">• No API Key Required</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setInstalledApps((prev) => prev.filter((a) => a.id !== 'chrome'));
                        onNavigateApp('home');
                      }}
                      className="text-[9px] font-mono text-slate-500 hover:text-rose-400 transition cursor-pointer"
                      title="Uninstall Chrome from phone"
                    >
                      Uninstall
                    </button>
                  </div>

                  {/* Live Interactive Chrome AI Chat Feed */}
                  <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
                    {chromeFeed.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-4 space-y-2">
                        <Cpu className="w-7 h-7 text-cyan-400/70" />
                        <p className="text-xs font-semibold text-slate-300">
                          {meta.label} Session Ready
                        </p>
                        <p className="text-[10.5px] text-slate-400">
                          Send any automation prompt in the chat panel or below to watch live prompts, screenshots, and JSON plans stream here.
                        </p>
                      </div>
                    ) : (
                      chromeFeed.map((entry) => (
                        <div
                          key={entry.id}
                          className={`rounded-2xl p-2.5 border text-[11px] space-y-1.5 ${
                            entry.role === 'system_prompt'
                              ? 'bg-slate-900 border-slate-700/80 ml-4'
                              : entry.role === 'ai_plan'
                              ? 'bg-cyan-950/30 border-cyan-500/35 mr-2'
                              : entry.role === 'vision_verdict'
                              ? 'bg-amber-950/35 border-amber-500/40 mr-2'
                              : 'bg-emerald-950/25 border-emerald-500/30 mr-2'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 text-[9.5px] font-mono">
                            <span className="font-bold text-slate-200 truncate">
                              {entry.title}
                            </span>
                            <span className="text-slate-400 shrink-0">
                              {entry.timestamp}
                              {entry.latencyMs > 0 ? ` • ${entry.latencyMs}ms` : ''}
                            </span>
                          </div>

                          {/* Screenshot attached to AI web session during continuous vision QA */}
                          {entry.screenshotUrl && (
                            <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-xl p-1.5">
                              <img
                                src={entry.screenshotUrl}
                                alt="Phone vision frame"
                                className="w-12 h-20 object-cover rounded-lg border border-slate-700 shrink-0"
                              />
                              <div className="min-w-0 flex-1 space-y-0.5">
                                <div className="text-[9.5px] font-mono text-emerald-400 font-bold">
                                  ATTACHED SCREENSHOT FRAME
                                </div>
                                <p className="text-[10px] text-slate-300 line-clamp-3">
                                  {entry.rawResponseText}
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Prompt or Raw Text */}
                          {!entry.screenshotUrl && (
                            <p className="text-[10.5px] text-slate-200 whitespace-pre-wrap break-words leading-relaxed">
                              {entry.role === 'system_prompt'
                                ? entry.promptText
                                : entry.rawResponseText}
                            </p>
                          )}

                          {/* JSON Payload Block for Vision / Plan */}
                          {entry.jsonPayload && entry.role !== 'ai_plan' && (
                            <pre className="bg-slate-950/90 border border-slate-800 rounded-xl p-2 text-[9px] font-mono text-emerald-300 overflow-x-auto max-h-28">
                              {JSON.stringify(entry.jsonPayload, null, 2)}
                            </pre>
                          )}
                        </div>
                      ))
                    )}
                    <div ref={chromeFeedEndRef} />
                  </div>

                  {/* Interactive Bottom Input Box inside Mobile Chrome */}
                  <form
                    onSubmit={handleSendInsideChrome}
                    className="p-2.5 bg-slate-900 border-t border-slate-800 flex items-center gap-1.5 shrink-0"
                  >
                    <input
                      type="text"
                      data-agent-target="chrome-address-input"
                      value={chromePromptDraft}
                      onChange={(e) => setChromePromptDraft(e.target.value)}
                      placeholder={`Ask ${meta.shortLabel} to automate phone...`}
                      className="flex-1 bg-slate-950 border border-slate-700/80 rounded-full px-3 py-1.5 text-[11px] text-white placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
                    />
                    <button
                      type="submit"
                      data-agent-target="chrome-send-prompt-btn"
                      className="p-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-full transition cursor-pointer shrink-0"
                      title="Run Prompt via In-Phone Chrome AI"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              );
            })()}

            {/* 10. SANDBOXED / INSTALLED APP VIEW (REAL HYBRID iOS WEBKIT / XCODE OR ANDROID ADB VIEWPORT) */}
            {!['home', 'food', 'social', 'messages', 'notes', 'browser', 'chrome', 'banking', 'quickbooks', 'settings'].includes(currentApp) && (
              (() => {
                const appNeedle = String(currentApp || '').toLowerCase();
                const runningApp =
                  installedApps.find(
                    (a) =>
                      a.id.toLowerCase() === appNeedle ||
                      a.name.toLowerCase() === appNeedle ||
                      a.id.toLowerCase().includes(appNeedle)
                  ) || {
                  id: currentApp,
                  name: currentApp.charAt(0).toUpperCase() + currentApp.slice(1),
                  icon: '📦',
                  bg: 'from-slate-700 to-slate-800',
                  packageType: (phonePlatform === 'ios' ? 'ipa' : 'apk') as 'apk' | 'ipa',
                  platform: phonePlatform,
                  size: '34.2 MB',
                  version: 'v1.0.0',
                  description:
                    phonePlatform === 'ios'
                      ? 'iOS Hybrid WebKit / Xcode Simulator runtime.'
                      : 'Android application container runtime.',
                  packageName: currentApp.includes('.') ? currentApp : undefined,
                  bundleId: phonePlatform === 'ios' ? `com.omniagent.ios.${currentApp}` : undefined,
                };

                const isIosApp =
                  phonePlatform === 'ios' ||
                  runningApp.packageType === 'ipa' ||
                  runningApp.platform === 'ios';
                const resolvedPkg = isIosApp
                  ? runningApp.bundleId || runningApp.id
                  : runningApp.packageName || runningApp.id;

                const handleLiveScreenClick = (e: React.MouseEvent<HTMLDivElement>) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  if (rect.width <= 0 || rect.height <= 0) return;
                  const xPct = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
                  const yPct = Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height));
                  const x = Math.round(xPct * liveScreenSize.width);
                  const y = Math.round(yPct * liveScreenSize.height);
                  sounds.playTap();
                  setLiveTapMarker({ xPct: xPct * 100, yPct: yPct * 100 });
                  window.setTimeout(() => setLiveTapMarker(null), 350);
                  void sendLiveInputCommand({ type: 'tap', x, y });
                };

                return (
                  <div className="flex-1 flex flex-col p-3.5 space-y-2.5 overflow-y-auto">
                    {/* App Top Navigation */}
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800 shrink-0">
                      <div className="flex items-center gap-2 min-w-0">
                        <button
                          data-agent-target="sandboxed-app-back-btn"
                          onClick={() => onNavigateApp('home')}
                          className="p-1 text-slate-400 hover:text-white transition cursor-pointer shrink-0"
                          title="Return to Home Screen"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <div
                          className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${runningApp.bg} flex items-center justify-center text-base shadow-xs shrink-0`}
                        >
                          {runningApp.icon}
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs text-white flex items-center gap-1.5 flex-wrap">
                            <span className="truncate">{runningApp.name}</span>
                            <span
                              className={`text-[8.5px] font-mono uppercase px-1.5 py-0.2 rounded-md font-bold ${
                                isIosApp
                                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                                  : liveContainerStatus === 'connected'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              }`}
                            >
                              {isIosApp
                                ? runningApp.iosEngineLabel || liveIosEngineLabel
                                : liveContainerStatus === 'connected'
                                ? 'ADB LIVE'
                                : 'ADB CONTAINER'}
                            </span>
                          </h4>
                          <p className="text-[10px] text-slate-400 font-mono truncate">
                            {isIosApp
                              ? liveIosCurrentUrl || runningApp.launchUrl || resolvedPkg
                              : `${resolvedPkg}${runningApp.adbTarget ? ` • ${runningApp.adbTarget}` : ''}`}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => onNavigateApp('home')}
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Real Live Screen Streamer (iOS WebKit/Xcode OR Android ADB) */}
                    <div className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl p-2.5 flex flex-col justify-between space-y-2.5 min-h-[340px]">
                      <div className="flex items-center justify-between text-[10px] font-mono px-1">
                        <span className="text-slate-400 flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              liveContainerStatus === 'connected'
                                ? isIosApp
                                  ? 'bg-blue-400 animate-pulse'
                                  : 'bg-emerald-400 animate-pulse'
                                : liveContainerStatus === 'launching'
                                ? 'bg-amber-400 animate-pulse'
                                : 'bg-rose-400'
                            }`}
                          />
                          <span>
                            {liveContainerStatus === 'connected'
                              ? isIosApp
                                ? `iPhone 16 Pro WebKit (${liveScreenSize.width}×${liveScreenSize.height})`
                                : `Live ADB Stream (${liveScreenSize.width}×${liveScreenSize.height})`
                              : liveContainerStatus === 'launching'
                              ? isIosApp
                                ? 'Booting iOS Engine...'
                                : 'Connecting to ADB Device...'
                              : isIosApp
                              ? 'iOS Engine Offline'
                              : 'ADB Device Offline'}
                          </span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setLiveRetryNonce((n) => n + 1)}
                          className="text-[10px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                          title="Reconnect & refresh screen"
                        >
                          <RotateCw className="w-3 h-3" />
                          <span>Refresh</span>
                        </button>
                      </div>

                      {directStreamTransport === 'webrtc' ||
                      directStreamTransport === 'websocket' ||
                      (liveContainerStatus === 'connected' && liveScreenUrl) ? (
                        <div
                          onClick={handleLiveScreenClick}
                          data-agent-target={isIosApp ? 'ios-live-screen' : 'adb-live-screen'}
                          className="relative flex-1 bg-black rounded-xl overflow-hidden border border-slate-800 cursor-crosshair flex items-center justify-center min-h-[250px]"
                          title={`Click anywhere to forward real touch tap via ${
                            directStreamTransport !== 'none'
                              ? `${directStreamTransport.toUpperCase()} Direct`
                              : isIosApp
                              ? '/api/ios/input'
                              : '/api/adb/input'
                          }`}
                        >
                          {directStreamTransport === 'webrtc' && (
                            <video
                              ref={liveVideoRef}
                              autoPlay
                              playsInline
                              muted
                              className="w-full h-full object-contain select-none pointer-events-none"
                            />
                          )}
                          {directStreamTransport === 'websocket' && (
                            <canvas
                              ref={liveCanvasRef}
                              className="w-full h-full object-contain select-none pointer-events-none"
                            />
                          )}
                          {directStreamTransport === 'none' && liveScreenUrl && (
                            <img
                              src={liveScreenUrl}
                              alt={`Live ${isIosApp ? 'iOS' : 'Android'} display for ${runningApp.name}`}
                              className="w-full h-full object-contain select-none pointer-events-none"
                              draggable={false}
                            />
                          )}
                          {liveTapMarker && (
                            <span
                              className={`absolute w-6 h-6 -ml-3 -mt-3 rounded-full border-2 pointer-events-none animate-ping ${
                                isIosApp
                                  ? 'border-blue-400 bg-blue-400/30'
                                  : 'border-emerald-400 bg-emerald-400/30'
                              }`}
                              style={{ left: `${liveTapMarker.xPct}%`, top: `${liveTapMarker.yPct}%` }}
                            />
                          )}
                        </div>
                      ) : (
                        <div className="flex-1 bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-center space-y-2.5 text-center">
                          <div
                            className={`w-10 h-10 mx-auto rounded-2xl border flex items-center justify-center ${
                              isIosApp
                                ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                : 'bg-amber-500/15 border-amber-500/40 text-amber-400'
                            }`}
                          >
                            <AlertCircle className="w-5 h-5" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs font-bold text-white">
                              {liveContainerStatus === 'launching'
                                ? isIosApp
                                  ? `Launching ${runningApp.name} in ${liveIosEngineLabel}...`
                                  : 'Launching Android App via ADB...'
                                : isIosApp
                                ? 'iOS Runtime Unavailable'
                                : 'No Live Android Container Connected'}
                            </p>
                            <p className="text-[11px] text-slate-300 font-mono leading-relaxed break-words">
                              {liveContainerMessage ||
                                (isIosApp
                                  ? 'Connecting to Apple WebKit iPhone Engine...'
                                  : 'Start a real Android Redroid container and expose port 5555 to stream this app.')}
                            </p>
                          </div>
                          {liveDockerHint && !isIosApp && (
                            <div className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-[10px] font-mono text-emerald-300 break-all select-all">
                              {liveDockerHint}
                            </div>
                          )}
                          <button
                            type="button"
                            onClick={() => setLiveRetryNonce((n) => n + 1)}
                            className="mx-auto px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer"
                          >
                            <RotateCw className="w-3.5 h-3.5" />
                            <span>{isIosApp ? 'Retry iOS Engine' : 'Retry ADB Connection'}</span>
                          </button>
                        </div>
                      )}

                      {/* Direct Input Controls (Text, Scroll, Back, Uninstall) */}
                      <div className="space-y-2">
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            const txt = liveInputDraft.trim();
                            if (!txt) return;
                            setLiveInputDraft('');
                            void sendLiveInputCommand({
                              type: 'text',
                              text: txt,
                              pressEnter: isIosApp,
                            });
                          }}
                          className="flex items-center gap-1.5"
                        >
                          <input
                            type="text"
                            data-agent-target="app-action-search"
                            value={liveInputDraft}
                            onChange={(e) => setLiveInputDraft(e.target.value)}
                            placeholder={`Type text to ${isIosApp ? 'iOS WebKit' : 'ADB'} (${runningApp.name})...`}
                            className={`flex-1 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-hidden ${
                              isIosApp ? 'focus:border-blue-500' : 'focus:border-emerald-500'
                            }`}
                          />
                          <button
                            type="submit"
                            data-agent-target="app-action-submit"
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold text-white transition cursor-pointer ${
                              isIosApp
                                ? 'bg-blue-600 hover:bg-blue-500'
                                : 'bg-emerald-600 hover:bg-emerald-500'
                            }`}
                          >
                            Send
                          </button>
                        </form>

                        <div className="grid grid-cols-3 gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              void sendLiveInputCommand({ type: 'keyevent', keycode: 'KEYCODE_BACK' })
                            }
                            className="py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-[11px] font-semibold transition cursor-pointer"
                          >
                            ◁ Back
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void sendLiveInputCommand({
                                type: 'swipe',
                                x1: Math.round(liveScreenSize.width / 2),
                                y1: Math.round(liveScreenSize.height * 0.75),
                                x2: Math.round(liveScreenSize.width / 2),
                                y2: Math.round(liveScreenSize.height * 0.25),
                                durationMs: 300,
                              })
                            }
                            className="py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-[11px] font-semibold transition cursor-pointer"
                          >
                            ⇅ Scroll
                          </button>
                          <button
                            type="button"
                            data-agent-target="app-btn-uninstall"
                            onClick={() => {
                              setInstalledApps((prev) => prev.filter((a) => a.id !== runningApp.id));
                              void removeInstalledAppFromVault(runningApp.id);
                              onNavigateApp('home');
                            }}
                            className="py-1.5 bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 rounded-xl text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3 text-rose-400" />
                            <span>Uninstall</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Return Home Button */}
                    <button
                      type="button"
                      data-agent-target="app-btn-home"
                      onClick={() => onNavigateApp('home')}
                      className={`w-full py-2 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer text-white shrink-0 ${
                        isIosApp
                          ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-950'
                          : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950'
                      }`}
                    >
                      <span>Return to Home Screen</span>
                    </button>
                  </div>
                );
              })()
            )}
          </div>

          {/* Bottom Home Indicator Bar (Swipeable to return home) */}
          <div
            data-agent-target="system-home-bar"
            onClick={() => onNavigateApp('home')}
            className="h-7 w-full flex items-center justify-center cursor-pointer shrink-0"
          >
            <div className="w-32 h-1 bg-slate-500/60 rounded-full hover:bg-slate-300 transition" />
          </div>

          {/* Autonomous Touch Actuator Cursor */}
          {cursorVisible && (
            <div
              className="absolute z-50 pointer-events-none transition-all duration-150 ease-out flex flex-col items-center"
              style={{
                left: `${cursorPos.x}%`,
                top: `${cursorPos.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div
                className={`w-7 h-7 rounded-full border-2 border-emerald-400 flex items-center justify-center shadow-lg transition-transform ${
                  cursorGesture === 'tapping'
                    ? 'scale-75 bg-emerald-500/60'
                    : cursorGesture === 'swiping_up' || cursorGesture === 'swiping_down'
                    ? 'scale-110 bg-cyan-500/40 ring-4 ring-cyan-500/20'
                    : 'bg-emerald-500/30'
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-white shadow-xs" />
              </div>
              {cursorLabel && (
                <div className="mt-1 px-2 py-0.5 bg-slate-900/90 border border-emerald-500/40 rounded-full text-[9px] font-mono font-bold text-emerald-300 shadow-md whitespace-nowrap">
                  {cursorLabel}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* App Installer Modal for sideloading APK and IPA packages & Official Store Hub */}
      <AppInstallerModal
        isOpen={isInstallerModalOpen}
        onClose={() => {
          setIsInstallerModalOpen(false);
          setInstallerInitialSearchQuery(null);
        }}
        phonePlatform={phonePlatform}
        onPlatformChange={handlePlatformChange}
        installedCount={installedApps.length}
        maxApps={MAX_INSTALLED_APPS}
        initialSearchQuery={installerInitialSearchQuery}
        onOpenBillingModal={onOpenBillingModal}
        onInstallApp={(newApp) => {
          if (installedApps.length >= MAX_INSTALLED_APPS) {
            setPlatformToast(`Storage limit reached! Maximum ${MAX_INSTALLED_APPS} apps allowed.`);
            sounds.playNotification();
            return;
          }
          const appWithTimestamp: InstalledAppItem = {
            ...newApp,
            installedAt: newApp.installedAt || new Date().toISOString(),
          };
          setInstalledApps((prev) => {
            if (prev.some((a) => a.id === appWithTimestamp.id)) return prev;
            if (prev.length >= MAX_INSTALLED_APPS) return prev;
            void saveInstalledAppToVault(appWithTimestamp);
            return [...prev, appWithTimestamp];
          });
          onNavigateApp(appWithTimestamp.id as PhoneAppType);
          window.setTimeout(() => {
            onAppInstalledNotify?.(appWithTimestamp);
          }, 120);
        }}
      />

      {/* Review & Feedback Modal */}
      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => setIsReviewModalOpen(false)}
      />
    </div>
  );
};
