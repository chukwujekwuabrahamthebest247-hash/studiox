/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ActionGuardrailState } from '../../types/phone';
import { AlertTriangle, ShieldAlert, CheckCircle2, X } from 'lucide-react';

interface ActionGuardrailModalProps {
  guardrail: ActionGuardrailState | null;
  onAuthorize: () => void;
  onCancel: () => void;
}

export const ActionGuardrailModal: React.FC<ActionGuardrailModalProps> = ({
  guardrail,
  onAuthorize,
  onCancel,
}) => {
  if (!guardrail) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
              ZERO-FEAR ACTION GUARDRAIL
            </span>
            <h3 className="text-base font-bold text-white mt-1">{guardrail.title}</h3>
          </div>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
          {guardrail.amount && (
            <div className="flex justify-between items-center text-slate-300">
              <span>Transaction Amount:</span>
              <span className="font-mono font-bold text-emerald-400 text-sm">{guardrail.amount}</span>
            </div>
          )}
          {guardrail.recipientOrVendor && (
            <div className="flex justify-between items-center text-slate-300">
              <span>Target Recipient / Vendor:</span>
              <span className="font-semibold text-white">{guardrail.recipientOrVendor}</span>
            </div>
          )}
          {guardrail.consequence && (
            <div className="text-slate-400 text-[11px] pt-1 border-t border-slate-800/80">
              {guardrail.consequence}
            </div>
          )}
        </div>

        <div className="flex gap-2.5 pt-1">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
          >
            Deny Action
          </button>
          <button
            onClick={onAuthorize}
            className="flex-1 py-2.5 bg-gradient-to-r from-amber-600 to-emerald-600 hover:from-amber-500 hover:to-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-lg"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Authorize & Proceed</span>
          </button>
        </div>
      </div>
    </div>
  );
};
