/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Coins,
  CreditCard,
  TrendingDown,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  History,
  Code,
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
  ShieldCheck,
  Gift,
  Copy,
  Check,
  Users,
} from 'lucide-react';
import {
  getStoredWallet,
  getStoredLedger,
  creditUserQuotaAsync,
  dispatchOpenAuthModal,
  syncWalletFromServer,
  subscribeToQuotaChanges,
  getUserReferralLink,
} from '../../utils/tokenQuotaManager';
import {
  TOKEN_TOPUP_PACKAGES,
  TOKENS_PER_DOLLAR,
  LOW_QUOTA_ALERT_THRESHOLD,
  formatTokenCount,
  tokensToUsd,
  usdToTokens,
  UserTokenWallet,
  QuotaLedgerEntry,
} from '../../types/tokenBilling';

interface TokenBillingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDeficitTokens?: number;
}

export const TokenBillingModal: React.FC<TokenBillingModalProps> = ({
  isOpen,
  onClose,
  initialDeficitTokens,
}) => {
  const [wallet, setWallet] = useState<UserTokenWallet>(getStoredWallet);
  const [ledger, setLedger] = useState<QuotaLedgerEntry[]>(getStoredLedger);
  const [customDollars, setCustomDollars] = useState<string>('8');
  const [selectedTab, setSelectedTab] = useState<'packages' | 'ledger' | 'referral' | 'developer'>('packages');
  const [ledgerFilter, setLedgerFilter] = useState<'ALL' | 'USAGE' | 'TOPUP'>('ALL');
  const [notification, setNotification] = useState<string | null>(null);
  const [isRefCopied, setIsRefCopied] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setWallet(getStoredWallet());
      setLedger(getStoredLedger());
      void syncWalletFromServer().then((res) => {
        if (res) {
          setWallet(res.wallet);
          setLedger(res.ledger);
        }
      });
    }
  }, [isOpen]);

  useEffect(() => {
    return subscribeToQuotaChanges((updated) => {
      setWallet(updated);
      setLedger(getStoredLedger());
    });
  }, []);

  if (!isOpen) return null;

  const isLowQuota = wallet.appTokenBalance < LOW_QUOTA_ALERT_THRESHOLD;
  const isOutOfQuota = wallet.appTokenBalance <= 0;
  const customNumber = parseFloat(customDollars) || 0;
  const customTokens = usdToTokens(customNumber);

  const handlePurchasePackage = async (priceUsd: number, packageName: string) => {
    const res = await creditUserQuotaAsync(wallet.userId, priceUsd, undefined, packageName);
    if (!res.success && res.authRequired) {
      setNotification(res.error || 'Please sign in and verify your email first.');
      dispatchOpenAuthModal();
      return;
    }
    setNotification(
      `✓ Successfully added ${formatTokenCount(res.tokensAdded)} tokens ($${priceUsd.toFixed(2)}) to your wallet!`
    );
    setTimeout(() => setNotification(null), 4000);
  };

  const handleCustomTopup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (customNumber <= 0) return;
    const res = await creditUserQuotaAsync(
      wallet.userId,
      customNumber,
      undefined,
      `Custom Top-Up ($${customNumber.toFixed(2)})`
    );
    if (!res.success && res.authRequired) {
      setNotification(res.error || 'Please sign in and verify your email first.');
      dispatchOpenAuthModal();
      return;
    }
    setNotification(
      `✓ Successfully added ${formatTokenCount(res.tokensAdded)} tokens ($${customNumber.toFixed(2)}) to your wallet!`
    );
    setTimeout(() => setNotification(null), 4000);
  };

  const filteredLedger = ledger.filter((entry) => {
    if (ledgerFilter === 'USAGE') return entry.type === 'AUTOMATION_RUN';
    if (ledgerFilter === 'TOPUP') return entry.type === 'TOPUP';
    return true;
  }).reverse();

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 flex items-center justify-center text-slate-950 font-bold shadow-md">
              <Coins className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <span>App Token Billing & Quota Manager</span>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                  $8 = 20M Tokens
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Provider-independent quota ledger • Single master API key execution
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Deficit Alert Banner if blocked during automation */}
          {initialDeficitTokens && initialDeficitTokens > 0 && (
            <div className="p-3.5 bg-rose-950/80 border border-rose-500/60 rounded-2xl flex items-start gap-3 text-xs text-rose-200">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-rose-100">
                  Out of Quota — Automation Workflow Blocked
                </p>
                <p className="text-[11px] text-rose-300 mt-0.5">
                  This task requires approximately{' '}
                  <span className="font-mono font-bold text-white">
                    {formatTokenCount(initialDeficitTokens)}
                  </span>{' '}
                  more tokens. Please top up your wallet below to resume automation.
                </p>
              </div>
            </div>
          )}

          {/* Low Quota Alert Banner */}
          {isLowQuota && !initialDeficitTokens && (
            <div className="p-3 bg-amber-950/70 border border-amber-500/50 rounded-2xl flex items-center gap-2.5 text-xs text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Low Quota Warning: Balance is below 250,000 tokens ($0.10). Top up to ensure uninterrupted background workflows.
              </span>
            </div>
          )}

          {/* Success Notification */}
          {notification && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-500/60 rounded-2xl flex items-center gap-2 text-xs text-emerald-200 font-semibold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{notification}</span>
            </div>
          )}

          {/* Wallet Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-mono uppercase text-slate-400">
                Remaining App Tokens
              </span>
              <div className="text-xl font-bold font-mono text-emerald-400 tracking-tight">
                {formatTokenCount(wallet.appTokenBalance)}
              </div>
              <span className="text-[11px] text-slate-400">
                ≈ ${tokensToUsd(wallet.appTokenBalance).toFixed(2)} USD value
              </span>
            </div>

            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-mono uppercase text-slate-400">
                Business Rate
              </span>
              <div className="text-base font-bold font-mono text-cyan-300">
                $8.00 = 20,000,000
              </div>
              <span className="text-[10px] text-slate-500">
                $1.00 = 2,500,000 tokens
              </span>
            </div>

            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1">
              <span className="text-[10px] font-mono uppercase text-slate-400">
                Lifetime Consumed
              </span>
              <div className="text-xl font-bold font-mono text-slate-300 tracking-tight">
                {formatTokenCount(wallet.lifetimeTokensUsed)}
              </div>
              <span className="text-[11px] text-slate-500">
                ≈ ${tokensToUsd(wallet.lifetimeTokensUsed).toFixed(2)} USD consumed
              </span>
            </div>
          </div>

          {/* Tabs Navigation */}
          <div className="flex items-center gap-1 p-1 bg-slate-950/80 border border-slate-800/80 rounded-xl text-xs">
            <button
              onClick={() => setSelectedTab('packages')}
              className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition cursor-pointer ${
                selectedTab === 'packages'
                  ? 'bg-slate-800 text-emerald-400 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Top-Up Packages
            </button>
            <button
              onClick={() => setSelectedTab('ledger')}
              className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                selectedTab === 'ledger'
                  ? 'bg-slate-800 text-emerald-400 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Usage Breakdown Ledger ({ledger.length})</span>
            </button>
            <button
              onClick={() => setSelectedTab('referral')}
              className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                selectedTab === 'referral'
                  ? 'bg-slate-800 text-emerald-400 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Gift className="w-3.5 h-3.5 text-amber-400" />
              <span>Referral (+5M)</span>
            </button>
            <button
              onClick={() => setSelectedTab('developer')}
              className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                selectedTab === 'developer'
                  ? 'bg-slate-800 text-emerald-400 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Webhooks</span>
            </button>
          </div>

          {/* TAB 1: Top-Up Packages */}
          {selectedTab === 'packages' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {TOKEN_TOPUP_PACKAGES.map((pack) => (
                  <div
                    key={pack.id}
                    className={`relative p-4 rounded-2xl border transition flex flex-col justify-between space-y-3 ${
                      pack.isPopular
                        ? 'bg-gradient-to-b from-emerald-950/60 to-slate-950 border-emerald-500/60 ring-1 ring-emerald-500/30'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {pack.isPopular && (
                      <span className="absolute -top-2.5 right-4 bg-emerald-500 text-slate-950 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md">
                        Standard Pack
                      </span>
                    )}

                    <div>
                      <div className="flex items-baseline justify-between">
                        <h4 className="font-bold text-sm text-white">{pack.name}</h4>
                        <span className="text-lg font-bold font-mono text-emerald-400">
                          ${pack.priceUsd}.00
                        </span>
                      </div>
                      <div className="text-base font-bold font-mono text-white mt-1">
                        {formatTokenCount(pack.tokens)}{' '}
                        <span className="text-xs font-normal text-slate-400">tokens</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">{pack.tagline}</p>
                    </div>

                    <button
                      onClick={() => handlePurchasePackage(pack.priceUsd, pack.name)}
                      className={`w-full py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm ${
                        pack.isPopular
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Buy for ${pack.priceUsd}.00</span>
                    </button>
                  </div>
                ))}
              </div>

              {/* Custom Dollar Amount Calculator */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-white">Custom Dollar Top-Up</h4>
                  <span className="text-[10px] font-mono text-slate-400">
                    Exact Formula: $1.00 = 2,500,000 Tokens ($8 = 20M)
                  </span>
                </div>

                <form onSubmit={handleCustomTopup} className="flex gap-2 items-center">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">
                      $
                    </span>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      max="1000"
                      value={customDollars}
                      onChange={(e) => setCustomDollars(e.target.value)}
                      placeholder="8"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-8 pr-3 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500 transition"
                    />
                  </div>

                  <div className="text-right px-2">
                    <span className="text-[10px] text-slate-500 block">Calculated Quota:</span>
                    <span className="font-bold font-mono text-xs text-emerald-400">
                      +{formatTokenCount(customTokens)} tokens
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={customNumber <= 0}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition cursor-pointer shrink-0 shadow-md"
                  >
                    Add Tokens
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 2: Quota Ledger Table */}
          {selectedTab === 'ledger' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px]">
                  Real-time integer ledger audit trail ({filteredLedger.length} entries)
                </span>
                <div className="flex gap-1">
                  {(['ALL', 'USAGE', 'TOPUP'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setLedgerFilter(filter)}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono transition cursor-pointer ${
                        ledgerFilter === filter
                          ? 'bg-slate-800 text-emerald-400 font-bold'
                          : 'text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/90 text-slate-400 text-[10px] font-mono uppercase sticky top-0 border-b border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Workflow / Source</th>
                        <th className="py-2.5 px-3 text-right">Tokens</th>
                        <th className="py-2.5 px-3 text-right">USD</th>
                        <th className="py-2.5 px-3 text-right">Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                      {filteredLedger.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-slate-500 font-sans">
                            No ledger transactions recorded yet.
                          </td>
                        </tr>
                      ) : (
                        filteredLedger.map((item) => (
                          <tr key={item.id} className="hover:bg-slate-900/40">
                            <td className="py-2 px-3">
                              {item.type === 'TOPUP' ? (
                                <span className="inline-flex items-center gap-1 text-emerald-400 text-[10px] font-bold">
                                  <ArrowDownLeft className="w-3 h-3" />
                                  <span>CREDIT</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-amber-400 text-[10px] font-bold">
                                  <ArrowUpRight className="w-3 h-3" />
                                  <span>USAGE</span>
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-slate-300 font-sans truncate max-w-[180px]">
                              {item.workflowName}
                            </td>
                            <td
                              className={`py-2 px-3 text-right font-bold ${
                                item.tokensDelta >= 0 ? 'text-emerald-400' : 'text-slate-300'
                              }`}
                            >
                              {item.tokensDelta >= 0 ? '+' : ''}
                              {formatTokenCount(item.tokensDelta)}
                            </td>
                            <td className="py-2 px-3 text-right text-slate-400">
                              ${item.dollarEquivalent.toFixed(4)}
                            </td>
                            <td className="py-2 px-3 text-right text-slate-400">
                              {formatTokenCount(item.balanceAfter)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: 5M Referral Program */}
          {selectedTab === 'referral' && (
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-emerald-950/60 to-slate-950 border border-emerald-500/40 rounded-2xl space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Gift className="w-4 h-4 text-amber-400" />
                    <span>5,000,000 Free Tokens Referral Program</span>
                  </div>
                  <span className="font-mono text-[10px] text-amber-300 font-bold bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
                    Costs us ~$0.50
                  </span>
                </div>

                <p className="text-slate-300 text-xs">
                  Whenever an invited friend signs up with your link and buys their first <strong className="text-white">$8 (20M token) pack</strong>, you instantly receive <strong className="text-emerald-400">5,000,000 free bonus tokens</strong> directly to your balance!
                </p>

                {/* Referral Link Box */}
                <div className="space-y-1.5 pt-1">
                  <label className="text-[11px] font-semibold text-slate-400">
                    Your Personal Referral Link:
                  </label>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 font-mono text-emerald-400 text-xs truncate select-all">
                      {getUserReferralLink(wallet.referralCode)}
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(getUserReferralLink(wallet.referralCode)).then(() => {
                          setIsRefCopied(true);
                          setTimeout(() => setIsRefCopied(false), 3000);
                        });
                      }}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                        isRefCopied
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
                      }`}
                    >
                      {isRefCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isRefCopied ? 'Copied' : 'Copy Link'}</span>
                    </button>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2 pt-2">
                  <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Friends Joined</span>
                    <span className="text-base font-bold font-mono text-white block">{wallet.referralInvitesCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">$8 Pack Buyers</span>
                    <span className="text-base font-bold font-mono text-emerald-400 block">{wallet.referralConversionsCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Bonus Tokens</span>
                    <span className="text-base font-bold font-mono text-amber-400 block">{formatTokenCount(wallet.referralTokensEarned)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Developer Webhooks */}
          {selectedTab === 'developer' && (
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3 text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>Payment Gateway Webhook Integration Hooks</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                To credit tokens automatically upon successful customer checkout, point your payment processor webhook (Paystack, Stripe, Flutterwave) to your backend and call the exported <code className="text-emerald-300 font-mono">creditUserQuota()</code> function.
              </p>

              <div className="p-3 bg-slate-900 rounded-xl font-mono text-[11px] text-slate-300 overflow-x-auto space-y-2 border border-slate-800">
                <p className="text-slate-500">// TypeScript / Node.js Webhook Integration Example</p>
                <p>
                  <span className="text-cyan-400">import</span> &#123; creditUserQuota &#125; <span className="text-cyan-400">from</span> <span className="text-emerald-300">'./utils/tokenQuotaManager'</span>;
                </p>
                <p>
                  <span className="text-slate-500">// Example: Paystack / Stripe charge.success webhook handler</span><br />
                  <span className="text-purple-400">app</span>.<span className="text-blue-400">post</span>(<span className="text-emerald-300">'/api/quota/webhook'</span>, (req, res) =&gt; &#123;<br />
                  &nbsp;&nbsp;<span className="text-cyan-400">const</span> &#123; event, data &#125; = req.body;<br />
                  &nbsp;&nbsp;<span className="text-cyan-400">if</span> (event === <span className="text-emerald-300">'charge.success'</span>) &#123;<br />
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-cyan-400">const</span> amountInDollars = data.amount / 100; <span className="text-slate-500">// e.g. $8.00</span><br />
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-slate-500">// Enforces exact conversion: $8 = 20,000,000 tokens</span><br />
                  &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-yellow-400">creditUserQuota</span>(data.customer.email, amountInDollars, data.reference);<br />
                  &nbsp;&nbsp;&#125;<br />
                  &nbsp;&nbsp;res.<span className="text-blue-400">json</span>(&#123; received: <span className="text-amber-400">true</span> &#125;);<br />
                  &#125;);
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <span className="text-[11px]">
            Master Key Isolation Active • Decoupled User Quotas
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-medium transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
