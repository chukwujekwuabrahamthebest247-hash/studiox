/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldX, AlertOctagon, Check } from 'lucide-react';

interface AppDownloadRestrictionModalProps {
  isOpen: boolean;
  onClose: () => void;
  attemptedAppName: string;
}

export const AppDownloadRestrictionModal: React.FC<AppDownloadRestrictionModalProps> = ({
  isOpen,
  onClose,
  attemptedAppName,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl space-y-4">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center">
          <ShieldX className="w-9 h-9" />
        </div>
        <div>
          <h3 className="text-base font-bold text-white">App Download Prohibited</h3>
          <p className="text-xs text-rose-400 font-semibold mt-0.5">{attemptedAppName}</p>
          <p className="text-xs text-slate-400 mt-2">
            Company policy and Zero-Fear sandbox strictly prevent downloading or sideloading unverified third-party binaries onto this virtual environment.
          </p>
        </div>
        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition"
        >
          Acknowledge & Dismiss
        </button>
      </div>
    </div>
  );
};
