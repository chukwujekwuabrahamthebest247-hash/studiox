/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Play,
  Sparkles,
  Share2,
  Copy,
  Check,
  CheckCircle2,
  Coins,
  Bot,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { PublicWorkflowTemplate } from '../../types/workflowShare';
import { formatTokenCount } from '../../types/tokenBilling';

interface ImportedWorkflowBannerModalProps {
  workflow: PublicWorkflowTemplate | null;
  isOpen: boolean;
  onClose: () => void;
  onRunWorkflow: (workflow: PublicWorkflowTemplate) => void;
}

export const ImportedWorkflowBannerModal: React.FC<ImportedWorkflowBannerModalProps> = ({
  workflow,
  isOpen,
  onClose,
  onRunWorkflow,
}) => {
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen || !workflow) return null;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(workflow.prompt).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    });
  };

  return (
    <div className="fixed inset-0 z-[130] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col my-auto animate-in zoom-in-95 duration-200">
        
        {/* Top Banner Tag */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 p-2.5 px-6 flex items-center justify-between text-white text-xs font-bold">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 fill-white animate-pulse" />
            <span>Shared Automation Template Detected!</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-black/20 rounded-lg transition cursor-pointer text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-md font-bold">
                {workflow.targetApp.toUpperCase()} WORKFLOW
              </span>
              <span className="text-[10px] text-slate-400">
                Created by <strong className="text-white">{workflow.author}</strong>
              </span>
            </div>
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              {workflow.title}
            </h2>
            <p className="text-xs text-slate-300">
              {workflow.description}
            </p>
          </div>

          {/* Executable Prompt Card */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-semibold text-slate-300">Executable Agent Instruction:</span>
              <button
                onClick={handleCopyPrompt}
                className="hover:text-emerald-400 flex items-center gap-1 transition cursor-pointer"
              >
                {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{isCopied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="text-xs font-mono text-emerald-300 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
              "{workflow.prompt}"
            </p>
          </div>

          {/* Sign Up / Free Welcome Quota Card */}
          <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
              <Coins className="w-5 h-5" />
            </div>
            <div className="text-xs">
              <p className="font-bold text-emerald-200">
                5,000,000 Free Welcome Tokens Activated
              </p>
              <p className="text-[11px] text-slate-300">
                This workflow consumes only ~{formatTokenCount(workflow.estimatedTokens)} tokens. Zero setup required—you can run it immediately!
              </p>
            </div>
          </div>

          {/* Big Action Buttons */}
          <div className="space-y-2 pt-1">
            <button
              onClick={() => {
                onRunWorkflow(workflow);
                onClose();
              }}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 cursor-pointer transition active:scale-98"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>1-Click Run in Active Phone Slot</span>
            </button>

            <button
              onClick={onClose}
              className="w-full py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium cursor-pointer transition"
            >
              Review Desktop Canvas First
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
