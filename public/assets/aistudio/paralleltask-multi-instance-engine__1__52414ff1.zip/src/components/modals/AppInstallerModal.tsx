/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { InstalledAppItem } from '../../types/phone';
import {
  X,
  Upload,
  Download,
  Package,
  Cpu,
  Sparkles,
  ExternalLink,
  Smartphone,
  Apple,
  Check,
  AlertTriangle,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { sounds } from '../../utils/soundEffects';
import { savePackageFileWithDedup } from '../../utils/browserFileVault';
import {
  dispatchOpenAuthModal,
  dispatchOpenBillingModal,
  checkServerPreflightQuota,
  deductServerQuota,
  getAuthHeaders,
  getAuthMultipartHeaders,
} from '../../utils/tokenQuotaManager';
import {
  APP_INSTALL_TOKEN_COST,
  formatTokenCount,
} from '../../types/tokenBilling';

export const ANDROID_PLAY_STORE_URL =
  'https://www.google.com/url?sa=i&source=web&rct=j&url=https://play.google.com&ved=2ahUKEwid65K-tfiXAxWVTkEAHT5iJLwQy_kOeggIAggBCBQQAg&opi=89978449&cd&psig=AOvVaw3w-Vk5B1wYiyq_dbzbpiWx&ust=1794228856034000';

export const IOS_APP_STORE_URL =
  'https://www.google.com/url?sa=i&source=web&rct=j&url=https://apps.apple.com&ved=2ahUKEwid65K-tfiXAxWVTkEAHT5iJLwQy_kOeggIAggBCBQQBA&opi=89978449&cd&psig=AOvVaw3w-Vk5B1wYiyq_dbzbpiWx&ust=1794228856034000';

export const MAX_INSTALLED_APPS = 40;

interface AppInstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
  phonePlatform: 'android' | 'ios';
  onPlatformChange: (platform: 'android' | 'ios') => void;
  onInstallApp: (app: InstalledAppItem) => void;
  installedCount?: number;
  maxApps?: number;
  initialSearchQuery?: string | null;
  onOpenBillingModal?: () => void;
}

// Curated Google Play Store Apps (Android APK)
const ANDROID_STORE_APPS = [
  {
    id: 'chrome',
    packageName: 'com.android.chrome',
    name: 'Google Chrome',
    icon: '🌐',
    bg: 'from-blue-500 via-emerald-500 to-amber-500',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '68.4 MB',
    version: 'v131.0.6778',
    category: 'Browser & AI Web',
    description: 'Mobile Chrome browser with built-in Gemini Web, ChatGPT Web & Claude Web AI Engine.',
  },
  {
    id: 'store-youtube',
    packageName: 'com.google.android.youtube',
    name: 'YouTube',
    icon: '▶️',
    bg: 'from-red-600 to-rose-700',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '52.4 MB',
    version: 'v19.14.3',
    category: 'Video & Entertainment',
    description: 'Watch video tutorials, music streams, subscribe to channels, and automate video playback.',
  },
  {
    id: 'store-spotify',
    packageName: 'com.spotify.music',
    name: 'Spotify',
    icon: '🎧',
    bg: 'from-emerald-500 to-green-700',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '41.5 MB',
    version: 'v8.9.18',
    category: 'Music & Audio',
    description: 'Stream global playlists, podcast episodes, search artists, and control audio playback.',
  },
  {
    id: 'store-instagram',
    packageName: 'com.instagram.android',
    name: 'Instagram',
    icon: '📸',
    bg: 'from-amber-500 via-rose-600 to-purple-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '49.8 MB',
    version: 'v325.0',
    category: 'Social Media',
    description: 'Browse photo feeds, automate social engagement, view stories, and post content.',
  },
  {
    id: 'store-netflix',
    packageName: 'com.netflix.mediaclient',
    name: 'Netflix',
    icon: '🍿',
    bg: 'from-red-700 to-black',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '48.0 MB',
    version: 'v8.106.0',
    category: 'Movies & TV',
    description: 'Stream movies, manage watchlists, view trailers, and run automated media searches.',
  },
  {
    id: 'store-uber',
    packageName: 'com.ubercab',
    name: 'Uber',
    icon: '🚗',
    bg: 'from-slate-900 to-black',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '62.1 MB',
    version: 'v4.512.0',
    category: 'Travel & Local',
    description: 'Request rides, set pickup and destination points, calculate fares, and track drivers.',
  },
  {
    id: 'store-duolingo',
    packageName: 'com.duolingo',
    name: 'Duolingo',
    icon: '🦉',
    bg: 'from-green-500 to-lime-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '38.4 MB',
    version: 'v5.132.4',
    category: 'Education',
    description: 'Language learning lessons, vocabulary quizzes, and automated practice drills.',
  },
  {
    id: 'store-canva',
    packageName: 'com.canva.editor',
    name: 'Canva',
    icon: '🎨',
    bg: 'from-cyan-500 to-blue-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '54.7 MB',
    version: 'v2.251.0',
    category: 'Design & Graphics',
    description: 'Create banners, graphics, social posts, and automate layout templates.',
  },
  {
    id: 'store-chatgpt',
    packageName: 'com.openai.chatgpt',
    name: 'ChatGPT',
    icon: '🤖',
    bg: 'from-teal-600 to-emerald-700',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '34.2 MB',
    version: 'v1.2024.08',
    category: 'Productivity',
    description: 'Conversational assistant, writing assistant, code generator, and research helper.',
  },
  {
    id: 'gmail',
    packageName: 'com.google.android.gm',
    name: 'Gmail',
    icon: '✉️',
    bg: 'from-red-500 via-amber-500 to-emerald-500',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '46.3 MB',
    version: 'v2025.02.18',
    category: 'Email & Productivity',
    description: 'Read unread inboxes, draft replies, summarize threads, and manage labels.',
  },
  {
    id: 'tiktok',
    packageName: 'com.zhiliaoapp.musically',
    name: 'TikTok',
    icon: '🎵',
    bg: 'from-slate-900 via-rose-600 to-cyan-500',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '84.2 MB',
    version: 'v36.4.1',
    category: 'Short Video & Social',
    description: 'Browse For You feeds, watch trending videos, and automate scrolling & likes.',
  },
  {
    id: 'whatsapp',
    packageName: 'com.whatsapp',
    name: 'WhatsApp',
    icon: '💬',
    bg: 'from-emerald-500 to-green-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '42.6 MB',
    version: 'v2.24.8',
    category: 'Messaging',
    description: 'End-to-end encrypted messaging, voice calls, and automated chat workflows.',
  },
  {
    id: 'telegram',
    packageName: 'org.telegram.messenger',
    name: 'Telegram',
    icon: '✈️',
    bg: 'from-sky-400 to-blue-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '48.1 MB',
    version: 'v10.9.1',
    category: 'Messaging',
    description: 'Fast cloud messaging, channel updates, bots, and broadcast feeds.',
  },
  {
    id: 'twitter',
    packageName: 'com.twitter.android',
    name: 'X (Twitter)',
    icon: '𝕏',
    bg: 'from-slate-900 to-slate-800',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '54.2 MB',
    version: 'v10.58.0',
    category: 'Social & News',
    description: 'Real-time tech topics, live breaking news feeds, and automated post checks.',
  },
  {
    id: 'cryptowallet',
    packageName: 'io.metamask',
    name: 'Crypto Wallet',
    icon: '🪙',
    bg: 'from-amber-500 via-orange-600 to-slate-900',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '47.5 MB',
    version: 'v7.29.0',
    category: 'Web3 & Finance',
    description: 'Check token balances, track portfolio valuation, with hardware-guarded transfers.',
  },
  {
    id: 'tinder',
    packageName: 'com.tinder',
    name: 'Tinder',
    icon: '🔥',
    bg: 'from-rose-500 to-pink-600',
    packageType: 'apk' as const,
    platform: 'android' as const,
    size: '58.9 MB',
    version: 'v15.12.0',
    category: 'Lifestyle',
    description: 'Browse profiles, manage matches, and send messages.',
  },
];

// Curated Apple App Store Apps (iOS IPA / WebKit Hybrid)
const IOS_STORE_APPS = [
  {
    id: 'chrome',
    bundleId: 'com.google.chrome.ios',
    launchUrl: 'https://www.google.com',
    name: 'Google Chrome',
    icon: '🌐',
    bg: 'from-blue-500 via-emerald-500 to-amber-500',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '71.2 MB',
    version: 'v131.0.6778',
    category: 'Browser & AI Web',
    description: 'Mobile Chrome browser for iOS with built-in Gemini Web, ChatGPT Web & Claude Web AI Engine.',
  },
  {
    id: 'store-youtube-ios',
    bundleId: 'com.google.ios.youtube',
    launchUrl: 'https://m.youtube.com',
    name: 'YouTube',
    icon: '▶️',
    bg: 'from-red-600 to-rose-700',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '64.2 MB',
    version: 'v19.15.1',
    category: 'Video & Entertainment',
    description: 'Watch video tutorials, music streams, subscribe to channels, and automate video playback.',
  },
  {
    id: 'store-instagram-ios',
    bundleId: 'com.burbn.instagram',
    launchUrl: 'https://www.instagram.com',
    name: 'Instagram',
    icon: '📸',
    bg: 'from-amber-500 via-rose-600 to-purple-600',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '58.3 MB',
    version: 'v326.1',
    category: 'Social Media',
    description: 'iOS edition with reels, stories, direct messages, and interactive feed automation.',
  },
  {
    id: 'store-tiktok-ios',
    bundleId: 'com.zhiliaoapp.musically',
    launchUrl: 'https://www.tiktok.com',
    name: 'TikTok',
    icon: '🎵',
    bg: 'from-slate-900 via-rose-600 to-cyan-500',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '61.5 MB',
    version: 'v34.2.0',
    category: 'Short Video',
    description: 'Browse For You feeds, search creators, like clips, and interact inside iOS WebKit.',
  },
  {
    id: 'store-chatgpt-ios',
    bundleId: 'com.openai.chat',
    launchUrl: 'https://chatgpt.com',
    name: 'ChatGPT',
    icon: '🤖',
    bg: 'from-teal-600 to-emerald-700',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '39.0 MB',
    version: 'v1.2024.11',
    category: 'Productivity',
    description: 'iOS AI assistant with responsive mobile web workspace and live touch targets.',
  },
  {
    id: 'store-x-ios',
    bundleId: 'com.atebits.Tweetie2',
    launchUrl: 'https://x.com',
    name: 'X',
    icon: '𝕏',
    bg: 'from-slate-800 to-black',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '54.0 MB',
    version: 'v10.42.0',
    category: 'Social & News',
    description: 'Real-time timeline, trending topics, posts, and live mobile iOS browsing.',
  },
  {
    id: 'store-spotify-ios',
    bundleId: 'com.spotify.client',
    launchUrl: 'https://open.spotify.com',
    name: 'Spotify',
    icon: '🎧',
    bg: 'from-emerald-500 to-green-700',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '46.0 MB',
    version: 'v8.9.22',
    category: 'Music & Audio',
    description: 'Stream global playlists, podcast episodes, search artists, and control audio playback.',
  },
  {
    id: 'store-applemusic',
    bundleId: 'com.apple.Music',
    launchUrl: 'https://music.apple.com',
    name: 'Apple Music',
    icon: '🎶',
    bg: 'from-rose-500 to-red-600',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '36.8 MB',
    version: 'v4.7.0',
    category: 'Music & Audio',
    description: 'Lossless audio streaming, curated Spatial Audio playlists, and Apple Music Radio.',
  },
  {
    id: 'store-procreate',
    bundleId: 'com.savageinteractive.procreatepocket',
    launchUrl: 'https://procreate.com',
    name: 'Procreate Pocket',
    icon: '🖌️',
    bg: 'from-purple-600 via-pink-600 to-amber-500',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '72.3 MB',
    version: 'v4.0.9',
    category: 'Digital Art',
    description: 'Mobile digital painting, brushes, high-res canvases, and layered artwork studio.',
  },
  {
    id: 'store-things3',
    bundleId: 'com.culturedcode.ThingsiPhone',
    launchUrl: 'https://culturedcode.com/things/',
    name: 'Things 3',
    icon: '📋',
    bg: 'from-blue-600 to-indigo-800',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '24.1 MB',
    version: 'v3.19.4',
    category: 'Productivity',
    description: 'Award-winning task manager, daily planner, project milestone tracking, and checklists.',
  },
  {
    id: 'gmail',
    bundleId: 'com.google.Gmail',
    launchUrl: 'https://mail.google.com',
    name: 'Gmail',
    icon: '✉️',
    bg: 'from-red-500 via-amber-500 to-emerald-500',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '52.0 MB',
    version: 'v6.0.25',
    category: 'Email & Productivity',
    description: 'Read unread inboxes, summarize emails, and manage correspondence on iOS.',
  },
  {
    id: 'whatsapp',
    bundleId: 'net.whatsapp.WhatsApp',
    launchUrl: 'https://web.whatsapp.com',
    name: 'WhatsApp',
    icon: '💬',
    bg: 'from-emerald-500 to-green-600',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '49.8 MB',
    version: 'v25.3.7',
    category: 'Messaging',
    description: 'End-to-end encrypted iOS messaging and voice chats.',
  },
  {
    id: 'telegram',
    bundleId: 'ph.telegra.Telegraph',
    launchUrl: 'https://web.telegram.org',
    name: 'Telegram',
    icon: '✈️',
    bg: 'from-sky-400 to-blue-600',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '54.4 MB',
    version: 'v11.6.0',
    category: 'Messaging',
    description: 'Cloud messaging, broadcast channels, and bot workflows on iOS.',
  },
  {
    id: 'cryptowallet',
    bundleId: 'io.metamask.MetaMask',
    launchUrl: 'https://portfolio.metamask.io',
    name: 'Crypto Wallet',
    icon: '🪙',
    bg: 'from-amber-500 via-orange-600 to-slate-900',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '49.1 MB',
    version: 'v7.29.0',
    category: 'Web3 & Finance',
    description: 'Portfolio tracking & biometric-protected Web3 transactions on iOS.',
  },
  {
    id: 'tinder',
    bundleId: 'com.cardify.tinder',
    launchUrl: 'https://tinder.com',
    name: 'Tinder',
    icon: '🔥',
    bg: 'from-rose-500 to-pink-600',
    packageType: 'ipa' as const,
    platform: 'ios' as const,
    size: '61.2 MB',
    version: 'v15.12.0',
    category: 'Lifestyle',
    description: 'Mobile web and iOS lifestyle profile browsing.',
  },
];

const EMOJI_ICONS = ['📱', '💬', '🎵', '📹', '🛒', '⚡', '🚀', '💻', '📊', '🛡️', '🌐', '📦', '🍔', '📷', '📚', '🤖'];

export const AppInstallerModal: React.FC<AppInstallerModalProps> = ({
  isOpen,
  onClose,
  phonePlatform,
  onPlatformChange,
  onInstallApp,
  installedCount = 0,
  maxApps = MAX_INSTALLED_APPS,
  initialSearchQuery = null,
  onOpenBillingModal,
}) => {
  const [activeTab, setActiveTab] = useState<'store' | 'upload' | 'url'>('store');

  const isLimitReached = installedCount >= maxApps;

  // File Upload State
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [customAppName, setCustomAppName] = useState('');
  const [customIcon, setCustomIcon] = useState('📦');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadedHashInfo, setUploadedHashInfo] = useState<{ hash: string; deduplicated: boolean } | null>(null);

  // Store Direct Install State
  const [storeSearchQuery, setStoreSearchQuery] = useState('');
  const [storeCustomUrlOrName, setStoreCustomUrlOrName] = useState('');

  // Installation Animation State
  const [isInstalling, setIsInstalling] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installStage, setInstallStage] = useState('');
  const [iosEngineInfo, setIosEngineInfo] = useState<{
    engineMode: 'webkit_linux' | 'xcode_simulator';
    engineLabel: string;
  }>({
    engineMode: 'webkit_linux',
    engineLabel: 'iOS WebKit Engine (Free Cloud)',
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (!isOpen) return;
    setUploadError(null);
    if (initialSearchQuery && initialSearchQuery.trim()) {
      const q = initialSearchQuery.trim();
      setActiveTab('store');
      setStoreSearchQuery(q);
      setStoreCustomUrlOrName(q);
    }
  }, [isOpen, initialSearchQuery]);

  React.useEffect(() => {
    if (!isOpen || phonePlatform !== 'ios') return;
    let active = true;
    fetch('/api/ios/status')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!active || !data?.engineMode) return;
        setIosEngineInfo({
          engineMode: data.engineMode,
          engineLabel: data.engineLabel || 'iOS WebKit Engine (Free Cloud)',
        });
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [isOpen, phonePlatform]);

  if (!isOpen) return null;

  const currentStoreUrl = phonePlatform === 'android' ? ANDROID_PLAY_STORE_URL : IOS_APP_STORE_URL;
  const storeTitle = phonePlatform === 'android' ? 'Google Play Store' : 'Apple App Store';
  const packageExtension = phonePlatform === 'android' ? '.apk' : '.ipa';

  const handlePlatformSwitch = (newPlatform: 'android' | 'ios') => {
    if (newPlatform === phonePlatform) return;
    onPlatformChange(newPlatform);
    setUploadedFile(null);
    setUploadError(null);
    sounds.playTap();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const lowerName = file.name.toLowerCase();
    setUploadError(null);

    if (phonePlatform === 'android') {
      const isAndroidFormat =
        lowerName.endsWith('.apk') || lowerName.endsWith('.xapk') || lowerName.endsWith('.aab');
      if (!isAndroidFormat) {
        setUploadError(
          `Incompatible file for Android! You can only upload Android packages (.apk, .xapk, .aab). iOS files are not allowed.`
        );
        sounds.playNotification();
        return;
      }
    } else {
      const isIosFormat =
        lowerName.endsWith('.ipa') || lowerName.endsWith('.app') || lowerName.endsWith('.zip');
      if (!isIosFormat) {
        setUploadError(
          `Incompatible file for iOS! You can only upload Apple iOS packages (.ipa, .app). Android APKs are not allowed.`
        );
        sounds.playNotification();
        return;
      }
    }

    setUploadedFile(file);
    setUploadedHashInfo(null);
    const cleanName = file.name.replace(/\.(apk|ipa|xapk|aab|app|zip)$/i, '');
    setCustomAppName(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    setCustomIcon(phonePlatform === 'android' ? '🤖' : '🍎');
    sounds.playTap();
  };

  const uploadFormDataToInstallApi = (
    endpoint: string,
    formData: FormData,
    onUploadProgress: (pct: number) => void,
    processingStageText: string
  ): Promise<{ ok: boolean; status: number; data: any }> => {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', endpoint, true);
      const authHeaders = getAuthMultipartHeaders();
      Object.entries(authHeaders).forEach(([k, v]) => {
        xhr.setRequestHeader(k, v);
      });

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable && event.total > 0) {
          const pct = Math.min(70, Math.max(5, Math.round((event.loaded / event.total) * 70)));
          onUploadProgress(pct);
          setInstallStage(
            `Uploading package to server (${(event.loaded / (1024 * 1024)).toFixed(2)} / ${(
              event.total /
              (1024 * 1024)
            ).toFixed(2)} MB)...`
          );
        }
      };

      xhr.upload.onload = () => {
        onUploadProgress(75);
        setInstallStage(processingStageText);
      };

      xhr.onload = () => {
        let parsed: any = {};
        try {
          parsed = xhr.responseText ? JSON.parse(xhr.responseText) : {};
        } catch {
          parsed = { error: xhr.responseText || `HTTP ${xhr.status}` };
        }
        resolve({
          ok: xhr.status >= 200 && xhr.status < 300,
          status: xhr.status,
          data: parsed,
        });
      };

      xhr.onerror = () => {
        reject(new Error(`Network error communicating with ${endpoint}.`));
      };

      xhr.send(formData);
    });
  };

  const openBillingPopup = () => {
    onClose();
    if (onOpenBillingModal) {
      onOpenBillingModal();
    } else {
      dispatchOpenBillingModal();
    }
  };

  const executeInstall = async (
    appData: InstalledAppItem,
    source?: { file?: File; url?: string }
  ) => {
    if (isLimitReached) {
      setUploadError(
        `Storage capacity reached! Maximum limit of ${maxApps} installed apps reached (${installedCount}/${maxApps}). Please uninstall an existing app first.`
      );
      sounds.playNotification();
      return;
    }

    setUploadError(null);

    // Pre-flight quota check: App Download & Installation strictly requires 25,000 tokens
    const quotaCheck = await checkServerPreflightQuota(
      `App Installation: ${appData.name}`,
      APP_INSTALL_TOKEN_COST
    );
    if (!quotaCheck.allowed) {
      sounds.playNotification();
      if (quotaCheck.authRequired) {
        setUploadError(
          quotaCheck.error || 'Please sign in and verify your email before installing apps.'
        );
        dispatchOpenAuthModal();
        return;
      }
      setUploadError(
        `Insufficient tokens: installing ${appData.name} requires ${formatTokenCount(
          APP_INSTALL_TOKEN_COST
        )} tokens ($8 = 20,000,000 tokens).`
      );
      openBillingPopup();
      return;
    }

    const isIosTarget = phonePlatform === 'ios' || appData.packageType === 'ipa';

    // Direct Android catalog shortcuts without binary APK/URL install immediately after token deduction
    if (!isIosTarget && !source?.file && !source?.url) {
      const deductRes = await deductServerQuota(
        `App Installation: ${appData.name}`,
        APP_INSTALL_TOKEN_COST,
        `Installed ${appData.name} from Google Play Store catalog`,
        1,
        true
      );
      if (!deductRes.success) {
        sounds.playNotification();
        if (deductRes.authRequired) {
          setUploadError(deductRes.error || 'Verified session required to install apps.');
          dispatchOpenAuthModal();
        } else {
          setUploadError(
            `Insufficient token balance. App installation requires ${formatTokenCount(
              APP_INSTALL_TOKEN_COST
            )} tokens.`
          );
          openBillingPopup();
        }
        return;
      }
      sounds.playSuccess();
      onInstallApp(appData);
      onClose();
      return;
    }

    setIsInstalling(true);
    setInstallProgress(10);
    sounds.playTap();

    // REAL iOS HYBRID ENGINE INSTALL (/api/ios/install)
    if (isIosTarget) {
      setInstallStage(
        source?.file
          ? `Uploading ${source.file.name} to /api/ios/install (${iosEngineInfo.engineLabel})...`
          : `Registering "${appData.name}" with ${iosEngineInfo.engineLabel} (/api/ios/install)...`
      );

      try {
        let response: { ok: boolean; status: number; data: any };

        if (source?.file) {
          const formData = new FormData();
          formData.append('ipa', source.file);
          formData.append('appName', appData.name);
          formData.append('appId', appData.id);
          if (appData.bundleId) formData.append('bundleId', appData.bundleId);
          if (appData.launchUrl) formData.append('launchUrl', appData.launchUrl);
          response = await uploadFormDataToInstallApi(
            '/api/ios/install',
            formData,
            (pct) => setInstallProgress(pct),
            `Registering IPA with ${iosEngineInfo.engineLabel}...`
          );
        } else {
          setInstallProgress(45);
          const fetchRes = await fetch('/api/ios/install', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
              appName: appData.name,
              appId: appData.id,
              bundleId: appData.bundleId,
              url: source?.url,
              launchUrl: appData.launchUrl || source?.url,
            }),
          });
          const data = await fetchRes.json().catch(() => ({}));
          response = { ok: fetchRes.ok, status: fetchRes.status, data };
        }

        if (!response.ok) {
          const errMsg =
            response.data?.error ||
            `iOS installation failed (HTTP ${response.status}).`;
          setIsInstalling(false);
          setInstallProgress(0);
          setInstallStage('');
          setUploadError(errMsg);
          sounds.playNotification();
          if (response.status === 401 || response.status === 403) {
            dispatchOpenAuthModal();
          } else if (response.status === 402) {
            openBillingPopup();
          }
          return;
        }

        const result = response.data || {};
        if (result.engineMode && result.engineLabel) {
          setIosEngineInfo({
            engineMode: result.engineMode,
            engineLabel: result.engineLabel,
          });
        }

        const iosDeductRes = await deductServerQuota(
          `App Installation: ${appData.name}`,
          APP_INSTALL_TOKEN_COST,
          `Installed ${appData.name} (${result.bundleId || 'iOS'})`,
          1,
          true
        );
        if (!iosDeductRes.success) {
          setIsInstalling(false);
          setInstallProgress(0);
          setInstallStage('');
          sounds.playNotification();
          if (iosDeductRes.authRequired) {
            setUploadError(iosDeductRes.error || 'Verified session required to install apps.');
            dispatchOpenAuthModal();
          } else {
            setUploadError(
              `Insufficient token balance. App installation requires ${formatTokenCount(
                APP_INSTALL_TOKEN_COST
              )} tokens.`
            );
            openBillingPopup();
          }
          return;
        }

        setInstallProgress(100);
        setInstallStage(result.message || `✓ Ready in ${result.engineLabel || iosEngineInfo.engineLabel}`);
        sounds.playSuccess();

        const finalIosApp: InstalledAppItem = {
          ...appData,
          packageType: 'ipa',
          platform: 'ios',
          bundleId: result.bundleId || appData.bundleId || `com.omniagent.ios.${appData.id}`,
          launchUrl: result.launchUrl || appData.launchUrl,
          iosEngineMode: result.engineMode || iosEngineInfo.engineMode,
          iosEngineLabel: result.engineLabel || iosEngineInfo.engineLabel,
          fileHash: result.sha256 || appData.fileHash,
          deduplicated:
            typeof result.deduplicated === 'boolean' ? result.deduplicated : appData.deduplicated,
          size:
            typeof result.sizeBytes === 'number' && result.sizeBytes > 0
              ? `${(result.sizeBytes / (1024 * 1024)).toFixed(2)} MB`
              : appData.size,
          description:
            result.message ||
            `${result.engineLabel || iosEngineInfo.engineLabel} (${result.bundleId || appData.bundleId})`,
        };

        setIsInstalling(false);
        onInstallApp(finalIosApp);
        onClose();
        return;
      } catch (err: any) {
        setIsInstalling(false);
        setInstallProgress(0);
        setInstallStage('');
        setUploadError(err?.message || 'Real iOS installation request failed.');
        sounds.playNotification();
        return;
      }
    }

    // REAL ANDROID ADB INSTALL (/api/apps/install)
    setInstallStage(
      source?.file
        ? `Uploading ${source.file.name} to backend /api/apps/install...`
        : `Downloading & installing APK from ${source?.url}...`
    );

    try {
      const formData = new FormData();
      if (source?.file) {
        formData.append('apk', source.file);
      }
      if (source?.url) {
        formData.append('url', source.url);
      }
      formData.append('appName', appData.name);

      const response = await uploadFormDataToInstallApi(
        '/api/apps/install',
        formData,
        (pct) => {
          setInstallProgress(pct);
        },
        'Computing SHA-256 hash, deduplicating in /tmp/omniagent_apk_cache, and running adb install -r...'
      );

      if (!response.ok) {
        const errMsg =
          response.data?.error ||
          `Installation failed (HTTP ${response.status}). Ensure a real ADB/Redroid container is reachable.`;
        setIsInstalling(false);
        setInstallProgress(0);
        setInstallStage('');
        setUploadError(errMsg);
        sounds.playNotification();
        if (response.status === 401 || response.status === 403) {
          dispatchOpenAuthModal();
        } else if (response.status === 402) {
          openBillingPopup();
        }
        return;
      }

      const result = response.data || {};
      const resolvedPackageName = result.packageName || appData.packageName || appData.id;

      const adbDeductRes = await deductServerQuota(
        `App Installation: ${appData.name}`,
        APP_INSTALL_TOKEN_COST,
        `Installed ${appData.name} (${resolvedPackageName}) via ADB`,
        1,
        true
      );
      if (!adbDeductRes.success) {
        setIsInstalling(false);
        setInstallProgress(0);
        setInstallStage('');
        sounds.playNotification();
        if (adbDeductRes.authRequired) {
          setUploadError(adbDeductRes.error || 'Verified session required to install apps.');
          dispatchOpenAuthModal();
        } else {
          setUploadError(
            `Insufficient token balance. App installation requires ${formatTokenCount(
              APP_INSTALL_TOKEN_COST
            )} tokens.`
          );
          openBillingPopup();
        }
        return;
      }

      setInstallProgress(100);
      setInstallStage(
        `✓ Installed "${resolvedPackageName}" via ADB (${result.adbTarget || '127.0.0.1:5555'})${
          result.deduplicated ? ' • SHA-256 deduplicated in cache' : ''
        }`
      );
      sounds.playSuccess();

      const finalApp: InstalledAppItem = {
        ...appData,
        packageName: resolvedPackageName,
        adbTarget: result.adbTarget || appData.adbTarget,
        fileHash: result.sha256 || appData.fileHash,
        deduplicated:
          typeof result.deduplicated === 'boolean' ? result.deduplicated : appData.deduplicated,
        size:
          typeof result.sizeBytes === 'number' && result.sizeBytes > 0
            ? `${(result.sizeBytes / (1024 * 1024)).toFixed(2)} MB`
            : appData.size,
        description: `Real Android package (${resolvedPackageName}) installed on ${
          result.adbTarget || 'ADB container'
        }. SHA-256: ${(result.sha256 || '').slice(0, 12)}…`,
      };

      setIsInstalling(false);
      onInstallApp(finalApp);
      onClose();
    } catch (err: any) {
      setIsInstalling(false);
      setInstallProgress(0);
      setInstallStage('');
      setUploadError(err?.message || 'Real APK installation request failed.');
      sounds.playNotification();
    }
  };

  const handleInstallUploaded = async () => {
    if (!uploadedFile) {
      setUploadError('Please select a file to install.');
      return;
    }

    const vaultResult = await savePackageFileWithDedup(uploadedFile);
    setUploadedHashInfo({
      hash: vaultResult.hash,
      deduplicated: vaultResult.deduplicated,
    });

    const name = customAppName.trim() || uploadedFile.name.replace(/\.[^/.]+$/, '') || 'Custom App';
    const id = `installed-${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}`;
    const size = `${(uploadedFile.size / (1024 * 1024)).toFixed(1)} MB`;

    await executeInstall(
      {
        id,
        name,
        icon: customIcon,
        bg:
          phonePlatform === 'android'
            ? 'from-emerald-600 via-teal-600 to-green-700'
            : 'from-blue-600 via-indigo-600 to-purple-700',
        packageType: phonePlatform === 'android' ? 'apk' : 'ipa',
        platform: phonePlatform,
        size,
        version: phonePlatform === 'android' ? 'v1.0.0-adb' : 'v1.0.0-ios',
        description:
          phonePlatform === 'android'
            ? `Real Android package (${name}) installed via ADB container bridge.`
            : `Real iOS package (${name}) registered with ${iosEngineInfo.engineLabel}.`,
        isCustom: true,
        fileHash: vaultResult.hash,
        deduplicated: vaultResult.deduplicated,
        installedAt: new Date().toISOString(),
      },
      { file: uploadedFile }
    );
  };

  const handleInstallStoreApp = (
    storeApp: (typeof ANDROID_STORE_APPS)[0] | (typeof IOS_STORE_APPS)[0]
  ) => {
    const resolvedId = storeApp.id === 'chrome' && phonePlatform === 'android' ? 'chrome' : `${storeApp.id}-${Date.now()}`;
    const pkgName = 'packageName' in storeApp ? storeApp.packageName : undefined;
    const bundleId = 'bundleId' in storeApp ? storeApp.bundleId : undefined;
    const launchUrl = 'launchUrl' in storeApp ? storeApp.launchUrl : undefined;
    void executeInstall({
      id: resolvedId,
      name: storeApp.name,
      icon: storeApp.icon,
      bg: storeApp.bg,
      packageType: storeApp.packageType,
      platform: storeApp.platform,
      size: storeApp.size,
      version: storeApp.version,
      description: storeApp.description,
      storeUrl: currentStoreUrl,
      packageName: pkgName,
      bundleId,
      launchUrl,
      isCustom: true,
    });
  };

  const handleInstallCustomStoreInput = async () => {
    const input = storeCustomUrlOrName.trim();
    if (!input) return;

    const isUrl = /^https?:\/\//i.test(input);
    let appName = customAppName.trim() || input;
    if (isUrl && !customAppName.trim()) {
      try {
        const urlObj = new URL(input);
        const idParam = urlObj.searchParams.get('id');
        if (idParam) {
          appName = idParam.split('.').pop() || 'Remote APK';
        } else {
          appName =
            urlObj.pathname
              .split('/')
              .filter(Boolean)
              .pop()
              ?.replace(/\.(apk|ipa|xapk|aab)$/i, '') || 'Remote APK';
        }
      } catch {
        appName = 'Remote APK';
      }
      appName = appName.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
    }

    const id = `store-custom-${appName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}`;
    await executeInstall(
      {
        id,
        name: appName,
        icon: phonePlatform === 'android' ? '🤖' : '🍎',
        bg:
          phonePlatform === 'android'
            ? 'from-teal-600 via-emerald-600 to-cyan-700'
            : 'from-indigo-600 via-purple-600 to-pink-700',
        packageType: phonePlatform === 'android' ? 'apk' : 'ipa',
        platform: phonePlatform,
        size: 'Pending',
        version: 'v1.0.0',
        description: `Downloaded from ${isUrl ? input : storeTitle}.`,
        storeUrl: isUrl ? input : currentStoreUrl,
        isCustom: true,
      },
      isUrl ? { url: input } : undefined
    );
  };

  const availableCatalog = phonePlatform === 'android' ? ANDROID_STORE_APPS : IOS_STORE_APPS;
  const filteredCatalog = availableCatalog.filter(
    (app) =>
      app.name.toLowerCase().includes(storeSearchQuery.toLowerCase()) ||
      app.category.toLowerCase().includes(storeSearchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col text-slate-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center font-bold shadow-md ${
                phonePlatform === 'android'
                  ? 'bg-gradient-to-tr from-emerald-500 to-teal-500 text-slate-950'
                  : 'bg-gradient-to-tr from-blue-500 to-indigo-500 text-white'
              }`}
            >
              {phonePlatform === 'android' ? (
                <Smartphone className="w-5 h-5" />
              ) : (
                <Apple className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2 flex-wrap">
                <span>App Installer & Store Hub</span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold uppercase ${
                    phonePlatform === 'android'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                      : 'bg-blue-950/80 text-blue-300 border-blue-500/40'
                  }`}
                >
                  {phonePlatform === 'android' ? 'Android (APK)' : 'iOS (IPA)'}
                </span>
                {phonePlatform === 'ios' && (
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${
                      iosEngineInfo.engineMode === 'xcode_simulator'
                        ? 'bg-indigo-950/80 text-indigo-300 border-indigo-500/40'
                        : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                    }`}
                  >
                    {iosEngineInfo.engineLabel}
                  </span>
                )}
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${
                    isLimitReached
                      ? 'bg-rose-950/90 text-rose-300 border-rose-500/60 animate-pulse'
                      : installedCount >= maxApps - 5
                      ? 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {installedCount}/{maxApps} Apps {isLimitReached ? '(MAX REACHED)' : '(Max 40)'}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Install apps from {storeTitle} or upload packages • Cost:{' '}
                <span className="font-mono font-semibold text-amber-300">
                  {formatTokenCount(APP_INSTALL_TOKEN_COST)} tokens
                </span>{' '}
                / install
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Selector Switch (Android vs iOS) */}
        <div className="px-5 pt-3 pb-2 bg-slate-950/60 border-b border-slate-800">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold text-slate-300">
              Select Phone Platform (The selected platform stands):
            </span>
            <span className="text-[10px] text-amber-400/90 font-mono">
              Switching uninstalls incompatible apps
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handlePlatformSwitch('android')}
              className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition cursor-pointer ${
                phonePlatform === 'android'
                  ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300 shadow-sm ring-1 ring-emerald-500/50'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Android (.apk / .xapk)</span>
              {phonePlatform === 'android' && (
                <Check className="w-3.5 h-3.5 text-emerald-400 ml-auto" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handlePlatformSwitch('ios')}
              className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition cursor-pointer ${
                phonePlatform === 'ios'
                  ? 'bg-blue-600/30 border-blue-500 text-blue-300 shadow-sm ring-1 ring-blue-500/50'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <Apple className="w-4 h-4 text-blue-400" />
              <span>Apple iOS (.ipa / .app)</span>
              {phonePlatform === 'ios' && (
                <Check className="w-3.5 h-3.5 text-blue-400 ml-auto" />
              )}
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-5 pt-3 gap-2 text-xs bg-slate-900/50">
          <button
            onClick={() => setActiveTab('store')}
            className={`pb-2.5 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'store'
                ? phonePlatform === 'android'
                  ? 'border-emerald-400 text-emerald-300 font-bold'
                  : 'border-blue-400 text-blue-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Get Apps ({storeTitle})</span>
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-2.5 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'upload'
                ? phonePlatform === 'android'
                  ? 'border-emerald-400 text-emerald-300 font-bold'
                  : 'border-blue-400 text-blue-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload {packageExtension.toUpperCase()} File</span>
          </button>
          <button
            onClick={() => setActiveTab('url')}
            className={`pb-2.5 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'url'
                ? phonePlatform === 'android'
                  ? 'border-emerald-400 text-emerald-300 font-bold'
                  : 'border-blue-400 text-blue-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install by URL</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto max-h-[60vh]">
          {/* Ongoing Install Progress Overlay */}
          {isInstalling ? (
            <div className="py-8 space-y-4 text-center">
              <div
                className={`w-16 h-16 mx-auto rounded-3xl flex items-center justify-center animate-pulse ${
                  phonePlatform === 'android'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                }`}
              >
                <Cpu className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-white">Installing Application...</h4>
                <p className="text-xs text-slate-400">{installStage}</p>
              </div>
              {/* Progress Bar */}
              <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                <div
                  className={`h-full transition-all duration-300 rounded-full ${
                    phonePlatform === 'android'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-400'
                  }`}
                  style={{ width: `${installProgress}%` }}
                />
              </div>
              <span
                className={`text-xs font-mono font-bold ${
                  phonePlatform === 'android' ? 'text-emerald-400' : 'text-blue-400'
                }`}
              >
                {installProgress}%
              </span>
            </div>
          ) : (
            <>
              {/* Server / ADB Installation Error Banner (Visible Across All Tabs) */}
              {uploadError && activeTab !== 'upload' && (
                <div className="bg-rose-950/70 border border-rose-700/80 rounded-2xl p-3.5 flex items-start gap-2.5 text-xs text-rose-200 mb-4 font-mono">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  <span className="break-words">{uploadError}</span>
                </div>
              )}

              {/* Maximum 40 Apps Limit Alert Banner */}
              {isLimitReached && (
                <div className="bg-rose-950/70 border border-rose-800/80 rounded-2xl p-3.5 flex items-start gap-3 text-xs text-rose-200 mb-4 animate-in fade-in">
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-rose-100">
                      Maximum Limit of {maxApps} Installed Apps Reached ({installedCount}/{maxApps})
                    </p>
                    <p className="text-[11px] text-rose-300/90 leading-relaxed">
                      The phone simulator restricts installations to a maximum of {maxApps} apps whether via Android APK, Apple iOS IPA, or Store downloads. Please uninstall an existing app from the phone to free up space.
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 1: GET APPS / OFFICIAL STORE HUB */}
              {activeTab === 'store' && (
                <div className="space-y-4">
                  {initialSearchQuery && initialSearchQuery.trim() && (
                    <div className="rounded-xl px-3.5 py-2.5 bg-slate-950 border border-amber-500/40 flex items-center justify-between gap-2 text-xs">
                      <div className="min-w-0">
                        <span className="font-bold text-amber-300">
                          {storeTitle} Pre-Selected:
                        </span>{' '}
                        <span className="text-slate-200">
                          Click Install on <strong>{initialSearchQuery}</strong> below to resume your queued task.
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setStoreSearchQuery('');
                          setStoreCustomUrlOrName('');
                        }}
                        className="text-[11px] font-semibold text-slate-400 hover:text-white shrink-0 cursor-pointer"
                      >
                        Show All
                      </button>
                    </div>
                  )}

                  {/* Official Store Card with the user's specific store links */}
                  <div
                    className={`rounded-2xl p-4 border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      phonePlatform === 'android'
                        ? 'bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border-emerald-500/40'
                        : 'bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/60 border-blue-500/40'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {phonePlatform === 'android' ? (
                          <Smartphone className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Apple className="w-4 h-4 text-blue-400" />
                        )}
                        <h4 className="font-bold text-xs text-white">
                          Official {storeTitle} Link
                        </h4>
                      </div>
                      <p className="text-[11px] text-slate-300">
                        {phonePlatform === 'android'
                          ? 'Browse Google Play Store to discover apps or download APKs for the phone.'
                          : `Runs via ${iosEngineInfo.engineLabel} — install Apple catalog web apps, PWA URLs, or .ipa packages.`}
                      </p>
                    </div>

                    {/* Prominent GET APPS Button */}
                    <a
                      href={currentStoreUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md flex items-center justify-center gap-2 shrink-0 transition hover:scale-105 active:scale-95 ${
                        phonePlatform === 'android'
                          ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950'
                          : 'bg-blue-600 hover:bg-blue-500 shadow-blue-950'
                      }`}
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Get Apps</span>
                      <ExternalLink className="w-3 h-3 opacity-80" />
                    </a>
                  </div>

                  {/* Install by Store URL or App Name */}
                  <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3 space-y-2">
                    <label className="block text-[11px] font-semibold text-slate-300">
                      Download & Install Any App from Store Link or Name:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={storeCustomUrlOrName}
                        onChange={(e) => setStoreCustomUrlOrName(e.target.value)}
                        placeholder={
                          phonePlatform === 'android'
                            ? 'Paste Google Play link or type app name (e.g. YouTube, Spotify)'
                            : 'Paste App Store link or type app name (e.g. Procreate, Things 3)'
                        }
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleInstallCustomStoreInput();
                        }}
                      />
                      <button
                        type="button"
                        onClick={handleInstallCustomStoreInput}
                        disabled={isLimitReached || !storeCustomUrlOrName.trim()}
                        className={`px-3 py-2 rounded-xl text-xs font-bold text-white transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5 shrink-0 ${
                          isLimitReached
                            ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                            : phonePlatform === 'android'
                            ? 'bg-emerald-600 hover:bg-emerald-500'
                            : 'bg-blue-600 hover:bg-blue-500'
                        }`}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{isLimitReached ? `Limit (${maxApps}/${maxApps})` : 'Install to Phone'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Store Catalog Header & Search */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">
                          1-Click Install Catalog ({filteredCatalog.length})
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {phonePlatform === 'android' ? 'Android APKs' : 'Apple IPAs'}
                        </span>
                      </div>
                      <div className="relative w-40">
                        <Search className="w-3 h-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          type="text"
                          value={storeSearchQuery}
                          onChange={(e) => setStoreSearchQuery(e.target.value)}
                          placeholder="Filter apps..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-7 pr-2 py-1 text-[11px] text-white focus:outline-hidden"
                        />
                      </div>
                    </div>

                    {/* Apps Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {filteredCatalog.map((app) => (
                        <div
                          key={app.id}
                          className="bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-2xl p-3 flex items-center justify-between gap-3 group transition"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div
                              className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${app.bg} flex items-center justify-center text-lg shrink-0 shadow-sm`}
                            >
                              {app.icon}
                            </div>
                            <div className="min-w-0">
                              <h5 className="font-bold text-xs text-white truncate">{app.name}</h5>
                              <div className="flex items-center gap-1.5 text-[9px] font-mono text-slate-400">
                                <span
                                  className={`font-bold uppercase ${
                                    phonePlatform === 'android' ? 'text-emerald-400' : 'text-blue-400'
                                  }`}
                                >
                                  {app.packageType}
                                </span>
                                <span>•</span>
                                <span>{app.size}</span>
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleInstallStoreApp(app)}
                            disabled={isLimitReached}
                            className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold text-white flex items-center gap-1 transition shrink-0 active:scale-95 cursor-pointer ${
                              isLimitReached
                                ? 'bg-slate-800 text-slate-400 cursor-not-allowed opacity-60'
                                : phonePlatform === 'android'
                                ? 'bg-emerald-600/90 hover:bg-emerald-500'
                                : 'bg-blue-600/90 hover:bg-blue-500'
                            }`}
                            title={isLimitReached ? `Maximum limit of ${maxApps} apps reached` : `Install ${app.name}`}
                          >
                            <Download className="w-3 h-3" />
                            <span>{isLimitReached ? 'Full (40/40)' : 'Install'}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: UPLOAD FILE (Platform-Restricted) */}
              {activeTab === 'upload' && (
                <div className="space-y-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={phonePlatform === 'android' ? '.apk,.xapk,.aab' : '.ipa,.app'}
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  {/* Warning Notice about Platform Compatibility */}
                  <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex items-start gap-2.5 text-xs">
                    <ShieldCheck
                      className={`w-4 h-4 shrink-0 mt-0.5 ${
                        phonePlatform === 'android' ? 'text-emerald-400' : 'text-blue-400'
                      }`}
                    />
                    <div>
                      <p className="font-semibold text-slate-200">
                        {phonePlatform === 'android'
                          ? 'Android Mode Active: Only .apk / .xapk / .aab files are allowed.'
                          : 'Apple iOS Mode Active: Only .ipa / .app files are allowed.'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Incompatible packages for the other OS are automatically rejected.
                      </p>
                    </div>
                  </div>

                  {uploadError && (
                    <div className="bg-rose-950/60 border border-rose-800/80 rounded-xl p-3 flex items-center gap-2 text-xs text-rose-300">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{uploadError}</span>
                    </div>
                  )}

                  {/* Drag and Drop Box */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition bg-slate-950/60 hover:bg-slate-950 group space-y-2 ${
                      phonePlatform === 'android'
                        ? 'border-emerald-500/40 hover:border-emerald-500'
                        : 'border-blue-500/40 hover:border-blue-500'
                    }`}
                  >
                    <div
                      className={`w-12 h-12 mx-auto rounded-2xl flex items-center justify-center group-hover:scale-110 transition border ${
                        phonePlatform === 'android'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                      }`}
                    >
                      <Upload className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">
                        {uploadedFile
                          ? uploadedFile.name
                          : `Click or drop any ${phonePlatform === 'android' ? 'Android APK' : 'Apple iOS IPA'} file here`}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {phonePlatform === 'android'
                          ? 'Allowed formats: .apk, .xapk, .aab'
                          : 'Allowed formats: .ipa, .app'}
                      </p>
                    </div>
                    {uploadedFile && (
                      <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                        <span className="text-[10px] font-mono bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                          {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB
                        </span>
                        <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-bold uppercase">
                          {phonePlatform === 'android' ? 'Android APK' : 'iOS IPA'}
                        </span>
                        <span className="text-[10px] font-mono bg-purple-950/80 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full font-bold">
                          {uploadedHashInfo
                            ? uploadedHashInfo.deduplicated
                              ? `SHA-256 Dedup (${uploadedHashInfo.hash.slice(0, 8)})`
                              : `SHA-256 Vault (${uploadedHashInfo.hash.slice(0, 8)})`
                            : 'Browser IndexedDB + SHA-256 Dedup'}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* App Configuration Details */}
                  <div className="space-y-3 pt-1">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Application Display Name
                      </label>
                      <input
                        type="text"
                        value={customAppName}
                        onChange={(e) => setCustomAppName(e.target.value)}
                        placeholder={`e.g. My ${phonePlatform === 'android' ? 'Android' : 'iOS'} App`}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Platform Format
                        </label>
                        <div
                          className={`py-2 px-3 rounded-xl text-xs font-bold border flex items-center gap-2 ${
                            phonePlatform === 'android'
                              ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                              : 'bg-blue-950/40 border-blue-500/50 text-blue-300'
                          }`}
                        >
                          {phonePlatform === 'android' ? (
                            <Smartphone className="w-3.5 h-3.5" />
                          ) : (
                            <Apple className="w-3.5 h-3.5" />
                          )}
                          <span>{phonePlatform === 'android' ? 'Android APK' : 'Apple IPA'}</span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          App Icon
                        </label>
                        <div className="flex gap-1 overflow-x-auto pb-1">
                          {EMOJI_ICONS.slice(0, 7).map((emoji) => (
                            <button
                              key={emoji}
                              type="button"
                              onClick={() => setCustomIcon(emoji)}
                              className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm border shrink-0 transition cursor-pointer ${
                                customIcon === emoji
                                  ? phonePlatform === 'android'
                                    ? 'bg-emerald-600 border-emerald-400 text-white'
                                    : 'bg-blue-600 border-blue-400 text-white'
                                  : 'bg-slate-950 border-slate-800 text-slate-300'
                              }`}
                            >
                              {emoji}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleInstallUploaded}
                      disabled={isLimitReached || !uploadedFile}
                      className={`w-full py-2.5 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition active:scale-95 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                        isLimitReached
                          ? 'bg-slate-800 text-slate-400'
                          : phonePlatform === 'android'
                          ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-950'
                          : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-950'
                      }`}
                    >
                      <Package className="w-4 h-4" />
                      <span>
                        {isLimitReached
                          ? `Max Limit Reached (${maxApps}/${maxApps} Apps)`
                          : `Install & Sideload to ${phonePlatform === 'android' ? 'Android' : 'iOS'}`}
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 3: DOWNLOAD VIA URL */}
              {activeTab === 'url' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {phonePlatform === 'android' ? 'Android APK' : 'Apple IPA'} Download URL
                    </label>
                    <input
                      type="url"
                      value={storeCustomUrlOrName}
                      onChange={(e) => setStoreCustomUrlOrName(e.target.value)}
                      placeholder={
                        phonePlatform === 'android'
                          ? 'https://example.com/downloads/package.apk'
                          : 'https://example.com/downloads/package.ipa'
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      App Label Name
                    </label>
                    <input
                      type="text"
                      value={customAppName}
                      onChange={(e) => setCustomAppName(e.target.value)}
                      placeholder="e.g. Remote Downloaded App"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleInstallCustomStoreInput}
                    disabled={isLimitReached || !storeCustomUrlOrName.trim()}
                    className={`w-full py-2.5 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer ${
                      isLimitReached
                        ? 'bg-slate-800 text-slate-400'
                        : phonePlatform === 'android'
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                    <span>
                      {isLimitReached
                        ? `Max Limit Reached (${maxApps}/${maxApps} Apps)`
                        : 'Download & Sideload'}
                    </span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
