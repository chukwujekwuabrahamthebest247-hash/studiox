/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  Sparkles,
  Globe,
  ExternalLink,
  Code2,
  Send,
  Zap,
  Tag,
  CheckCircle2,
} from 'lucide-react';
import { PhoneAppType } from '../../types/phone';
import { PublicWorkflowTemplate } from '../../types/workflowShare';
import {
  publishWorkflow,
  getWorkflowShareUrl,
} from '../../utils/workflowStore';

interface ShareWorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  initialApp?: PhoneAppType;
  initialTitle?: string;
  onWorkflowPublished?: (wf: PublicWorkflowTemplate) => void;
}

export const ShareWorkflowModal: React.FC<ShareWorkflowModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
  initialApp = 'browser',
  initialTitle = '',
  onWorkflowPublished,
}) => {
  const [title, setTitle] = useState(
    initialTitle ||
      (initialPrompt.toLowerCase().includes('lead')
        ? 'Automated Lead Scraper'
        : initialPrompt.slice(0, 36) || 'My Automated Phone Workflow')
  );
  const [description, setDescription] = useState(
    'Runs autonomously across installed apps, extracting key insights and completing multi-step mobile tasks.'
  );
  const [prompt, setPrompt] = useState(initialPrompt || 'Open SearchGlobe browser, search for top AI startups, and compile contacts into Notes.');
  const [targetApp, setTargetApp] = useState<PhoneAppType | 'all'>(initialApp || 'all');
  const [authorName, setAuthorName] = useState('Abraham (Creator)');
  const [tagsInput, setTagsInput] = useState('Lead Scraper, Productivity, Automation');
  
  const [publishedWorkflow, setPublishedWorkflow] = useState<PublicWorkflowTemplate | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !prompt.trim()) return;

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const wf = publishWorkflow({
      title,
      description,
      prompt,
      targetApp,
      authorName,
      tags,
    });

    setPublishedWorkflow(wf);
    if (onWorkflowPublished) {
      onWorkflowPublished(wf);
    }
  };

  const handleCopyLink = () => {
    if (!publishedWorkflow) return;
    const url = getWorkflowShareUrl(publishedWorkflow);
    navigator.clipboard.writeText(url).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 3000);
    });
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-emerald-950/30 to-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>1-Click "Share Workflow" Link</span>
                <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  Public Template
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Publish any automation so anyone who clicks signs up to run it
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {!publishedWorkflow ? (
            <form onSubmit={handlePublish} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Workflow Template Name (e.g. "Copy my Automated Lead Scraper")
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Copy my Automated Lead Scraper"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Description & Value Pitch
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what this automation accomplishes..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Executable Prompt Instruction
                </label>
                <textarea
                  rows={3}
                  required
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="The exact prompt that the agent executes..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono text-emerald-300 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Primary App Target
                  </label>
                  <select
                    value={targetApp}
                    onChange={(e) => setTargetApp(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    <option value="all">Cross-App (Any installed app)</option>
                    <option value="browser">SearchGlobe Browser</option>
                    <option value="notes">Notes App</option>
                    <option value="social">Social Network</option>
                    <option value="messages">Messages</option>
                    <option value="food">Food Delivery</option>
                    <option value="settings">Settings</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Creator Name / Handle
                  </label>
                  <input
                    type="text"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    placeholder="e.g. Abraham (Creator)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="Leads, Scraper, Sales, Growth"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 cursor-pointer transition active:scale-98"
              >
                <Sparkles className="w-4 h-4" />
                <span>Publish & Generate 1-Click Link</span>
              </button>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-bold text-emerald-200">
                    Workflow published successfully as a public template!
                  </p>
                  <p className="text-slate-300">
                    Anyone who visits this link will see your automation card and can run it immediately with their free trial quota.
                  </p>
                </div>
              </div>

              {/* Shareable Link Box */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  1-Click Public Template Link:
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-emerald-400 overflow-x-auto whitespace-nowrap">
                    {getWorkflowShareUrl(publishedWorkflow)}
                  </div>
                  <button
                    onClick={handleCopyLink}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                      isCopied
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
                    }`}
                  >
                    {isCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{isCopied ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                </div>
              </div>

              {/* Public Preview Card */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
                    Recipient Preview Card
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono">
                    ~{publishedWorkflow.estimatedTokens} tokens • {publishedWorkflow.estimatedSeconds}s execution
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white">
                  {publishedWorkflow.title}
                </h3>
                <p className="text-xs text-slate-300">
                  {publishedWorkflow.description}
                </p>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-emerald-300">
                  "{publishedWorkflow.prompt}"
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>Author: <strong className="text-white">{publishedWorkflow.author}</strong></span>
                  <span className="text-emerald-400 font-semibold">1-Click Clone & Run Ready</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setPublishedWorkflow(null)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition"
                >
                  Edit & Publish Another
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer transition"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
