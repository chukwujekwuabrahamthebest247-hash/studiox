/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Key,
  ShieldCheck,
  CheckCircle2,
  X,
  RefreshCw,
  Globe,
  Sparkles,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  AlertCircle,
  Chrome,
  PlugZap,
  Smartphone,
  Layers,
  ExternalLink,
} from 'lucide-react';
import { sounds } from '../../utils/soundEffects';
import {
  ChromeBridgeConfig,
  ChromeBridgePingResult,
  ChromeBridgeProvider,
  pingChromeBridge,
} from '../../utils/chromeWebBridge';
import {
  CHROME_PROVIDER_META,
  DEFAULT_IN_PHONE_CHROME_CONFIG,
  InPhoneChromeConfig,
  InPhoneChromeProvider,
  InPhoneChromeVisualMode,
} from '../../utils/inPhoneChromeEngine';

export type ApiModalTab =
  | 'openrouter'
  | 'serper'
  | 'tavily'
  | 'in_phone_chrome'
  | 'chrome_bridge';

export type { ChromeBridgeConfig, InPhoneChromeConfig };

export interface OpenRouterConfig {
  apiKey: string;
  apiKeys?: string[];
  model: string;
  isVerified: boolean;
  verifiedAt?: string;
  latency?: string;
}

export interface SerperConfig {
  apiKey: string;
  apiKeys?: string[];
  isVerified: boolean;
  verifiedAt?: string;
  latency?: string;
}

export interface TavilyConfig {
  apiKey: string;
  apiKeys?: string[];
  isVerified: boolean;
  verifiedAt?: string;
  latency?: string;
}

interface OpenRouterModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: ApiModalTab;
  config: OpenRouterConfig;
  onSaveConfig: (config: OpenRouterConfig) => void;
  serperConfig: SerperConfig;
  onSaveSerperConfig: (config: SerperConfig) => void;
  tavilyConfig: TavilyConfig;
  onSaveTavilyConfig: (config: TavilyConfig) => void;
  inPhoneChromeConfig?: InPhoneChromeConfig;
  onSaveInPhoneChromeConfig?: (config: InPhoneChromeConfig) => void;
  isChromeInstalledOnPhone?: boolean;
  onInstallAndLaunchChrome?: () => void;
  chromeBridgeConfig?: ChromeBridgeConfig;
  onSaveChromeBridgeConfig?: (config: ChromeBridgeConfig) => void;
}

const DEFAULT_CHROME_BRIDGE_CONFIG: ChromeBridgeConfig = {
  enabled: false,
  preferredProvider: 'auto',
  timeoutMs: 28000,
};

export const OpenRouterModal: React.FC<OpenRouterModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'openrouter',
  config,
  onSaveConfig,
  serperConfig,
  onSaveSerperConfig,
  tavilyConfig,
  onSaveTavilyConfig,
  inPhoneChromeConfig = DEFAULT_IN_PHONE_CHROME_CONFIG,
  onSaveInPhoneChromeConfig,
  isChromeInstalledOnPhone = true,
  onInstallAndLaunchChrome,
  chromeBridgeConfig = DEFAULT_CHROME_BRIDGE_CONFIG,
  onSaveChromeBridgeConfig,
}) => {
  const [activeTab, setActiveTab] = useState<ApiModalTab>(initialTab);
  const [orKey, setOrKey] = useState(config.apiKey);
  const [orModel, setOrModel] = useState(config.model || 'nvidia/nemotron-3.5-super-vl:free');
  const [serperKey, setSerperKey] = useState(serperConfig.apiKey);
  const [tavilyKey, setTavilyKey] = useState(tavilyConfig.apiKey);
  const [isVerifying, setIsVerifying] = useState(false);

  // Chrome Bridge State
  const [isTestingBridge, setIsTestingBridge] = useState(false);
  const [bridgePingResult, setBridgePingResult] = useState<ChromeBridgePingResult | null>(null);

  // Security Password Gate State (protects API key vault tabs)
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [isCheckingPassword, setIsCheckingPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const isKeyProtectedTab =
    activeTab === 'openrouter' || activeTab === 'serper' || activeTab === 'tavily';

  const handleUnlockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const candidate = passwordInput.trim();
    if (!candidate) {
      sounds.playNotification();
      setPasswordError('Please enter the master authorization password.');
      return;
    }

    setIsCheckingPassword(true);
    setPasswordError(null);
    try {
      const res = await fetch('/api/admin/verify-vault', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: candidate }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.verified) {
        sounds.playSuccess();
        setIsUnlocked(true);
        setPasswordError(null);
        setPasswordInput('');
      } else {
        sounds.playNotification();
        setPasswordError(
          data?.error || 'Access Denied: Incorrect authorization password.'
        );
      }
    } catch {
      sounds.playNotification();
      setPasswordError('Unable to reach server vault verification endpoint.');
    } finally {
      setIsCheckingPassword(false);
    }
  };

  const handleClose = () => {
    // Reset unlock state on close so password is required each time key vault opens
    setIsUnlocked(false);
    setPasswordInput('');
    setPasswordError(null);
    onClose();
  };

  const handleLockVault = () => {
    sounds.playTap();
    setIsUnlocked(false);
    setPasswordInput('');
    setPasswordError(null);
  };

  const handleVerifyOpenRouter = async () => {
    setIsVerifying(true);
    await new Promise((r) => setTimeout(r, 600));
    setIsVerifying(false);
    onSaveConfig({
      ...config,
      apiKey: orKey,
      model: orModel,
      isVerified: Boolean(orKey),
      verifiedAt: new Date().toLocaleTimeString(),
      latency: '24ms',
    });
  };

  const handleVerifySerper = async () => {
    setIsVerifying(true);
    await new Promise((r) => setTimeout(r, 500));
    setIsVerifying(false);
    onSaveSerperConfig({
      ...serperConfig,
      apiKey: serperKey,
      isVerified: Boolean(serperKey),
      verifiedAt: new Date().toLocaleTimeString(),
      latency: '18ms',
    });
  };

  const handleVerifyTavily = async () => {
    setIsVerifying(true);
    await new Promise((r) => setTimeout(r, 500));
    setIsVerifying(false);
    onSaveTavilyConfig({
      ...tavilyConfig,
      apiKey: tavilyKey,
      isVerified: Boolean(tavilyKey),
      verifiedAt: new Date().toLocaleTimeString(),
      latency: '32ms',
    });
  };

  const handleToggleInPhoneChrome = () => {
    sounds.playTap();
    onSaveInPhoneChromeConfig?.({
      ...inPhoneChromeConfig,
      enabled: !inPhoneChromeConfig.enabled,
    });
  };

  const handleChangeInPhoneModel = (aiModel: InPhoneChromeProvider) => {
    sounds.playTap();
    onSaveInPhoneChromeConfig?.({
      ...inPhoneChromeConfig,
      aiModel,
    });
  };

  const handleChangeInPhoneVisualMode = (visualMode: InPhoneChromeVisualMode) => {
    sounds.playTap();
    onSaveInPhoneChromeConfig?.({
      ...inPhoneChromeConfig,
      visualMode,
    });
  };

  const handleLaunchChromeClick = () => {
    sounds.playSuccess();
    onInstallAndLaunchChrome?.();
    handleClose();
  };

  const handleToggleChromeBridge = () => {
    sounds.playTap();
    const nextEnabled = !chromeBridgeConfig.enabled;
    onSaveChromeBridgeConfig?.({
      ...chromeBridgeConfig,
      enabled: nextEnabled,
    });
  };

  const handleChangeBridgeProvider = (provider: ChromeBridgeProvider) => {
    sounds.playTap();
    onSaveChromeBridgeConfig?.({
      ...chromeBridgeConfig,
      preferredProvider: provider,
    });
  };

  const handleTestChromeBridge = async () => {
    sounds.playTap();
    setIsTestingBridge(true);
    setBridgePingResult(null);
    const result = await pingChromeBridge(chromeBridgeConfig.preferredProvider || 'auto', 2500);
    setBridgePingResult(result);
    setIsTestingBridge(false);

    if (result.connected) {
      sounds.playSuccess();
    } else {
      sounds.playNotification();
    }

    onSaveChromeBridgeConfig?.({
      ...chromeBridgeConfig,
      lastPingAt: new Date().toLocaleTimeString(),
      extensionInstalled: result.extensionInstalled,
      detectedProvider: result.activeTabProvider,
      detectedTabTitle: result.activeTabTitle || null,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div
        className={`bg-slate-900 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col text-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] border ${
          activeTab === 'in_phone_chrome'
            ? 'border-emerald-500/60'
            : isKeyProtectedTab && !isUnlocked
            ? 'border-amber-500/50'
            : 'border-emerald-500/50'
        }`}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center shadow-xs border ${
                isKeyProtectedTab && !isUnlocked
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
              }`}
            >
              {activeTab === 'in_phone_chrome' ? (
                <Chrome className="w-4 h-4" />
              ) : isKeyProtectedTab && !isUnlocked ? (
                <Lock className="w-4 h-4" />
              ) : (
                <ShieldCheck className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <span>AI Engine &amp; In-Phone Chrome Settings</span>
                {isUnlocked ? (
                  <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.2 rounded-full font-bold">
                    ✓ Vault Unlocked
                  </span>
                ) : activeTab === 'in_phone_chrome' ? (
                  <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.2 rounded-full font-bold">
                    No API Key Mode
                  </span>
                ) : (
                  <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.2 rounded-full">
                    Vault Protected
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-400">
                Use the built-in In-Phone Chrome AI Browser Engine or configure API keys
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isUnlocked && (
              <button
                type="button"
                onClick={handleLockVault}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg text-xs font-semibold border border-amber-500/30 flex items-center gap-1 transition cursor-pointer"
                title="Lock Vault"
              >
                <Lock className="w-3 h-3" />
                <span>Lock</span>
              </button>
            )}
            <button
              onClick={handleClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap border-b border-slate-800 px-4 pt-3 gap-1 text-xs shrink-0">
          <button
            onClick={() => setActiveTab('openrouter')}
            className={`pb-2.5 px-2.5 font-medium border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'openrouter'
                ? 'border-emerald-400 text-emerald-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>OpenRouter</span>
          </button>

          <button
            onClick={() => setActiveTab('serper')}
            className={`pb-2.5 px-2.5 font-medium border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'serper'
                ? 'border-emerald-400 text-emerald-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Serper (Search)</span>
          </button>

          <button
            onClick={() => setActiveTab('tavily')}
            className={`pb-2.5 px-2.5 font-medium border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'tavily'
                ? 'border-emerald-400 text-emerald-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Tavily AI</span>
          </button>

          {/* 4th Tab: In-Phone Chrome (No API Key) */}
          <button
            onClick={() => setActiveTab('in_phone_chrome')}
            data-agent-target="tab-in-phone-chrome"
            className={`pb-2.5 px-2.5 font-medium border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'in_phone_chrome'
                ? 'border-cyan-400 text-cyan-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>In-Phone Chrome (No API Key)</span>
            {inPhoneChromeConfig.enabled && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>

          {/* Optional Companion Desktop Chrome Bridge */}
          <button
            onClick={() => setActiveTab('chrome_bridge')}
            className={`pb-2.5 px-2.5 font-medium border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'chrome_bridge'
                ? 'border-cyan-400 text-cyan-300 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Chrome className="w-3.5 h-3.5 text-slate-400" />
            <span>PC Extension Bridge</span>
            {chromeBridgeConfig.enabled && (
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            )}
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Password Gate when viewing secret API Key tabs while locked */}
          {isKeyProtectedTab && !isUnlocked && (
            <form onSubmit={handleUnlockSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 flex items-center justify-between gap-3">
                <div className="text-xs">
                  <div className="font-bold text-cyan-200">
                    Want to run without API Keys?
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Switch to the built-in In-Phone Chrome AI Browser Engine — zero password or API key needed.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('in_phone_chrome')}
                  className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shrink-0 cursor-pointer transition"
                >
                  Open In-Phone Chrome
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  Master Authorization Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      if (passwordError) setPasswordError(null);
                    }}
                    placeholder="Enter vault password to unlock..."
                    autoFocus
                    disabled={isCheckingPassword}
                    className={`w-full bg-slate-950 border rounded-xl pl-3.5 pr-10 py-2.5 text-xs text-white font-mono focus:outline-hidden transition ${
                      passwordError
                        ? 'border-rose-500 focus:border-rose-400 ring-2 ring-rose-500/20'
                        : 'border-slate-800 focus:border-emerald-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition cursor-pointer"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {passwordError ? (
                  <div className="flex items-center gap-1.5 text-rose-400 text-xs font-medium pt-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400">
                    Verified server-side against <code className="text-emerald-400 font-mono">ADMIN_VAULT_PASSWORD</code>.
                  </p>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition active:scale-95 cursor-pointer"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock Vault</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 1: OPENROUTER */}
          {activeTab === 'openrouter' && isUnlocked && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  OpenRouter API Key
                </label>
                <input
                  type="password"
                  value={orKey}
                  onChange={(e) => setOrKey(e.target.value)}
                  placeholder="sk-or-v1-..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Vision Language Model
                </label>
                <input
                  type="text"
                  value={orModel}
                  onChange={(e) => setOrModel(e.target.value)}
                  placeholder="nvidia/nemotron-3.5-super-vl:free"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <button
                onClick={handleVerifyOpenRouter}
                disabled={isVerifying}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer active:scale-95"
              >
                {isVerifying ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                )}
                <span>Save &amp; Test OpenRouter</span>
              </button>
            </>
          )}

          {/* TAB 2: SERPER */}
          {activeTab === 'serper' && isUnlocked && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Serper API Key
                </label>
                <input
                  type="password"
                  value={serperKey}
                  onChange={(e) => setSerperKey(e.target.value)}
                  placeholder="serper-..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <button
                onClick={handleVerifySerper}
                disabled={isVerifying}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer active:scale-95"
              >
                {isVerifying ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                )}
                <span>Save &amp; Test Serper</span>
              </button>
            </>
          )}

          {/* TAB 3: TAVILY */}
          {activeTab === 'tavily' && isUnlocked && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tavily API Key
                </label>
                <input
                  type="password"
                  value={tavilyKey}
                  onChange={(e) => setTavilyKey(e.target.value)}
                  placeholder="tvly-..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <button
                onClick={handleVerifyTavily}
                disabled={isVerifying}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer active:scale-95"
              >
                {isVerifying ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                )}
                <span>Save &amp; Test Tavily</span>
              </button>
            </>
          )}

          {/* TAB 4: IN-PHONE CHROME (NO API KEY) */}
          {activeTab === 'in_phone_chrome' && (
            <div className="space-y-4">
              {/* Primary ON/OFF Toggle */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/40 flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">
                      Use In-Phone Chrome Browser Instead of API Keys
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${
                        inPhoneChromeConfig.enabled
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-slate-900 text-slate-400 border-slate-700'
                      }`}
                    >
                      {inPhoneChromeConfig.enabled ? 'ON • ACTIVE' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Executes action planning, continuous screenshot vision QA, and autonomous tool takeover inside the simulator&apos;s Chrome AI tab with zero external extensions or API keys.
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={inPhoneChromeConfig.enabled}
                  data-agent-target="toggle-in-phone-chrome-enabled"
                  onClick={handleToggleInPhoneChrome}
                  className={`w-12 h-6 rounded-full transition relative shrink-0 cursor-pointer ${
                    inPhoneChromeConfig.enabled ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform shadow-sm ${
                      inPhoneChromeConfig.enabled ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* AI Model Loaded Inside In-Phone Chrome */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  AI Model Loaded Inside In-Phone Chrome Browser
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {(['gemini_web', 'chatgpt_web', 'claude_web'] as const).map((modelId) => {
                    const meta = CHROME_PROVIDER_META[modelId];
                    const selected = inPhoneChromeConfig.aiModel === modelId;
                    return (
                      <button
                        key={modelId}
                        type="button"
                        data-agent-target={`select-inphone-model-${modelId}`}
                        onClick={() => handleChangeInPhoneModel(modelId)}
                        className={`p-3 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
                          selected
                            ? 'bg-cyan-500/15 border-cyan-400 text-white shadow-sm'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <Chrome className="w-4 h-4 text-cyan-400" />
                          {selected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                        </div>
                        <div className="font-bold text-xs">{meta.label}</div>
                        <div className="text-[10px] font-mono text-slate-400 truncate">
                          {meta.url}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Visual Execution Mode Toggle (Background Headless Tab vs Live Split/Tab View) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Visual Execution Mode
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    data-agent-target="select-visual-headless"
                    onClick={() => handleChangeInPhoneVisualMode('headless')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
                      inPhoneChromeConfig.visualMode === 'headless'
                        ? 'bg-emerald-500/15 border-emerald-400 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      <Layers className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Background Headless Tab</span>
                    </div>
                    <p className="text-[10.5px] text-slate-400">
                      Runs silently inside Chrome&apos;s background tab while the phone operates target apps smoothly.
                    </p>
                  </button>

                  <button
                    type="button"
                    data-agent-target="select-visual-livesplit"
                    onClick={() => handleChangeInPhoneVisualMode('live_split')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
                      inPhoneChromeConfig.visualMode === 'live_split'
                        ? 'bg-amber-500/15 border-amber-400 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      <Eye className="w-3.5 h-3.5 text-amber-400" />
                      <span>Live Split / Tab View</span>
                    </div>
                    <p className="text-[10.5px] text-slate-400">
                      Briefly previews the in-phone Chrome AI chat tab dispatching the prompt before switching to the target app.
                    </p>
                  </button>
                </div>
              </div>

              {/* 1-Click Install & Launch Chrome on Phone */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Chrome className="w-4 h-4 text-cyan-400" />
                    <span>
                      {isChromeInstalledOnPhone
                        ? 'Google Chrome Installed on Simulator'
                        : 'Google Chrome Not on Home Screen'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Open the in-phone Chrome browser to inspect live prompts, screenshots &amp; JSON plans in real time.
                  </p>
                </div>
                <button
                  type="button"
                  data-agent-target="btn-install-launch-chrome"
                  onClick={handleLaunchChromeClick}
                  className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shrink-0 transition cursor-pointer active:scale-95 shadow-md"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>
                    {isChromeInstalledOnPhone
                      ? 'Launch Chrome on Phone'
                      : 'Install & Launch Chrome on Phone'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: OPTIONAL PC CHROME EXTENSION BRIDGE */}
          {activeTab === 'chrome_bridge' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">
                      Enable Desktop Chrome Web-Session Bridge
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                        chromeBridgeConfig.enabled
                          ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40'
                          : 'bg-slate-900 text-slate-400 border-slate-700'
                      }`}
                    >
                      {chromeBridgeConfig.enabled ? 'Active' : 'Off'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Optional: Relay via unpacked Chrome extension to a desktop browser tab.
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={chromeBridgeConfig.enabled}
                  onClick={handleToggleChromeBridge}
                  className={`w-11 h-6 rounded-full transition relative shrink-0 cursor-pointer ${
                    chromeBridgeConfig.enabled ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform shadow-sm ${
                      chromeBridgeConfig.enabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Target Browser AI Tab
                </label>
                <div className="grid grid-cols-4 gap-1.5 text-xs">
                  {(
                    [
                      { id: 'auto', label: 'Auto-Detect' },
                      { id: 'gemini', label: 'Gemini' },
                      { id: 'chatgpt', label: 'ChatGPT' },
                      { id: 'claude', label: 'Claude' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleChangeBridgeProvider(opt.id)}
                      className={`py-1.5 px-2 rounded-xl border font-medium transition cursor-pointer ${
                        (chromeBridgeConfig.preferredProvider || 'auto') === opt.id
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={handleTestChromeBridge}
                disabled={isTestingBridge}
                className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer active:scale-95 shadow-md"
              >
                {isTestingBridge ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <PlugZap className="w-3.5 h-3.5" />
                )}
                <span>
                  {isTestingBridge
                    ? 'Pinging Extension & Browser Tabs...'
                    : 'Test Extension & AI Tab'}
                </span>
              </button>

              {bridgePingResult && (
                <div
                  className={`p-3 rounded-xl border text-xs space-y-1 ${
                    bridgePingResult.connected
                      ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                      : bridgePingResult.extensionInstalled
                      ? 'bg-amber-950/40 border-amber-500/50 text-amber-200'
                      : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      {bridgePingResult.connected ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      <span>
                        {bridgePingResult.connected
                          ? `Connected to ${bridgePingResult.activeTabProvider} Tab`
                          : bridgePingResult.extensionInstalled
                          ? 'Extension Installed — No AI Web Tab Open'
                          : 'Chrome Extension Not Detected'}
                      </span>
                    </span>
                    <span className="font-mono text-[10px] opacity-80">
                      {bridgePingResult.latencyMs}ms
                    </span>
                  </div>
                  {!bridgePingResult.connected && (
                    <p className="text-[11px] opacity-90">{bridgePingResult.error}</p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
