/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  Play,
  Sparkles,
  Search,
  Filter,
  Flame,
  Clock,
  Coins,
  ArrowRight,
  ExternalLink,
  Plus,
  Compass,
} from 'lucide-react';
import { PhoneAppType } from '../../types/phone';
import { PublicWorkflowTemplate } from '../../types/workflowShare';
import {
  getStoredWorkflows,
  subscribeToWorkflows,
  getWorkflowShareUrl,
  recordWorkflowRun,
  recordWorkflowClone,
} from '../../utils/workflowStore';
import { formatTokenCount } from '../../types/tokenBilling';

interface WorkflowCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRunWorkflow: (workflow: PublicWorkflowTemplate) => void;
  onOpenPublishModal: () => void;
}

export const WorkflowCommunityModal: React.FC<WorkflowCommunityModalProps> = ({
  isOpen,
  onClose,
  onRunWorkflow,
  onOpenPublishModal,
}) => {
  const [workflows, setWorkflows] = useState<PublicWorkflowTemplate[]>(getStoredWorkflows);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setWorkflows(getStoredWorkflows());
    }
  }, [isOpen]);

  useEffect(() => {
    return subscribeToWorkflows(() => {
      setWorkflows(getStoredWorkflows());
    });
  }, []);

  if (!isOpen) return null;

  const filtered = workflows.filter((wf) => {
    const matchesSearch =
      wf.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wf.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wf.prompt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wf.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesFilter =
      selectedFilter === 'all' ||
      wf.targetApp === selectedFilter ||
      (selectedFilter === 'featured' && wf.isFeatured);

    return matchesSearch && matchesFilter;
  });

  const handleCopy = (wf: PublicWorkflowTemplate) => {
    const url = getWorkflowShareUrl(wf);
    navigator.clipboard.writeText(url).then(() => {
      setCopiedId(wf.id);
      recordWorkflowClone(wf.id);
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  const handleRun = (wf: PublicWorkflowTemplate) => {
    recordWorkflowRun(wf.id);
    onRunWorkflow(wf);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 px-6 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 text-emerald-400 border border-emerald-500/40">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  Public Workflow Templates
                </h2>
                <span className="text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                  1-Click Share & Run
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Explore, run, or share public mobile automations built on installed apps
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenPublishModal();
              }}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition cursor-pointer active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Publish My Workflow</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="p-4 px-6 border-b border-slate-800 bg-slate-950/60 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between shrink-0">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search templates (e.g. Lead Scraper, Social, Notes)..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-9 pr-3.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs">
            {[
              { id: 'all', label: 'All Templates' },
              { id: 'featured', label: '⭐ Featured' },
              { id: 'browser', label: 'Browser' },
              { id: 'social', label: 'Social' },
              { id: 'notes', label: 'Notes' },
              { id: 'messages', label: 'Messages' },
              { id: 'food', label: 'Food Delivery' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold shrink-0 transition cursor-pointer ${
                  selectedFilter === f.id
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Template Grid */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No matching workflow templates found. Try a different search term or publish one!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filtered.map((wf) => {
                const isItemCopied = copiedId === wf.id;
                return (
                  <div
                    key={wf.id}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 transition flex flex-col justify-between group shadow-sm hover:shadow-md"
                  >
                    <div>
                      {/* Top Badges */}
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono uppercase bg-slate-850 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800">
                            {wf.targetApp.toUpperCase()}
                          </span>
                          {wf.isFeatured && (
                            <span className="text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                              <Sparkles className="w-2.5 h-2.5" />
                              <span>Featured</span>
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                          <span>{wf.runCount} runs</span>
                          <span>•</span>
                          <span className="text-emerald-400">~{formatTokenCount(wf.estimatedTokens)} tokens</span>
                        </div>
                      </div>

                      {/* Title & Description */}
                      <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition line-clamp-1">
                        {wf.title}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                        {wf.description}
                      </p>

                      {/* Executable Prompt Preview */}
                      <div className="mt-3 p-2.5 rounded-lg bg-slate-900/90 border border-slate-800/80 text-[11px] font-mono text-emerald-300 line-clamp-2">
                        "{wf.prompt}"
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mt-2.5">
                        {wf.tags.slice(0, 3).map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[9px] bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded-md border border-slate-800"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Bottom Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-500 truncate">
                        By <strong className="text-slate-300">{wf.author}</strong>
                      </span>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* 1-Click Copy Public Link Button */}
                        <button
                          onClick={() => handleCopy(wf)}
                          className={`p-1.5 px-2.5 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer ${
                            isItemCopied
                              ? 'bg-emerald-500 text-slate-950 font-bold'
                              : 'bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700 active:scale-95'
                          }`}
                          title="Copy 1-Click Public Template Link"
                        >
                          {isItemCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{isItemCopied ? 'Link Copied' : 'Share Link'}</span>
                        </button>

                        {/* 1-Click Run Button */}
                        <button
                          onClick={() => handleRun(wf)}
                          className="p-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer active:scale-95"
                          title="1-Click Run Automation in Prompt Slot"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Run</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="p-3 px-6 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between shrink-0">
          <span>
            Templates execute using server-side master key at standard rate ($8 for 20M tokens)
          </span>
          <span className="text-emerald-400 font-semibold hidden sm:inline">
            5,000,000 Free Welcome Tokens on sign-up
          </span>
        </div>
      </div>
    </div>
  );
};
