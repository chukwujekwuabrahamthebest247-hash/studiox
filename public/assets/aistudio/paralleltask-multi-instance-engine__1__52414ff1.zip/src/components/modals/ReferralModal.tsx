/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Gift,
  Copy,
  Check,
  Users,
  Coins,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  TrendingUp,
} from 'lucide-react';
import {
  getStoredWallet,
  getUserReferralLink,
  rewardReferralBonusAsync,
  syncWalletFromServer,
  subscribeToQuotaChanges,
} from '../../utils/tokenQuotaManager';
import {
  REFERRAL_BONUS_TOKENS,
  formatTokenCount,
  tokensToUsd,
  UserTokenWallet,
} from '../../types/tokenBilling';

interface ReferralModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferralModal: React.FC<ReferralModalProps> = ({ isOpen, onClose }) => {
  const [wallet, setWallet] = useState<UserTokenWallet>(getStoredWallet);
  const [isCopied, setIsCopied] = useState(false);
  const [rewardToast, setRewardToast] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setWallet(getStoredWallet());
      void syncWalletFromServer().then((res) => {
        if (res) setWallet(res.wallet);
      });
    }
  }, [isOpen]);

  useEffect(() => {
    return subscribeToQuotaChanges((updated) => {
      setWallet(updated);
    });
  }, []);

  if (!isOpen) return null;

  const referralLink = getUserReferralLink(wallet.referralCode);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 3000);
    });
  };

  // Allows user to test the 5M bonus mechanism live via persistent server DB
  const handleSimulateFriendPurchase = async () => {
    const friendNames = ['Alex Rivera', 'Maya Lin', 'David K.', 'Sarah Chen', 'Tunde B.'];
    const randomFriend = friendNames[Math.floor(Math.random() * friendNames.length)];
    await rewardReferralBonusAsync(`${randomFriend} (${randomFriend.toLowerCase().replace(' ', '')}@gmail.com)`);
    setRewardToast(`🎉 Boom! ${randomFriend} bought their first $8 pack! 5,000,000 Free Tokens credited to your balance.`);
    setTimeout(() => setRewardToast(null), 5000);
  };

  return (
    <div className="fixed inset-0 z-[125] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-auto animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 px-6 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500/20 to-emerald-500/20 text-emerald-400 border border-emerald-500/40">
              <Gift className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  Refer & Earn 5M Free Tokens
                </h2>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                  +5,000,000 Tokens
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Get 5M bonus tokens whenever an invited friend buys their first $8 pack
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Reward celebration toast */}
        {rewardToast && (
          <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 text-white p-3 px-6 text-xs font-bold flex items-center gap-2 shadow-lg animate-in slide-in-from-top">
            <Sparkles className="w-4 h-4 fill-white shrink-0" />
            <span className="flex-1">{rewardToast}</span>
            <button onClick={() => setRewardToast(null)} className="p-1 hover:bg-black/20 rounded">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Top Referral Link Copy Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-300">
                Your Unique Personal Referral Link:
              </label>
              <span className="text-emerald-400 font-mono text-[11px] font-bold">
                Code: {wallet.referralCode}
              </span>
            </div>
            <div className="flex gap-2">
              <div className="flex-1 bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-emerald-400 truncate select-all">
                {referralLink}
              </div>
              <button
                onClick={handleCopyLink}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                  isCopied
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
                }`}
              >
                {isCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{isCopied ? 'Link Copied!' : 'Copy Link'}</span>
              </button>
            </div>
          </div>

          {/* Referral Stats Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">
                Friends Joined
              </span>
              <span className="text-lg font-bold font-mono text-white mt-0.5 block">
                {wallet.referralInvitesCount}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">
                $8 Packs Bought
              </span>
              <span className="text-lg font-bold font-mono text-emerald-400 mt-0.5 block">
                {wallet.referralConversionsCount}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">
                5M Bonuses Earned
              </span>
              <span className="text-lg font-bold font-mono text-amber-400 mt-0.5 block">
                {formatTokenCount(wallet.referralTokensEarned)}
              </span>
            </div>
          </div>

          {/* How It Works Steps */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              How the 5M Token Referral Reward Works:
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  1
                </div>
                <div className="text-slate-300">
                  <strong className="text-white">Share your personal link</strong> with friends, teammates, or on social channels.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  2
                </div>
                <div className="text-slate-300">
                  Your friend signs up, verifies their email, and unlocks their personal cloud token wallet.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  3
                </div>
                <div className="text-slate-300">
                  When your friend buys their first <strong className="text-white">$8 pack (20,000,000 tokens)</strong>, you instantly receive <strong className="text-emerald-400">+5,000,000 free tokens</strong> (costs us ~$0.50) added straight to your wallet balance!
                </div>
              </div>
            </div>
          </div>

          {/* Test simulation button */}
          <div className="pt-1 flex items-center justify-between gap-3">
            <button
              onClick={handleSimulateFriendPurchase}
              className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold cursor-pointer underline underline-offset-2"
              title="Test the 5M bonus crediting live"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Simulate Friend $8 Purchase (+5M Tokens)</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer transition"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
