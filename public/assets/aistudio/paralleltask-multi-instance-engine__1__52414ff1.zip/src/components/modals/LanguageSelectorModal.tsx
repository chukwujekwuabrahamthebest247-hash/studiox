/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SupportedLanguage, SUPPORTED_LANGUAGES } from '../../utils/multilingualSlang';
import { Globe, Check, Sparkles, X } from 'lucide-react';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onRunSamplePrompt?: (prompt: string) => void;
}

export const LanguageSelectorModal: React.FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedLanguage,
  onSelectLanguage,
  onRunSamplePrompt,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl flex flex-col text-slate-200">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Language & Slang Adaptor</h3>
              <p className="text-[11px] text-slate-400">Natural dialect understanding for phone agent</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
          {SUPPORTED_LANGUAGES.map((item) => {
            const isSelected = selectedLanguage === item.code;
            return (
              <div
                key={item.code}
                onClick={() => {
                  onSelectLanguage(item.code);
                  onClose();
                }}
                className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500/60 text-white'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{item.flag}</span>
                  <div>
                    <div className="font-bold text-xs flex items-center gap-2">
                      <span>{item.label}</span>
                      {isSelected && (
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded-full font-mono">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 italic mt-0.5 line-clamp-1">
                      "{item.samplePrompt}"
                    </p>
                  </div>
                </div>
                {isSelected ? (
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : onRunSamplePrompt ? (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectLanguage(item.code);
                      onRunSamplePrompt(item.samplePrompt);
                      onClose();
                    }}
                    className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 hover:bg-emerald-900/60 px-2 py-1 rounded-lg border border-emerald-500/30 flex items-center gap-1 shrink-0"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Run</span>
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
