/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  UserCheck,
  Mail,
  Lock,
  User,
  Sparkles,
  LogOut,
  AlertCircle,
  ShieldCheck,
  Coins,
  RefreshCw,
  CheckCircle2,
  ArrowLeft,
  Loader2,
} from 'lucide-react';
import {
  AuthenticatedUser,
} from '../../types/tokenBilling';
import {
  clearAuthSession,
  getStoredWallet,
  setAuthSession,
  syncWalletFromServer,
} from '../../utils/tokenQuotaManager';
import {
  isSupabaseConfigured,
  mapSupabaseUserToAuthUser,
  supabase,
} from '../../lib/supabaseClient';
import { sounds } from '../../utils/soundEffects';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthenticatedUser | null;
  onAuthChanged?: (user: AuthenticatedUser | null) => void;
}

type OAuthProviderType = 'google' | 'github' | 'facebook';

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onAuthChanged,
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [viewState, setViewState] = useState<'form' | 'verification_pending'>('form');
  const [pendingEmail, setPendingEmail] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [referralCode, setReferralCode] = useState(() => {
    try {
      return getStoredWallet().referredBy || '';
    } catch {
      return '';
    }
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<OAuthProviderType | null>(null);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendCooldownSec, setResendCooldownSec] = useState(0);
  const [resendNotice, setResendNotice] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (resendCooldownSec <= 0) return;
    const t = window.setTimeout(() => setResendCooldownSec((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearTimeout(t);
  }, [resendCooldownSec]);

  if (!isOpen) return null;

  const handleOAuthLogin = async (provider: OAuthProviderType) => {
    setErrorMsg(null);
    setResendNotice(null);
    if (!isSupabaseConfigured || !supabase) {
      setErrorMsg(
        'Supabase OAuth requires VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.'
      );
      sounds.playNotification();
      return;
    }

    setOauthLoading(provider);
    sounds.playTap();
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) {
        sounds.playNotification();
        setErrorMsg(error.message || `Failed starting ${provider} sign-in.`);
        setOauthLoading(null);
      }
    } catch (err: any) {
      sounds.playNotification();
      setErrorMsg(err?.message || `OAuth error with ${provider}.`);
      setOauthLoading(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setResendNotice(null);

    if (!isSupabaseConfigured || !supabase) {
      sounds.playNotification();
      setErrorMsg(
        'Supabase Auth is not configured yet. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.'
      );
      return;
    }

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    setIsSubmitting(true);

    try {
      if (mode === 'signup') {
        const displayName = name.trim() || cleanEmail.split('@')[0];
        const cleanRef = referralCode.trim().toUpperCase() || undefined;
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: {
              name: displayName,
              full_name: displayName,
              referral_code: cleanRef,
            },
          },
        });

        if (error) {
          sounds.playNotification();
          setErrorMsg(error.message || 'Sign-up failed. Please check your details.');
          setIsSubmitting(false);
          return;
        }

        // Strict verification gate: unless email_confirmed_at is already verified, force confirmation link click
        if (!data.user?.email_confirmed_at) {
          if (data.session) {
            await supabase.auth.signOut();
            clearAuthSession();
          }
          sounds.playTap();
          setPendingEmail(cleanEmail);
          setViewState('verification_pending');
          setPassword('');
          setResendCooldownSec(30);
          setIsSubmitting(false);
          return;
        }

        if (data.session?.access_token && data.user) {
          const mapped = mapSupabaseUserToAuthUser(data.user, getStoredWallet().referralCode);
          setAuthSession(data.session.access_token, mapped);
          void syncWalletFromServer();
          onAuthChanged?.(mapped);
          sounds.playSuccess();
          setPassword('');
          onClose();
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });

        if (error) {
          sounds.playNotification();
          const msg = error.message || 'Invalid email or password.';
          if (msg.toLowerCase().includes('not confirmed')) {
            setPendingEmail(cleanEmail);
            setViewState('verification_pending');
          }
          setErrorMsg(msg);
          setIsSubmitting(false);
          return;
        }

        // Strict verification enforcement on login
        if (!data.user?.email_confirmed_at || !data.session?.access_token) {
          await supabase.auth.signOut();
          clearAuthSession();
          sounds.playNotification();
          setPendingEmail(cleanEmail);
          setViewState('verification_pending');
          setErrorMsg(
            'Your email address has not been verified yet. Click the verification link sent to your inbox before signing in.'
          );
          setIsSubmitting(false);
          return;
        }

        const mapped = mapSupabaseUserToAuthUser(data.user, getStoredWallet().referralCode);
        setAuthSession(data.session.access_token, mapped);
        const synced = await syncWalletFromServer();
        onAuthChanged?.(synced?.user || mapped);
        sounds.playSuccess();
        setPassword('');
        onClose();
      }
    } catch (err: any) {
      sounds.playNotification();
      setErrorMsg(err?.message || 'Network error reaching authentication service.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendVerification = async () => {
    const targetEmail = (pendingEmail || email).trim();
    if (!targetEmail || !supabase) return;
    setResendLoading(true);
    setErrorMsg(null);
    setResendNotice(null);

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: targetEmail,
        options: {
          emailRedirectTo: window.location.origin,
        },
      });

      if (error) {
        sounds.playNotification();
        setErrorMsg(error.message || 'Could not resend verification link.');
      } else {
        sounds.playSuccess();
        setResendCooldownSec(45);
        setResendNotice(`Verification link re-sent to ${targetEmail}. Check your inbox & spam folder.`);
      }
    } catch (err: any) {
      sounds.playNotification();
      setErrorMsg(err?.message || 'Failed to resend verification email.');
    } finally {
      setResendLoading(false);
    }
  };

  const handleLogout = async () => {
    sounds.playTap();
    try {
      if (supabase) {
        await supabase.auth.signOut();
      }
      await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    } catch {}
    clearAuthSession();
    onAuthChanged?.(null);
    setViewState('form');
    onClose();
  };

  const userInitial = (currentUser?.name || currentUser?.email || 'U').charAt(0).toUpperCase();

  return (
    <div className="fixed inset-0 z-[210] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/95">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              {currentUser ? <UserCheck className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {currentUser ? 'Verified Account' : 'Sign In & Account Verification'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {currentUser
                  ? 'Verified session & cloud token ledger'
                  : 'Verify via email link or 1-click OAuth to access your wallet'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[82vh] overflow-y-auto">
          {currentUser ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {currentUser.avatarUrl ? (
                      <img
                        src={currentUser.avatarUrl}
                        alt={currentUser.name}
                        className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-sm font-bold text-emerald-300 shrink-0">
                        {userInitial}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-white truncate">{currentUser.name}</div>
                      <div className="text-xs font-mono text-slate-400 truncate">
                        {currentUser.email}
                      </div>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 px-2.5 py-1 rounded-lg shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Verified</span>
                  </span>
                </div>

                <div className="pt-2 space-y-1.5 text-[11px] border-t border-slate-800/80">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Provider:</span>
                    <span className="font-mono uppercase text-slate-200">
                      {currentUser.provider || 'email'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">Account ID:</span>
                    <span className="font-mono text-cyan-300 truncate max-w-[210px]">
                      {currentUser.id}
                    </span>
                  </div>
                  {currentUser.referralCode && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Referral Code:</span>
                      <span className="font-mono font-bold text-emerald-400">
                        {currentUser.referralCode}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={handleLogout}
                data-agent-target="btn-auth-logout"
                className="w-full py-2.5 rounded-xl bg-rose-950/70 hover:bg-rose-900/80 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : viewState === 'verification_pending' ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-950/35 border border-emerald-500/40 space-y-2.5">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                  <Mail className="w-4 h-4 shrink-0" />
                  <span>Check your Gmail / Email inbox</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Check your Gmail/Email inbox and click the verification link to activate your account before signing in:
                </p>
                <div className="px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-300 truncate">
                  {pendingEmail || email}
                </div>
              </div>

              {resendNotice && (
                <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-200 text-xs flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{resendNotice}</span>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleResendVerification}
                  disabled={resendLoading || resendCooldownSec > 0}
                  data-agent-target="btn-auth-resend-verification"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  {resendLoading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {resendLoading
                      ? 'Sending Verification Link...'
                      : resendCooldownSec > 0
                      ? `Resend Verification Link (${resendCooldownSec}s)`
                      : 'Resend Verification Link'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setViewState('form');
                    setMode('login');
                    setErrorMsg(null);
                    setResendNotice(null);
                  }}
                  className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {!isSupabaseConfigured && (
                <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-500/40 text-amber-200 text-xs space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Supabase Environment Keys Required</span>
                  </div>
                  <p className="text-[11px] text-amber-200/80">
                    Set <code className="font-mono text-white">VITE_SUPABASE_URL</code> and{' '}
                    <code className="font-mono text-white">VITE_SUPABASE_ANON_KEY</code> to enable real email confirmation links & OAuth.
                  </p>
                </div>
              )}

              {/* 1-Click Social OAuth Buttons */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => handleOAuthLogin('google')}
                  disabled={oauthLoading !== null || isSubmitting}
                  data-agent-target="btn-oauth-google"
                  className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-slate-100 disabled:opacity-60 text-slate-900 text-xs font-bold flex items-center justify-center gap-2.5 transition cursor-pointer shadow-xs"
                >
                  {oauthLoading === 'google' ? (
                    <Loader2 className="w-4 h-4 animate-spin text-slate-700" />
                  ) : (
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                      />
                    </svg>
                  )}
                  <span>Continue with Google (Gmail)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleOAuthLogin('github')}
                    disabled={oauthLoading !== null || isSubmitting}
                    data-agent-target="btn-oauth-github"
                    className="py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700/80 disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {oauthLoading === 'github' ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
                      </svg>
                    )}
                    <span>GitHub</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOAuthLogin('facebook')}
                    disabled={oauthLoading !== null || isSubmitting}
                    data-agent-target="btn-oauth-facebook"
                    className="py-2.5 px-3 rounded-xl bg-[#1877F2] hover:bg-[#166FE5] disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {oauthLoading === 'facebook' ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                    )}
                    <span>Facebook</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 text-[11px] text-slate-500">
                <div className="h-[1px] flex-1 bg-slate-800" />
                <span className="font-mono uppercase tracking-wider">or with email link</span>
                <div className="h-[1px] flex-1 bg-slate-800" />
              </div>

              {/* Mode Switcher */}
              <div className="flex p-1 bg-slate-950 border border-slate-800 rounded-xl text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    setErrorMsg(null);
                  }}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    mode === 'signup'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Create Account
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg(null);
                  }}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    mode === 'login'
                      ? 'bg-slate-800 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
              </div>

              {mode === 'signup' && (
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2.5 text-xs text-slate-300">
                  <Coins className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    New accounts start at{' '}
                    <strong className="font-mono text-white">0 tokens</strong>. Top up{' '}
                    <strong className="font-mono text-emerald-400">$8 = 20,000,000 tokens</strong> after verifying.
                  </span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-3">
                {mode === 'signup' && (
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300 block">
                      Display Name
                    </label>
                    <div className="relative">
                      <User className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Alex Rivera"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-hidden"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-300 block">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@gmail.com"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-300 block">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-hidden"
                    />
                  </div>
                </div>

                {mode === 'signup' && (
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300 block">
                      Referral Code (Optional)
                    </label>
                    <input
                      type="text"
                      value={referralCode}
                      onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                      placeholder="OMNI-XXXX"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs font-mono text-emerald-300 focus:outline-hidden"
                    />
                  </div>
                )}

                {errorMsg && (
                  <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting || oauthLoading !== null}
                  data-agent-target="btn-auth-submit"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-lg"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {isSubmitting
                      ? 'Authenticating...'
                      : mode === 'signup'
                      ? 'Send Verification Link & Create Account'
                      : 'Sign In to Cloud Wallet'}
                  </span>
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
