/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BiometricPromptState } from '../../types/phone';
import { ShieldCheck, Fingerprint, Lock, Check } from 'lucide-react';

interface BiometricPromptModalProps {
  prompt: BiometricPromptState | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export const BiometricPromptModal: React.FC<BiometricPromptModalProps> = ({
  prompt,
  onSuccess,
  onCancel,
}) => {
  if (!prompt) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl space-y-4">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center animate-pulse">
          <Fingerprint className="w-9 h-9" />
        </div>
        <div>
          <h3 className="text-base font-bold text-white">Biometric Authorization</h3>
          <p className="text-xs text-emerald-400 font-semibold mt-0.5">{prompt.appName}</p>
          <p className="text-xs text-slate-400 mt-2">{prompt.reason}</p>
        </div>
        <div className="flex gap-2.5 pt-2">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
          >
            Cancel
          </button>
          <button
            onClick={onSuccess}
            className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-lg shadow-emerald-600/30"
          >
            <Check className="w-4 h-4" />
            <span>Verify FaceID</span>
          </button>
        </div>
      </div>
    </div>
  );
};
