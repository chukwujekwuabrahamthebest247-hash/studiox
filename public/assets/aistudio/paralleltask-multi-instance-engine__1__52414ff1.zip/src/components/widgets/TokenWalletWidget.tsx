/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Coins, AlertTriangle, ChevronRight, PlusCircle } from 'lucide-react';
import {
  getStoredWallet,
  subscribeToQuotaChanges,
} from '../../utils/tokenQuotaManager';
import {
  LOW_QUOTA_ALERT_THRESHOLD,
  formatTokenCount,
  tokensToUsd,
  UserTokenWallet,
} from '../../types/tokenBilling';

interface TokenWalletWidgetProps {
  onOpenBillingModal: () => void;
  className?: string;
}

export const TokenWalletWidget: React.FC<TokenWalletWidgetProps> = ({
  onOpenBillingModal,
  className = '',
}) => {
  const [wallet, setWallet] = useState<UserTokenWallet>(getStoredWallet);

  useEffect(() => {
    return subscribeToQuotaChanges((updated) => {
      setWallet(updated);
    });
  }, []);

  const isLowQuota = wallet.appTokenBalance < LOW_QUOTA_ALERT_THRESHOLD;
  const isOutOfQuota = wallet.appTokenBalance <= 0;
  const dollarVal = tokensToUsd(wallet.appTokenBalance);

  return (
    <button
      onClick={onOpenBillingModal}
      data-agent-target="btn-open-token-wallet"
      className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-xl border transition cursor-pointer shadow-xs active:scale-95 text-xs ${
        isOutOfQuota
          ? 'bg-rose-950/80 border-rose-500/60 text-rose-200 hover:bg-rose-900/80'
          : isLowQuota
          ? 'bg-amber-950/80 border-amber-500/60 text-amber-200 hover:bg-amber-900/80'
          : 'bg-slate-900/90 border-slate-700/80 hover:border-emerald-500/60 text-slate-200 hover:text-white'
      } ${className}`}
      title="Open Token Quota & Billing Management ($8 = 20M Tokens)"
    >
      {/* Icon with alert dot if low */}
      <div className="relative">
        <Coins
          className={`w-3.5 h-3.5 ${
            isOutOfQuota
              ? 'text-rose-400 animate-bounce'
              : isLowQuota
              ? 'text-amber-400'
              : 'text-emerald-400'
          }`}
        />
        {isLowQuota && (
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-ping" />
        )}
      </div>

      {/* Balance representation */}
      <div className="flex items-baseline gap-1.5 font-mono">
        <span
          className={`font-bold tracking-tight ${
            isOutOfQuota
              ? 'text-rose-400'
              : isLowQuota
              ? 'text-amber-300'
              : 'text-emerald-400'
          }`}
        >
          {formatTokenCount(wallet.appTokenBalance)}
        </span>
        <span className="text-[10px] text-slate-400 hidden sm:inline">
          tokens
        </span>
        <span className="text-slate-600 hidden sm:inline">•</span>
        <span className="text-[10px] text-slate-300 font-semibold hidden md:inline">
          ${dollarVal.toFixed(2)}
        </span>
      </div>

      {/* Action pill */}
      <div
        className={`flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${
          isLowQuota
            ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
            : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 group-hover:bg-emerald-500/25'
        }`}
      >
        <PlusCircle className="w-2.5 h-2.5" />
        <span className="hidden lg:inline">
          {isLowQuota ? 'Low Quota' : 'Top Up'}
        </span>
      </div>
    </button>
  );
};
