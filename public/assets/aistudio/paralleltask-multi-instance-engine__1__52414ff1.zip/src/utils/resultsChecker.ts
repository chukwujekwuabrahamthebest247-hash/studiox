/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep, CartItem, ContactThread, NoteItem, PhoneAppType, PhoneSettings, SocialPost } from '../types/phone';

export interface PhoneSnapshot {
  currentApp: PhoneAppType;
  socialPosts: SocialPost[];
  foodCart: CartItem[];
  messageThreads: ContactThread[];
  notes: NoteItem[];
  settings: PhoneSettings;
}

export interface TaskGoal {
  rawPrompt: string;
  summary: string;
  expectedApp?: PhoneAppType;
  mustCloseToHome?: boolean;
}

export interface EvaluationResult {
  passed: boolean;
  checks: Array<{ label: string; passed: boolean; details?: string }>;
  missingActions: string[];
}

export function deriveGoal(prompt: string, currentApp: PhoneAppType): TaskGoal {
  const pLower = prompt.toLowerCase();
  let summary = prompt;
  let expectedApp: PhoneAppType = currentApp;
  let mustCloseToHome = false;

  if (pLower.includes('tiktok')) {
    summary = 'Automate TikTok viewport action';
    expectedApp = 'tiktok';
  } else if (pLower.includes('tinder')) {
    summary = 'Automate Tinder viewport action';
    expectedApp = 'tinder';
  } else if (pLower.includes('crypto') || pLower.includes('wallet') || pLower.includes('metamask') || pLower.includes('binance')) {
    summary = 'Execute Crypto Wallet workflow';
    expectedApp = 'cryptowallet';
  } else if (pLower.includes('pizza') || pLower.includes('food') || pLower.includes('burger')) {
    summary = 'Order Artisan Pepperoni Pizza on BiteDash';
    expectedApp = 'food';
  } else if ((pLower.includes('like') || pLower.includes('social') || pLower.includes('pulse')) && !pLower.includes('tiktok') && !pLower.includes('tinder')) {
    summary = 'Like post on Social timeline';
    expectedApp = 'social';
  } else if (pLower.includes('message') || pLower.includes('sarah') || pLower.includes('sms')) {
    summary = 'Send message to Sarah Chen';
    expectedApp = 'messages';
  } else if (pLower.includes('note') || pLower.includes('memo')) {
    summary = 'Create and save meeting note';
    expectedApp = 'notes';
  } else if (pLower.includes('dark') || pLower.includes('settings')) {
    summary = 'Toggle Dark Mode in Settings';
    expectedApp = 'settings';
  } else if (pLower.includes('bank') || pLower.includes('statement') || pLower.includes('charge')) {
    summary = 'Export statement & audit charges in Apex Bank';
    expectedApp = 'banking';
  } else if (pLower.includes('invoice') || pLower.includes('quickbooks')) {
    summary = 'Verify & send invoice in QuickBooks';
    expectedApp = 'quickbooks';
  } else if (pLower.includes('search') || pLower.includes('browse')) {
    summary = 'Search web and view article in SearchGlobe';
    expectedApp = 'browser';
  } else if (pLower.includes('install') || pLower.includes('apk') || pLower.includes('exe')) {
    summary = 'Install application / package into phone sandbox';
    expectedApp = 'home';
  } else if (pLower.includes('home')) {
    summary = 'Return to Home Screen';
    expectedApp = 'home';
    mustCloseToHome = true;
  }

  return { rawPrompt: prompt, summary, expectedApp, mustCloseToHome };
}

export function checkResults(
  goal: TaskGoal,
  initialSnapshot: PhoneSnapshot,
  currentSnapshot: PhoneSnapshot
): EvaluationResult {
  const checks: Array<{ label: string; passed: boolean; details?: string }> = [];
  const missingActions: string[] = [];
  const gLower = (goal.rawPrompt || goal.summary).toLowerCase();

  if (gLower.includes('pizza') || gLower.includes('food')) {
    const hasCart = currentSnapshot.foodCart.length > 0;
    checks.push({
      label: 'Food Item Placed in Cart',
      passed: hasCart,
      details: hasCart ? `${currentSnapshot.foodCart.length} item(s) present in cart` : 'Cart is currently empty',
    });
    if (!hasCart) missingActions.push('add_item_to_cart');
  }

  if (gLower.includes('like') && !gLower.includes('tiktok') && !gLower.includes('tinder')) {
    const postLiked = currentSnapshot.socialPosts.some((p) => p.isLiked);
    checks.push({
      label: 'Target Social Post Is Liked',
      passed: postLiked,
      details: postLiked ? 'Post successfully heart-reacted' : 'No liked post found',
    });
    if (!postLiked) missingActions.push('like_post');
  }

  if (gLower.includes('message') || gLower.includes('sarah')) {
    const hasSent = currentSnapshot.messageThreads.some((t) =>
      t.messages.some((m) => m.sender === 'me')
    );
    checks.push({
      label: 'Message Dispatched to Contact',
      passed: hasSent,
      details: hasSent ? 'Outgoing message sent into thread' : 'No sent message detected',
    });
    if (!hasSent) missingActions.push('send_message');
  }

  if (gLower.includes('note')) {
    const noteCount = currentSnapshot.notes.length;
    checks.push({
      label: 'Note Document Created & Saved',
      passed: noteCount > 0,
      details: `${noteCount} note(s) in sandbox library`,
    });
    if (noteCount === 0) missingActions.push('save_note');
  }

  if (gLower.includes('dark')) {
    checks.push({
      label: 'Display Theme Updated',
      passed: true,
      details: `Dark mode is currently ${currentSnapshot.settings.darkMode ? 'Enabled' : 'Disabled'}`,
    });
  }

  checks.push({
    label: 'Viewport Visual Fidelity Verified',
    passed: true,
    details: `Active viewport: ${currentSnapshot.currentApp.toUpperCase()} screen synchronized`,
  });

  const allPassed = checks.every((c) => c.passed);
  return { passed: allPassed, checks, missingActions };
}

export function generateSelfCorrectionSteps(
  missingActions: string[],
  goal: TaskGoal,
  currentSnapshot: PhoneSnapshot
): AgentStep[] {
  const steps: AgentStep[] = [];
  for (const action of missingActions) {
    if (action === 'add_item_to_cart') {
      if (currentSnapshot.currentApp !== 'food') {
        steps.push({ action: 'navigate_app', targetApp: 'food', detail: 'Switch to BiteDash' });
      }
      steps.push({ action: 'tap', targetName: 'add-pizza-to-cart', detail: 'Self-Correct: Tap Add to Cart' });
    } else if (action === 'like_post') {
      if (currentSnapshot.currentApp !== 'social') {
        steps.push({ action: 'navigate_app', targetApp: 'social', detail: 'Switch to Social' });
      }
      steps.push({ action: 'tap', targetName: 'post-like-button-0', detail: 'Self-Correct: Tap Like' });
    } else if (action === 'send_message') {
      if (currentSnapshot.currentApp !== 'messages') {
        steps.push({ action: 'navigate_app', targetApp: 'messages', detail: 'Switch to Messages' });
      }
      steps.push({ action: 'tap', targetName: 'thread-sarah', detail: 'Self-Correct: Open Sarah Thread' });
      steps.push({ action: 'tap', targetName: 'send-message-btn', detail: 'Self-Correct: Send Message' });
    } else if (action === 'save_note') {
      if (currentSnapshot.currentApp !== 'notes') {
        steps.push({ action: 'navigate_app', targetApp: 'notes', detail: 'Switch to Notes' });
      }
      steps.push({ action: 'tap', targetName: 'new-note-button', detail: 'Self-Correct: Create Note' });
    }
  }
  return steps;
}
