/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InstalledAppItem } from '../types/phone';

export interface MissingExternalAppMatch {
  appKey: string;
  appName: string;
  storeQuery: string;
  icon: string;
  packageName: string;
  bundleId: string;
}

interface KnownExternalAppSpec extends MissingExternalAppMatch {
  matchPatterns: RegExp[];
  idAliases: string[];
}

const KNOWN_EXTERNAL_APPS: KnownExternalAppSpec[] = [
  {
    appKey: 'whatsapp',
    appName: 'WhatsApp',
    storeQuery: 'WhatsApp',
    icon: '💬',
    packageName: 'com.whatsapp',
    bundleId: 'net.whatsapp.WhatsApp',
    idAliases: ['whatsapp', 'com.whatsapp', 'net.whatsapp.whatsapp'],
    matchPatterns: [/\bwhatsapp\b/i],
  },
  {
    appKey: 'gmail',
    appName: 'Gmail',
    storeQuery: 'Gmail',
    icon: '✉️',
    packageName: 'com.google.android.gm',
    bundleId: 'com.google.Gmail',
    idAliases: ['gmail', 'com.google.android.gm', 'com.google.gmail'],
    matchPatterns: [/\bgmail\b/i],
  },
  {
    appKey: 'tiktok',
    appName: 'TikTok',
    storeQuery: 'TikTok',
    icon: '🎵',
    packageName: 'com.zhiliaoapp.musically',
    bundleId: 'com.zhiliaoapp.musically',
    idAliases: ['tiktok', 'com.zhiliaoapp.musically'],
    matchPatterns: [/\btiktok\b/i, /\btik\s*tok\b/i],
  },
  {
    appKey: 'instagram',
    appName: 'Instagram',
    storeQuery: 'Instagram',
    icon: '📸',
    packageName: 'com.instagram.android',
    bundleId: 'com.burbn.instagram',
    idAliases: ['instagram', 'com.instagram.android', 'com.burbn.instagram'],
    matchPatterns: [/\binstagram\b/i, /\big\s+feed\b/i],
  },
  {
    appKey: 'telegram',
    appName: 'Telegram',
    storeQuery: 'Telegram',
    icon: '✈️',
    packageName: 'org.telegram.messenger',
    bundleId: 'ph.telegra.Telegraph',
    idAliases: ['telegram', 'org.telegram.messenger', 'ph.telegra.telegraph'],
    matchPatterns: [/\btelegram\b/i],
  },
  {
    appKey: 'youtube',
    appName: 'YouTube',
    storeQuery: 'YouTube',
    icon: '▶️',
    packageName: 'com.google.android.youtube',
    bundleId: 'com.google.ios.youtube',
    idAliases: ['youtube', 'com.google.android.youtube', 'com.google.ios.youtube'],
    matchPatterns: [/\byoutube\b/i],
  },
  {
    appKey: 'spotify',
    appName: 'Spotify',
    storeQuery: 'Spotify',
    icon: '🎧',
    packageName: 'com.spotify.music',
    bundleId: 'com.spotify.client',
    idAliases: ['spotify', 'com.spotify.music', 'com.spotify.client'],
    matchPatterns: [/\bspotify\b/i],
  },
  {
    appKey: 'twitter',
    appName: 'X (Twitter)',
    storeQuery: 'X',
    icon: '𝕏',
    packageName: 'com.twitter.android',
    bundleId: 'com.atebits.Tweetie2',
    idAliases: ['twitter', 'x', 'x (twitter)', 'com.twitter.android', 'com.atebits.tweetie2'],
    matchPatterns: [
      /\bx\s*\(\s*twitter\s*\)/i,
      /\btwitter\b/i,
      /(?:open|launch|check|use|go to|switch to|browse)\s+x\b/i,
    ],
  },
  {
    appKey: 'cryptowallet',
    appName: 'Crypto Wallet',
    storeQuery: 'Crypto Wallet',
    icon: '🪙',
    packageName: 'io.metamask',
    bundleId: 'io.metamask.MetaMask',
    idAliases: ['cryptowallet', 'crypto wallet', 'metamask', 'binance', 'coinbase', 'phantom', 'trust wallet'],
    matchPatterns: [
      /\bcrypto\s*wallet\b/i,
      /\bcryptowallet\b/i,
      /\bmetamask\b/i,
      /\bcoinbase\b/i,
      /\btrust\s*wallet\b/i,
      /\bphantom\b/i,
      /\bbinance\b/i,
    ],
  },
  {
    appKey: 'tinder',
    appName: 'Tinder',
    storeQuery: 'Tinder',
    icon: '🔥',
    packageName: 'com.tinder',
    bundleId: 'com.cardify.tinder',
    idAliases: ['tinder', 'com.tinder', 'com.cardify.tinder'],
    matchPatterns: [/\btinder\b/i],
  },
  {
    appKey: 'netflix',
    appName: 'Netflix',
    storeQuery: 'Netflix',
    icon: '🍿',
    packageName: 'com.netflix.mediaclient',
    bundleId: 'com.netflix.Netflix',
    idAliases: ['netflix', 'com.netflix.mediaclient', 'com.netflix.netflix'],
    matchPatterns: [/\bnetflix\b/i],
  },
  {
    appKey: 'uber',
    appName: 'Uber',
    storeQuery: 'Uber',
    icon: '🚗',
    packageName: 'com.ubercab',
    bundleId: 'com.ubercab.UberClient',
    idAliases: ['uber', 'com.ubercab', 'com.ubercab.uberclient'],
    matchPatterns: [/\buber\b/i],
  },
  {
    appKey: 'chatgpt',
    appName: 'ChatGPT',
    storeQuery: 'ChatGPT',
    icon: '🤖',
    packageName: 'com.openai.chatgpt',
    bundleId: 'com.openai.chat',
    idAliases: ['chatgpt', 'com.openai.chatgpt', 'com.openai.chat'],
    matchPatterns: [/\bchatgpt\b/i],
  },
  {
    appKey: 'duolingo',
    appName: 'Duolingo',
    storeQuery: 'Duolingo',
    icon: '🦉',
    packageName: 'com.duolingo',
    bundleId: 'com.duolingo.DuolingoMobile',
    idAliases: ['duolingo', 'com.duolingo', 'com.duolingo.duolingomobile'],
    matchPatterns: [/\bduolingo\b/i],
  },
  {
    appKey: 'canva',
    appName: 'Canva',
    storeQuery: 'Canva',
    icon: '🎨',
    packageName: 'com.canva.editor',
    bundleId: 'com.canva.Canva',
    idAliases: ['canva', 'com.canva.editor', 'com.canva.canva'],
    matchPatterns: [/\bcanva\b/i],
  },
  {
    appKey: 'chrome',
    appName: 'Google Chrome',
    storeQuery: 'Chrome',
    icon: '🌐',
    packageName: 'com.android.chrome',
    bundleId: 'com.google.chrome.ios',
    idAliases: ['chrome', 'google chrome', 'com.android.chrome', 'com.google.chrome.ios'],
    matchPatterns: [/\bgoogle\s+chrome\b/i, /\bchrome\b/i],
  },
];

function isAppInstalled(spec: KnownExternalAppSpec, installedApps: InstalledAppItem[]): boolean {
  return installedApps.some((app) => {
    const idLower = (app.id || '').toLowerCase();
    const nameLower = (app.name || '').toLowerCase();
    const pkgLower = (app.packageName || '').toLowerCase();
    const bundleLower = (app.bundleId || '').toLowerCase();

    return spec.idAliases.some((alias) => {
      const a = alias.toLowerCase();
      if (a.length <= 2) {
        return nameLower === a || idLower === a || nameLower.startsWith(`${a} `) || idLower.includes(`-${a}-`);
      }
      return (
        idLower === a ||
        idLower.includes(a) ||
        nameLower === a ||
        nameLower.includes(a) ||
        pkgLower === a ||
        bundleLower === a
      );
    });
  });
}

/**
 * Inspects a user prompt to determine if an external downloadable app is requested
 * and checks whether it is already installed on the virtual device.
 */
export function detectMissingExternalApp(
  prompt: string,
  installedApps: InstalledAppItem[]
): MissingExternalAppMatch | null {
  const cleanPrompt = (prompt || '').trim();
  if (!cleanPrompt) return null;

  for (const spec of KNOWN_EXTERNAL_APPS) {
    if (spec.matchPatterns.some((re) => re.test(cleanPrompt))) {
      if (!isAppInstalled(spec, installedApps)) {
        return {
          appKey: spec.appKey,
          appName: spec.appName,
          storeQuery: spec.storeQuery,
          icon: spec.icon,
          packageName: spec.packageName,
          bundleId: spec.bundleId,
        };
      }
      return null;
    }
  }

  return null;
}

/**
 * Checks if an installed app matches a missing-app request name/key.
 */
export function doesInstalledAppSatisfyMissing(
  installedApp: InstalledAppItem,
  missingAppName: string
): boolean {
  const target = (missingAppName || '').trim().toLowerCase();
  if (!target) return false;
  const spec = KNOWN_EXTERNAL_APPS.find(
    (s) => s.appName.toLowerCase() === target || s.storeQuery.toLowerCase() === target || s.appKey === target
  );
  if (spec) {
    return isAppInstalled(spec, [installedApp]);
  }
  const nameLower = (installedApp.name || '').toLowerCase();
  const idLower = (installedApp.id || '').toLowerCase();
  return nameLower.includes(target) || idLower.includes(target);
}
