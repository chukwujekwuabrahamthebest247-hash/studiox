/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep, PhoneAppType } from '../types/phone';

export type ChromeBridgeProvider = 'auto' | 'gemini' | 'chatgpt' | 'claude';

export interface ChromeBridgeConfig {
  enabled: boolean;
  preferredProvider: ChromeBridgeProvider;
  timeoutMs: number;
  lastPingAt?: string;
  extensionInstalled?: boolean;
  detectedProvider?: string | null;
  detectedTabTitle?: string | null;
}

export interface ChromeBridgePingResult {
  extensionInstalled: boolean;
  connected: boolean;
  activeTabProvider: 'Gemini' | 'ChatGPT' | 'Claude' | null;
  activeTabTitle?: string;
  activeTabUrl?: string;
  availableProviders?: string[];
  latencyMs: number;
  error?: string;
}

export interface ChromeBridgePlanResult {
  replyMessage: string;
  reasoning: string;
  steps: AgentStep[];
  provider: string;
  modelUsed: string;
}

export interface ChromeBridgeVisionResult {
  matchesInstruction: boolean;
  confidenceScore: number;
  observationText: string;
  discrepancyDetected: boolean;
  discrepancyReason?: string;
  correctiveActionNeeded?: string;
  detectedApp: string;
  detectedElements: string[];
  provider?: string;
}

const VALID_STEP_ACTIONS = new Set<AgentStep['action']>([
  'navigate_app',
  'go_home',
  'tap',
  'type_text',
  'swipe_up',
  'swipe_down',
  'wait',
  'biometric_auth',
  'guardrail_approval',
]);

function generateRequestId(): string {
  return `omni-bridge-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Sends a message to the companion Chrome Extension via window.postMessage
 * and awaits a matching response before timeout.
 */
function sendBridgeMessage<T = any>(
  type: 'OMNIAGENT_BRIDGE_PING' | 'OMNIAGENT_BRIDGE_REQUEST',
  payload: any,
  timeoutMs: number
): Promise<T | null> {
  if (typeof window === 'undefined') {
    return Promise.resolve(null);
  }

  const requestId = generateRequestId();
  const expectedResponseType =
    type === 'OMNIAGENT_BRIDGE_PING'
      ? 'OMNIAGENT_BRIDGE_PONG'
      : 'OMNIAGENT_BRIDGE_RESPONSE';

  return new Promise((resolve) => {
    let settled = false;

    const cleanup = () => {
      window.removeEventListener('message', handleWindowMessage);
      window.removeEventListener(expectedResponseType, handleCustomEvent as EventListener);
      clearTimeout(timer);
    };

    const finish = (result: T | null) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(result);
    };

    const handleWindowMessage = (event: MessageEvent) => {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      if (
        (data.type === expectedResponseType || data.type === 'OMNIAGENT_BRIDGE_RESPONSE') &&
        data.requestId === requestId
      ) {
        finish(data.payload ?? data);
      }
    };

    const handleCustomEvent = (event: CustomEvent) => {
      const detail = event.detail;
      if (detail && detail.requestId === requestId) {
        finish(detail.payload ?? detail);
      }
    };

    const timer = setTimeout(() => {
      finish(null);
    }, timeoutMs);

    window.addEventListener('message', handleWindowMessage);
    window.addEventListener(expectedResponseType, handleCustomEvent as EventListener);

    // Dispatch both postMessage and CustomEvent for maximum extension compatibility
    window.postMessage(
      {
        source: 'omniagent-app',
        type,
        requestId,
        payload,
      },
      '*'
    );

    try {
      window.dispatchEvent(
        new CustomEvent(type, {
          detail: { source: 'omniagent-app', type, requestId, payload },
        })
      );
    } catch {}
  });
}

/**
 * Extracts a JSON object from raw LLM response text (supports ```json``` fenced blocks or inline JSON).
 */
function extractJsonFromText(rawText: string): any | null {
  if (!rawText || typeof rawText !== 'string') return null;

  // 1. Try ```json ... ``` fenced block first
  const jsonFenceMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (jsonFenceMatch && jsonFenceMatch[1]) {
    try {
      return JSON.parse(jsonFenceMatch[1].trim());
    } catch {}
  }

  // 2. Try finding outermost { ... } block
  const firstBrace = rawText.indexOf('{');
  const lastBrace = rawText.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    const candidate = rawText.slice(firstBrace, lastBrace + 1);
    try {
      return JSON.parse(candidate);
    } catch {}
  }

  return null;
}

/**
 * Sends OMNIAGENT_BRIDGE_PING to check if the Chrome Extension is installed
 * and whether a supported AI web tab (Gemini, ChatGPT, Claude) is open.
 */
export async function pingChromeBridge(
  preferredProvider: ChromeBridgeProvider = 'auto',
  timeoutMs: number = 2500
): Promise<ChromeBridgePingResult> {
  const start = performance.now();
  const res = await sendBridgeMessage<any>(
    'OMNIAGENT_BRIDGE_PING',
    { preferredProvider },
    timeoutMs
  );
  const latencyMs = Math.max(1, Math.round(performance.now() - start));

  if (!res) {
    return {
      extensionInstalled: false,
      connected: false,
      activeTabProvider: null,
      latencyMs,
      error:
        'No response from Chrome Extension. Load the chrome-extension/ folder in chrome://extensions and refresh this tab.',
    };
  }

  return {
    extensionInstalled: Boolean(res.extensionInstalled ?? true),
    connected: Boolean(res.connected),
    activeTabProvider: res.activeTabProvider || null,
    activeTabTitle: res.activeTabTitle,
    activeTabUrl: res.activeTabUrl,
    availableProviders: Array.isArray(res.availableProviders) ? res.availableProviders : [],
    latencyMs,
    error: res.error,
  };
}

/**
 * Formats an action-planning prompt and relays it through the Chrome Extension
 * to the user's open AI web tab (Gemini, ChatGPT, or Claude).
 * Falls back cleanly (returns null) if extension/tab is unavailable or times out.
 */
export async function requestChromeBridgePlan(params: {
  prompt: string;
  currentApp: PhoneAppType;
  phoneStateSummary?: any;
  preferredProvider?: ChromeBridgeProvider;
  timeoutMs?: number;
}): Promise<ChromeBridgePlanResult | null> {
  const {
    prompt,
    currentApp,
    phoneStateSummary,
    preferredProvider = 'auto',
    timeoutMs = 28000,
  } = params;

  const structuredPrompt = [
    'You are the autonomous smartphone action planner for OmniPhone.',
    'STRICT RULE: Execute ONLY what the user explicitly instructed and NOTHING MORE. Never add unprompted clicks, extra navigations, or extra purchases.',
    `Current Active Phone App: "${currentApp}"`,
    phoneStateSummary ? `Phone State Snapshot: ${JSON.stringify(phoneStateSummary)}` : '',
    `User Instruction: "${prompt}"`,
    '',
    'Valid Phone App IDs: home, social, food, messages, notes, settings, browser, gallery, banking, sheets, quickbooks.',
    'Valid Step Actions: navigate_app, go_home, tap, type_text, swipe_up, swipe_down, wait, biometric_auth, guardrail_approval.',
    '',
    'Respond STRICTLY with a single ```json``` block matching this exact schema:',
    '```json',
    '{',
    '  "replyMessage": "Short status summary for the user",',
    '  "reasoning": "Brief explanation of the exact minimal steps",',
    '  "steps": [',
    '    {',
    '      "action": "navigate_app",',
    '      "targetApp": "browser",',
    '      "detail": "Open SearchGlobe browser"',
    '    }',
    '  ]',
    '}',
    '```',
  ]
    .filter(Boolean)
    .join('\n');

  const res = await sendBridgeMessage<any>(
    'OMNIAGENT_BRIDGE_REQUEST',
    {
      mode: 'plan',
      preferredProvider,
      prompt: structuredPrompt,
      rawUserPrompt: prompt,
      currentApp,
    },
    timeoutMs
  );

  if (!res || !res.ok || !res.text) {
    return null;
  }

  const parsed = extractJsonFromText(res.text);
  if (!parsed || !Array.isArray(parsed.steps) || parsed.steps.length === 0) {
    return null;
  }

  const sanitizedSteps: AgentStep[] = parsed.steps.map((s: any, idx: number) => {
    const rawAction = String(s?.action || 'wait').toLowerCase().trim() as AgentStep['action'];
    const action: AgentStep['action'] = VALID_STEP_ACTIONS.has(rawAction) ? rawAction : 'tap';
    return {
      id: s?.id || `bridge-step-${idx}-${Date.now()}`,
      action,
      detail: s?.detail || `Execute ${action}`,
      targetApp: s?.targetApp,
      targetName: s?.targetName,
      x: typeof s?.x === 'number' ? s.x : undefined,
      y: typeof s?.y === 'number' ? s.y : undefined,
      value: s?.value !== undefined ? String(s.value) : undefined,
      distance: typeof s?.distance === 'number' ? s.distance : undefined,
      duration: typeof s?.duration === 'number' ? s.duration : undefined,
      requiresBiometric: Boolean(s?.requiresBiometric),
      biometricPrompt: s?.biometricPrompt,
      requiresApproval: Boolean(s?.requiresApproval),
      guardrailType: s?.guardrailType,
      approvalDetail: s?.approvalDetail,
      status: 'pending',
    };
  });

  const providerLabel = res.provider || 'Chrome Web AI';
  return {
    replyMessage: parsed.replyMessage || `Executing via ${providerLabel} Chrome Bridge...`,
    reasoning: parsed.reasoning || `Formulated by ${providerLabel} web session`,
    steps: sanitizedSteps,
    provider: 'Chrome Bridge',
    modelUsed: `${providerLabel} (Web Session)`,
  };
}

/**
 * Sends a phone screenshot data URL + verification prompt through the Chrome Extension
 * so the open AI web tab inspects the image and returns structured vision verification JSON.
 */
export async function requestChromeBridgeVision(params: {
  screenshotDataUrl: string;
  prompt: string;
  currentStep?: string;
  currentApp: PhoneAppType;
  phoneState?: any;
  preferredProvider?: ChromeBridgeProvider;
  timeoutMs?: number;
}): Promise<ChromeBridgeVisionResult | null> {
  const {
    screenshotDataUrl,
    prompt,
    currentStep,
    currentApp,
    phoneState,
    preferredProvider = 'auto',
    timeoutMs = 24000,
  } = params;

  const visionPrompt = [
    'Inspect the attached smartphone screen screenshot carefully.',
    `User Instruction: "${prompt}"`,
    currentStep ? `Current Step Executed: "${currentStep}"` : '',
    `Active App Reported: "${currentApp}"`,
    phoneState ? `Phone State Summary: ${JSON.stringify(phoneState)}` : '',
    '',
    'Respond STRICTLY with a single ```json``` block matching this exact schema:',
    '```json',
    '{',
    '  "matchesInstruction": true,',
    '  "confidenceScore": 96,',
    '  "observationText": "Concise visual observation of what is currently visible on the phone screen",',
    '  "discrepancyDetected": false,',
    '  "discrepancyReason": "",',
    '  "correctiveActionNeeded": "none",',
    `  "detectedApp": "${currentApp}",`,
    '  "detectedElements": ["Element 1", "Element 2"]',
    '}',
    '```',
  ]
    .filter(Boolean)
    .join('\n');

  const res = await sendBridgeMessage<any>(
    'OMNIAGENT_BRIDGE_REQUEST',
    {
      mode: 'vision',
      preferredProvider,
      prompt: visionPrompt,
      screenshot: screenshotDataUrl,
      currentApp,
    },
    timeoutMs
  );

  if (!res || !res.ok || !res.text) {
    return null;
  }

  const parsed = extractJsonFromText(res.text);
  if (!parsed || typeof parsed.observationText !== 'string') {
    return null;
  }

  return {
    matchesInstruction:
      typeof parsed.matchesInstruction === 'boolean' ? parsed.matchesInstruction : true,
    confidenceScore:
      typeof parsed.confidenceScore === 'number' ? parsed.confidenceScore : 94,
    observationText: parsed.observationText,
    discrepancyDetected: Boolean(parsed.discrepancyDetected),
    discrepancyReason: parsed.discrepancyReason || undefined,
    correctiveActionNeeded: parsed.correctiveActionNeeded || 'none',
    detectedApp: parsed.detectedApp || currentApp,
    detectedElements: Array.isArray(parsed.detectedElements) ? parsed.detectedElements : [],
    provider: res.provider || 'Chrome Web AI',
  };
}
