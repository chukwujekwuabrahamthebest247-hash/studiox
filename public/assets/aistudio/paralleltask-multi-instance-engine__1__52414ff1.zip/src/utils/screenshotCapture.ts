/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BandwidthMode } from './lowBandwidthOptimizer';

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
}

export interface ScreenshotResult {
  dataUrl: string;
  timestamp: string;
  boundingBoxes: BoundingBox[];
  compressedSizeBytes?: number;
  savingsPercentage?: number;
  bandwidthMode?: BandwidthMode;
  detectedApp?: string;
  elementCount?: number;
  isLiveDeviceFrame?: boolean;
}

export interface ScreenshotCaptureOptions {
  currentApp?: string;
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

function collectDomBoundingBoxes(element: HTMLElement | null, width: number, height: number): BoundingBox[] {
  if (!element) return [];
  const boundingBoxes: BoundingBox[] = [];
  const targets = element.querySelectorAll<HTMLElement>('[data-agent-target]');
  const containerRect = element.getBoundingClientRect();
  const scaleX = width / Math.max(containerRect.width, 1);
  const scaleY = height / Math.max(containerRect.height, 1);

  targets.forEach((t) => {
    const r = t.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) {
      const x = Math.max(0, Math.round((r.left - containerRect.left) * scaleX));
      const y = Math.max(0, Math.round((r.top - containerRect.top) * scaleY));
      const w = Math.min(width - x, Math.round(r.width * scaleX));
      const h = Math.min(height - y, Math.round(r.height * scaleY));
      const label = t.getAttribute('data-agent-target') || t.innerText.slice(0, 20) || 'Target';
      boundingBoxes.push({ x, y, width: w, height: h, label });
    }
  });
  return boundingBoxes;
}

function encodeCompressedFrame(canvas: HTMLCanvasElement, bandwidthMode: BandwidthMode): string {
  const quality = bandwidthMode === 'low_data' ? 0.45 : 0.65;
  try {
    const webp = canvas.toDataURL('image/webp', quality);
    if (webp.startsWith('data:image/webp')) {
      return webp;
    }
  } catch {}
  return canvas.toDataURL('image/jpeg', quality);
}

/**
 * Event-driven compressed screenshot capture (<= 540px width, 0.65 WebP/JPEG quality).
 * Captures directly from client WebRTC <video>, WebSocket <canvas>, active live frame <img>,
 * or renders the sandboxed UI DOM cleanly when called after an action step.
 */
export async function capturePhoneScreenshot(
  element: HTMLElement | null,
  bandwidthMode: BandwidthMode = 'optimized_4g',
  _isFast: boolean = false,
  options?: ScreenshotCaptureOptions
): Promise<ScreenshotResult | null> {
  if (typeof window === 'undefined') return null;

  try {
    // Cap capture width strictly <= 540px (default 360x640, scales up to 540px max for wide frames)
    const MAX_WIDTH = 540;
    const width = Math.min(MAX_WIDTH, 360);
    const height = 640;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const iosLiveContainer = element?.querySelector<HTMLElement>('[data-agent-target="ios-live-screen"]');
    const adbLiveContainer = element?.querySelector<HTMLElement>('[data-agent-target="adb-live-screen"]');
    const liveContainer = iosLiveContainer || adbLiveContainer;

    if (liveContainer) {
      const boundingBoxes = collectDomBoundingBoxes(element, width, height);
      let drawnLiveFrame = false;

      // 1. Direct client-side WebRTC <video> stream capture (zero server roundtrip)
      const domVideo = liveContainer.querySelector<HTMLVideoElement>('video');
      if (domVideo && domVideo.readyState >= 2 && domVideo.videoWidth > 0) {
        const vw = Math.min(MAX_WIDTH, domVideo.videoWidth);
        const vh = Math.round((domVideo.videoHeight / domVideo.videoWidth) * vw);
        canvas.width = vw;
        canvas.height = vh;
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, vw, vh);
        ctx.drawImage(domVideo, 0, 0, vw, vh);
        drawnLiveFrame = true;
      }

      // 2. Direct client-side WebSocket binary <canvas> capture (zero server roundtrip)
      if (!drawnLiveFrame) {
        const domCanvas = liveContainer.querySelector<HTMLCanvasElement>('canvas');
        if (domCanvas && domCanvas.width > 0 && domCanvas.height > 0) {
          const cw = Math.min(MAX_WIDTH, domCanvas.width);
          const ch = Math.round((domCanvas.height / domCanvas.width) * cw);
          canvas.width = cw;
          canvas.height = ch;
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, cw, ch);
          ctx.drawImage(domCanvas, 0, 0, cw, ch);
          drawnLiveFrame = true;
        }
      }

      // 3. Direct DOM <img> already rendered in viewport
      if (!drawnLiveFrame) {
        const domImg = liveContainer.querySelector<HTMLImageElement>('img');
        if (domImg && domImg.complete && domImg.naturalWidth > 0) {
          const scaledW = Math.min(MAX_WIDTH, domImg.naturalWidth);
          const scaledH = Math.round((domImg.naturalHeight / domImg.naturalWidth) * scaledW);
          canvas.width = scaledW;
          canvas.height = scaledH;
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, scaledW, scaledH);
          ctx.drawImage(domImg, 0, 0, scaledW, scaledH);
          drawnLiveFrame = true;
        }
      }

      // 4. Single event-driven backend snapshot fallback only when no client stream/image is mounted
      if (!drawnLiveFrame) {
        const endpoint = iosLiveContainer ? '/api/ios/screen' : '/api/adb/screen';
        try {
          const res = await fetch(`${endpoint}?t=${Date.now()}`, { cache: 'no-store' });
          if (res.ok && (res.headers.get('content-type') || '').includes('image/')) {
            const blob = await res.blob();
            const objectUrl = URL.createObjectURL(blob);
            try {
              const img = await loadImageElement(objectUrl);
              const scaledW = Math.min(MAX_WIDTH, Math.max(img.width, 1));
              const scaledH = Math.round((Math.max(img.height, 1) / Math.max(img.width, 1)) * scaledW);
              canvas.width = scaledW;
              canvas.height = scaledH;
              ctx.fillStyle = '#000000';
              ctx.fillRect(0, 0, scaledW, scaledH);
              ctx.drawImage(img, 0, 0, scaledW, scaledH);
              drawnLiveFrame = true;
            } finally {
              URL.revokeObjectURL(objectUrl);
            }
          }
        } catch {}
      }

      if (drawnLiveFrame) {
        const dataUrl = encodeCompressedFrame(canvas, bandwidthMode);
        return {
          dataUrl,
          timestamp: new Date().toLocaleTimeString(),
          boundingBoxes,
          compressedSizeBytes: Math.round(dataUrl.length * 0.75),
          savingsPercentage: bandwidthMode === 'low_data' ? 74 : 58,
          bandwidthMode,
          detectedApp: options?.currentApp || (iosLiveContainer ? 'ios_live_app' : 'adb_live_app'),
          elementCount: boundingBoxes.length,
          isLiveDeviceFrame: true,
        };
      }
    }

    // Background base
    const isDarkMode = element ? element.classList.contains('bg-slate-900') : true;
    ctx.fillStyle = isDarkMode ? '#090d16' : '#f8fafc';
    ctx.fillRect(0, 0, width, height);

    // Collect DOM bounding boxes and screen details if element is provided
    const boundingBoxes: BoundingBox[] = [];
    let detectedApp = options?.currentApp || 'home';
    let timeText = '9:41';

    if (element) {
      // Find current time text
      const timeEl = element.querySelector('.font-mono');
      if (timeEl && timeEl.textContent) {
        timeText = timeEl.textContent.trim();
      }

      // Check detected app
      if (element.querySelector('[data-agent-target="dock-messages"]')) {
        detectedApp = 'home';
      }
      if (element.textContent?.includes('BiteDash Food') || element.querySelector('[data-category-id]')) {
        detectedApp = 'food';
      } else if (element.textContent?.includes('Pulse Social') || element.querySelector('[data-agent-target^="post-like-button"]')) {
        detectedApp = 'social';
      } else if (element.querySelector('[data-agent-target="messages-input-field"]') || element.textContent?.includes('iMessage')) {
        detectedApp = 'messages';
      } else if (element.textContent?.includes('Notes') && (element.querySelector('[data-agent-target="new-note-button"]') || element.querySelector('[data-agent-target="note-title-input"]'))) {
        detectedApp = 'notes';
      } else if (element.querySelector('[data-agent-target="browser-search-input"]') || element.textContent?.includes('SearchGlobe')) {
        detectedApp = 'browser';
      } else if (element.textContent?.includes('Apex Secure Bank') || element.textContent?.includes('24,850.12')) {
        detectedApp = 'banking';
      } else if (element.textContent?.includes('QuickBooks Online') || element.textContent?.includes('#INV-2026-104')) {
        detectedApp = 'quickbooks';
      } else if (element.textContent?.includes('System Settings') || element.querySelector('[data-agent-target="settings-darkmode-toggle"]')) {
        detectedApp = 'settings';
      } else if (element.textContent?.includes('Application View') || element.textContent?.includes('Sandboxed & Isolated')) {
        detectedApp = 'sandboxed_app';
      }

      // Collect real bounding boxes of all interactive targets
      const targets = element.querySelectorAll<HTMLElement>('[data-agent-target]');
      const containerRect = element.getBoundingClientRect();
      const scaleX = width / Math.max(containerRect.width, 1);
      const scaleY = height / Math.max(containerRect.height, 1);

      targets.forEach((t) => {
        const r = t.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          const x = Math.max(0, Math.round((r.left - containerRect.left) * scaleX));
          const y = Math.max(0, Math.round((r.top - containerRect.top) * scaleY));
          const w = Math.min(width - x, Math.round(r.width * scaleX));
          const h = Math.min(height - y, Math.round(r.height * scaleY));
          const label = t.getAttribute('data-agent-target') || t.innerText.slice(0, 20) || 'Target';
          boundingBoxes.push({ x, y, width: w, height: h, label });
        }
      });
    }

    // 1. Draw Status Bar
    ctx.fillStyle = isDarkMode ? '#e2e8f0' : '#1e293b';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(timeText, 24, 24);

    // Dynamic Island
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.roundRect(width / 2 - 40, 10, 80, 22, 11);
    ctx.fill();

    // Pulse dot inside Island
    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.arc(width / 2 + 25, 21, 3, 0, Math.PI * 2);
    ctx.fill();

    // Wifi and Battery Icons
    ctx.fillStyle = isDarkMode ? '#94a3b8' : '#475569';
    ctx.font = '10px sans-serif';
    ctx.fillText('5G', width - 68, 24);
    ctx.fillStyle = '#10b981';
    ctx.fillRect(width - 45, 16, 18, 9);
    ctx.fillStyle = isDarkMode ? '#94a3b8' : '#475569';
    ctx.fillRect(width - 27, 18, 2, 5);

    // 2. Draw Screen View based on detected app
    if (detectedApp === 'home') {
      // Search bar
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 50, width - 40, 36, 12);
      ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.font = '11px sans-serif';
      const homeSearch = element?.querySelector<HTMLInputElement>('[data-agent-target="home-omnisearch-input"] input')?.value;
      ctx.fillText(homeSearch ? `🔍 ${homeSearch}` : '🔍 Search apps, web, & contacts...', 32, 73);

      // App Icons Grid
      const apps = [
        { name: 'BiteDash', icon: '🍕', color: '#ea580c' },
        { name: 'Pulse', icon: '📸', color: '#db2777' },
        { name: 'Messages', icon: '💬', color: '#059669' },
        { name: 'Notes', icon: '📝', color: '#d97706' },
        { name: 'SearchGlobe', icon: '🌐', color: '#0284c7' },
        { name: 'Apex Bank', icon: '🏦', color: '#4f46e5' },
        { name: 'QuickBooks', icon: '💼', color: '#16a34a' },
        { name: 'Settings', icon: '⚙️', color: '#475569' },
        { name: 'WhatsApp', icon: '💬', color: '#10b981' },
        { name: 'Telegram', icon: '✈️', color: '#0284c7' },
        { name: '+ Add App', icon: '➕', color: '#059669' },
      ];

      apps.forEach((app, idx) => {
        const col = idx % 4;
        const row = Math.floor(idx / 4);
        const x = 32 + col * 78;
        const y = 110 + row * 82;

        ctx.fillStyle = app.color;
        ctx.beginPath();
        ctx.roundRect(x, y, 48, 48, 14);
        ctx.fill();

        ctx.font = '20px sans-serif';
        ctx.fillText(app.icon, x + 12, y + 32);

        ctx.fillStyle = '#cbd5e1';
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(app.name, x + 24, y + 62);
        ctx.textAlign = 'left';
      });

      // Dock
      ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
      ctx.beginPath();
      ctx.roundRect(24, height - 90, width - 48, 56, 20);
      ctx.fill();
      const dockIcons = ['💬', '🌐', '🍕', '⚙️'];
      dockIcons.forEach((icon, i) => {
        ctx.font = '22px sans-serif';
        ctx.fillText(icon, 52 + i * 72, height - 54);
      });
    } else if (detectedApp === 'food') {
      // Header
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('🍕 BiteDash Food', 24, 65);

      // Categories
      const cats = ['All', 'Pizza', 'Burger', 'Sushi', 'Drinks'];
      cats.forEach((cat, i) => {
        ctx.fillStyle = i === 1 ? '#059669' : '#1e293b';
        ctx.beginPath();
        ctx.roundRect(24 + i * 62, 85, 54, 26, 8);
        ctx.fill();
        ctx.fillStyle = i === 1 ? '#ffffff' : '#94a3b8';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(cat, 34 + i * 62, 102);
      });

      // Food items
      const items = [
        { name: 'Artisan Pepperoni Pizza', desc: 'San Marzano tomatoes, mozzarella, spicy pepperoni', price: '$18.99' },
        { name: 'Smash Truffle Burger', desc: 'Double smash patty, black truffle aioli, brioche', price: '$15.50' },
        { name: 'Dragon Roll Supreme', desc: 'Eel, crab salad, avocado, sweet unagi drizzle', price: '$21.00' },
      ];

      items.forEach((item, i) => {
        const y = 130 + i * 95;
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect(20, y, width - 40, 82, 14);
        ctx.fill();

        ctx.fillStyle = '#334155';
        ctx.beginPath();
        ctx.roundRect(32, y + 12, 58, 58, 10);
        ctx.fill();
        ctx.font = '28px sans-serif';
        ctx.fillText(i === 0 ? '🍕' : i === 1 ? '🍔' : '🍣', 44, y + 50);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(item.name, 100, y + 28);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px sans-serif';
        ctx.fillText(item.desc.slice(0, 32) + '...', 100, y + 46);

        ctx.fillStyle = '#34d399';
        ctx.font = 'bold 12px monospace';
        ctx.fillText(item.price, 100, y + 68);

        // Add button
        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.roundRect(width - 80, y + 50, 48, 24, 8);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText('+ Add', width - 72, y + 66);
      });

      // Floating Cart check
      const cartEl = element?.querySelector('[data-agent-target="food-floating-cart"]');
      if (cartEl || element?.textContent?.includes('in Cart')) {
        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.roundRect(20, height - 75, width - 40, 44, 14);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('✓ 1 item(s) in Cart', 36, height - 48);
        ctx.fillText('$18.99 ➔', width - 90, height - 48);
      }
    } else if (detectedApp === 'messages') {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('💬 Messages', 24, 65);

      const threads = [
        { name: 'Sarah Chen', msg: 'Hey! Are we still confirmed for lunch tomorrow?', time: '10:30 AM' },
        { name: 'Marcus Brody', msg: 'The design prototypes are uploaded to Figma.', time: 'Yesterday' },
        { name: 'Elena Rostova', msg: 'Code review approved and pushed to staging.', time: 'Monday' },
      ];

      threads.forEach((t, i) => {
        const y = 90 + i * 72;
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect(20, y, width - 40, 62, 14);
        ctx.fill();

        ctx.fillStyle = '#059669';
        ctx.beginPath();
        ctx.arc(48, y + 31, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(t.name.slice(0, 1), 44, y + 35);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(t.name, 76, y + 26);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px monospace';
        ctx.fillText(t.time, width - 80, y + 26);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px sans-serif';
        ctx.fillText(t.msg.slice(0, 32) + '...', 76, y + 46);
      });

      // Draft input area
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, height - 70, width - 40, 40, 12);
      ctx.fill();
      ctx.fillStyle = '#64748b';
      ctx.font = '11px sans-serif';
      ctx.fillText('Type iMessage or SMS...', 36, height - 45);
    } else if (detectedApp === 'social') {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('📸 Pulse Social', 24, 65);

      // Post Card
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 85, width - 40, 280, 16);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('Alex Rivera', 36, 112);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px sans-serif';
      ctx.fillText('@arivera • 2h ago', 36, 126);

      // Post Image
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(20, 138, width - 40, 150);
      ctx.fillStyle = '#34d399';
      ctx.font = '12px sans-serif';
      ctx.fillText('🏔️ Mountain sunrise with autonomous drones', 36, 210);

      // Action bar
      ctx.fillStyle = '#f43f5e';
      ctx.fillText('❤️ 1,248 Likes', 36, 315);
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('💬 89 Comments', 140, 315);
      ctx.fillText('🔖 Saved', width - 80, 315);
    } else if (detectedApp === 'banking') {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('🏦 Apex Secure Bank', 24, 65);

      // Balance Card
      ctx.fillStyle = '#064e3b';
      ctx.beginPath();
      ctx.roundRect(20, 90, width - 40, 110, 16);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = '11px monospace';
      ctx.fillText('TOTAL LIQUID BALANCE', 36, 118);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 26px monospace';
      ctx.fillText('$24,850.12', 36, 156);
      ctx.fillStyle = '#a7f3d0';
      ctx.font = '10px sans-serif';
      ctx.fillText('FDIC Insured • Zero Liability Protection', 36, 180);

      // Actions
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 220, (width - 50) / 2, 42, 12);
      ctx.roundRect(width / 2 + 5, 220, (width - 50) / 2, 42, 12);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText('Export Statement', 32, 246);
      ctx.fillStyle = '#fbbf24';
      ctx.fillText('Audit Charges', width / 2 + 18, 246);
    } else if (detectedApp === 'quickbooks') {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('💼 QuickBooks Online', 24, 65);

      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 90, width - 40, 140, 16);
      ctx.fill();

      ctx.fillStyle = '#94a3b8';
      ctx.font = '11px sans-serif';
      ctx.fillText('Invoice:', 36, 120);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('#INV-2026-104', width - 140, 120);

      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Client:', 36, 150);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Alex Rivera', width - 140, 150);

      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Total:', 36, 180);
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 14px monospace';
      ctx.fillText('$1,800.00', width - 140, 180);

      // Send Button
      ctx.fillStyle = '#059669';
      ctx.beginPath();
      ctx.roundRect(20, 250, width - 40, 44, 14);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('Verify & Send Invoice', width / 2 - 60, 277);
    } else if (detectedApp === 'notes') {
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('📝 Notes', 24, 65);

      const notes = [
        { title: 'Project Roadmap 2026', body: 'AI agent process isolation, multi-slot multitasking', date: 'Oct 24' },
        { title: 'Shopping Checklist', body: 'HDMI 2.1 cable, thermal pads, ergonomic mouse', date: 'Oct 19' },
      ];

      notes.forEach((n, i) => {
        const y = 90 + i * 85;
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect(20, y, width - 40, 72, 14);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(n.title, 36, y + 26);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px monospace';
        ctx.fillText(n.date, width - 75, y + 26);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px sans-serif';
        ctx.fillText(n.body.slice(0, 36) + '...', 36, y + 48);
      });
    } else if (detectedApp === 'browser') {
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 50, width - 40, 36, 12);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.font = '11px monospace';
      ctx.fillText('🌐 https://verified.ai/doc/isolation', 36, 73);

      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 100, width - 40, 160, 16);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 10px monospace';
      ctx.fillText('AUTHORITATIVE SOURCE VERIFIED', 36, 125);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 13px sans-serif';
      ctx.fillText('Multi-Instance Process Isolation in GUIs', 36, 150);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '11px sans-serif';
      ctx.fillText('Enables web applications to execute background tasks', 36, 175);
      ctx.fillText('with independent actuator control threads and 0% cross-slot leakage.', 36, 195);
    } else {
      // General / sandboxed app view
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText('📦 Sandboxed Application View', 24, 65);

      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(20, 90, width - 40, 160, 16);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 10px monospace';
      ctx.fillText('STATUS: PROCESS RUNNING', 36, 120);
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '11px monospace';
      ctx.fillText('➜ Memory sandbox allocation: 48.2 MB', 36, 145);
      ctx.fillText('➜ Virtual network interface: veth0 [OK]', 36, 165);
      ctx.fillText('➜ Actuator touch listener: READY', 36, 185);
      ctx.fillText('➜ Automation fidelity check: 100%', 36, 205);
    }

    // 3. Draw Touch Actuator Cursor (if visible)
    if (element) {
      const cursorEl = element.querySelector<HTMLElement>('.rounded-full.border-2.border-emerald-400');
      if (cursorEl) {
        const cursorParent = cursorEl.closest<HTMLElement>('.absolute.z-50');
        if (cursorParent) {
          const leftPercent = parseFloat(cursorParent.style.left || '50');
          const topPercent = parseFloat(cursorParent.style.top || '50');
          const cx = Math.round((leftPercent / 100) * width);
          const cy = Math.round((topPercent / 100) * height);

          // Outer glowing ring
          ctx.strokeStyle = '#34d399';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(cx, cy, 14, 0, Math.PI * 2);
          ctx.stroke();

          // Inner touch center
          ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';
          ctx.beginPath();
          ctx.arc(cx, cy, 14, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(cx, cy, 3, 0, Math.PI * 2);
          ctx.fill();

          // Actuator label
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.roundRect(cx - 24, cy + 18, 48, 16, 8);
          ctx.fill();
          ctx.fillStyle = '#34d399';
          ctx.font = 'bold 8px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('ACTUATOR', cx, cy + 29);
          ctx.textAlign = 'left';
        }
      }
    }

    // Bottom home indicator bar
    ctx.fillStyle = '#64748b';
    ctx.beginPath();
    ctx.roundRect(width / 2 - 50, height - 12, 100, 4, 2);
    ctx.fill();

    // Model perception watermark
    ctx.fillStyle = 'rgba(52, 211, 153, 0.35)';
    ctx.font = 'bold 9px monospace';
    ctx.fillText('GEMINI VISION FEED • CONTINUOUS QA', 20, height - 24);

    const dataUrl = encodeCompressedFrame(canvas, bandwidthMode);

    return {
      dataUrl,
      timestamp: new Date().toLocaleTimeString(),
      boundingBoxes,
      compressedSizeBytes: Math.round(dataUrl.length * 0.75),
      savingsPercentage: bandwidthMode === 'low_data' ? 74 : 58,
      bandwidthMode,
      detectedApp,
      elementCount: boundingBoxes.length,
    };
  } catch (err) {
    console.warn('Screenshot capture error:', err);
    return null;
  }
}
