/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InstalledAppItem } from '../types/phone';

const DB_NAME = 'OmniAgentBrowserFileVault';
const DB_VERSION = 1;
const STORE_PACKAGE_BLOBS = 'packageBlobs';
const STORE_INSTALLED_APPS = 'installedApps';
const VAULT_INITIALIZED_KEY = 'omniagent_file_vault_initialized_v1';

export interface StoredPackageBlob {
  hash: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  buffer: ArrayBuffer;
  uploadedAt: string;
  referenceCount: number;
}

export interface VaultSaveResult {
  hash: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  deduplicated: boolean;
}

export interface VaultStorageStats {
  uniqueBlobsCount: number;
  totalBytesStored: number;
  appCount: number;
}

function isIndexedDbAvailable(): boolean {
  return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
}

function openVaultDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!isIndexedDbAvailable()) {
      reject(new Error('IndexedDB is unavailable in this environment.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_PACKAGE_BLOBS)) {
        db.createObjectStore(STORE_PACKAGE_BLOBS, { keyPath: 'hash' });
      }
      if (!db.objectStoreNames.contains(STORE_INSTALLED_APPS)) {
        db.createObjectStore(STORE_INSTALLED_APPS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open IndexedDB vault.'));
  });
}

/**
 * Computes a lowercase hex SHA-256 digest of a File or ArrayBuffer directly in the browser.
 */
export async function computeFileSha256(fileOrBuffer: File | ArrayBuffer): Promise<string> {
  const buffer =
    fileOrBuffer instanceof ArrayBuffer ? fileOrBuffer : await fileOrBuffer.arrayBuffer();

  if (typeof crypto !== 'undefined' && crypto.subtle?.digest) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // Deterministic fallback hash only if WebCrypto subtle is unavailable
  const bytes = new Uint8Array(buffer);
  let h1 = 0x811c9dc5;
  for (let i = 0; i < bytes.length; i++) {
    h1 ^= bytes[i];
    h1 = Math.imul(h1, 0x01000193);
  }
  return `fallback-${(h1 >>> 0).toString(16).padStart(8, '0')}-${bytes.length}`;
}

/**
 * Stores an uploaded APK/IPA binary in client-side IndexedDB (0 bytes server storage)
 * and deduplicates identical binaries using their SHA-256 hash.
 */
export async function savePackageFileWithDedup(file: File): Promise<VaultSaveResult> {
  const buffer = await file.arrayBuffer();
  const hash = await computeFileSha256(buffer);
  const mimeType = file.type || 'application/octet-stream';

  if (!isIndexedDbAvailable()) {
    return {
      hash,
      fileName: file.name,
      mimeType,
      sizeBytes: file.size,
      deduplicated: false,
    };
  }

  try {
    const db = await openVaultDatabase();
    return await new Promise<VaultSaveResult>((resolve, reject) => {
      const tx = db.transaction(STORE_PACKAGE_BLOBS, 'readwrite');
      const store = tx.objectStore(STORE_PACKAGE_BLOBS);
      const getReq = store.get(hash);

      let wasDeduplicated = false;

      getReq.onsuccess = () => {
        const existing = getReq.result as StoredPackageBlob | undefined;
        if (existing) {
          wasDeduplicated = true;
          store.put({
            ...existing,
            referenceCount: (existing.referenceCount || 1) + 1,
          });
        } else {
          const entry: StoredPackageBlob = {
            hash,
            fileName: file.name,
            mimeType,
            sizeBytes: file.size,
            buffer,
            uploadedAt: new Date().toISOString(),
            referenceCount: 1,
          };
          store.put(entry);
        }
      };

      tx.oncomplete = () => {
        db.close();
        resolve({
          hash,
          fileName: file.name,
          mimeType,
          sizeBytes: file.size,
          deduplicated: wasDeduplicated,
        });
      };

      tx.onerror = () => {
        db.close();
        reject(tx.error || new Error('Failed saving package blob to IndexedDB.'));
      };
    });
  } catch {
    return {
      hash,
      fileName: file.name,
      mimeType,
      sizeBytes: file.size,
      deduplicated: false,
    };
  }
}

/**
 * Loads persisted installed apps from IndexedDB.
 * Returns `null` if the vault has never been initialized so first-run defaults can be seeded cleanly.
 */
export async function loadInstalledAppsFromVault(): Promise<InstalledAppItem[] | null> {
  if (!isIndexedDbAvailable()) return null;

  let isInitialized = false;
  try {
    isInitialized = localStorage.getItem(VAULT_INITIALIZED_KEY) === 'true';
  } catch {}

  try {
    const db = await openVaultDatabase();
    const apps = await new Promise<InstalledAppItem[]>((resolve, reject) => {
      const tx = db.transaction(STORE_INSTALLED_APPS, 'readonly');
      const store = tx.objectStore(STORE_INSTALLED_APPS);
      const req = store.getAll();

      req.onsuccess = () => {
        resolve(Array.isArray(req.result) ? (req.result as InstalledAppItem[]) : []);
      };
      req.onerror = () => {
        reject(req.error || new Error('Failed loading installed apps from IndexedDB.'));
      };
      tx.oncomplete = () => db.close();
    });

    if (!isInitialized && apps.length === 0) {
      return null;
    }

    return apps.sort((a, b) => {
      const tA = a.installedAt ? Date.parse(a.installedAt) : 0;
      const tB = b.installedAt ? Date.parse(b.installedAt) : 0;
      return tA - tB;
    });
  } catch {
    return null;
  }
}

export async function saveInstalledAppToVault(app: InstalledAppItem): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  try {
    localStorage.setItem(VAULT_INITIALIZED_KEY, 'true');
  } catch {}

  try {
    const db = await openVaultDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_INSTALLED_APPS, 'readwrite');
      const store = tx.objectStore(STORE_INSTALLED_APPS);
      store.put({
        ...app,
        installedAt: app.installedAt || new Date().toISOString(),
      });
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error || new Error('Failed saving installed app to IndexedDB.'));
      };
    });
  } catch {}
}

export async function saveAllInstalledAppsToVault(apps: InstalledAppItem[]): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  try {
    localStorage.setItem(VAULT_INITIALIZED_KEY, 'true');
  } catch {}

  try {
    const db = await openVaultDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_INSTALLED_APPS, 'readwrite');
      const store = tx.objectStore(STORE_INSTALLED_APPS);
      store.clear();
      const baseTime = Date.now();
      apps.forEach((app, index) => {
        store.put({
          ...app,
          installedAt: app.installedAt || new Date(baseTime + index).toISOString(),
        });
      });
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error || new Error('Failed syncing installed apps to IndexedDB.'));
      };
    });
  } catch {}
}

export async function removeInstalledAppFromVault(appId: string): Promise<void> {
  if (!isIndexedDbAvailable()) return;
  try {
    localStorage.setItem(VAULT_INITIALIZED_KEY, 'true');
  } catch {}

  try {
    const db = await openVaultDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_INSTALLED_APPS, 'readwrite');
      const store = tx.objectStore(STORE_INSTALLED_APPS);
      store.delete(appId);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error || new Error('Failed deleting app from IndexedDB.'));
      };
    });
  } catch {}
}

export async function getVaultStorageStats(): Promise<VaultStorageStats> {
  if (!isIndexedDbAvailable()) {
    return { uniqueBlobsCount: 0, totalBytesStored: 0, appCount: 0 };
  }

  try {
    const db = await openVaultDatabase();
    return await new Promise<VaultStorageStats>((resolve) => {
      const tx = db.transaction([STORE_PACKAGE_BLOBS, STORE_INSTALLED_APPS], 'readonly');
      const blobReq = tx.objectStore(STORE_PACKAGE_BLOBS).getAll();
      const appReq = tx.objectStore(STORE_INSTALLED_APPS).getAll();

      tx.oncomplete = () => {
        db.close();
        const blobs = (blobReq.result as StoredPackageBlob[]) || [];
        const apps = (appReq.result as InstalledAppItem[]) || [];
        const totalBytesStored = blobs.reduce((sum, b) => sum + (b.sizeBytes || 0), 0);
        resolve({
          uniqueBlobsCount: blobs.length,
          totalBytesStored,
          appCount: apps.length,
        });
      };

      tx.onerror = () => {
        db.close();
        resolve({ uniqueBlobsCount: 0, totalBytesStored: 0, appCount: 0 });
      };
    });
  } catch {
    return { uniqueBlobsCount: 0, totalBytesStored: 0, appCount: 0 };
  }
}
