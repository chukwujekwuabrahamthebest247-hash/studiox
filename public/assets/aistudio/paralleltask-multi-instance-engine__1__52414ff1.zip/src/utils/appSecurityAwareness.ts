/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppSecurityProfile } from '../types/securityAwareness';

export const BUILT_IN_PROFILES: Record<string, AppSecurityProfile> = {
  home: {
    id: 'home',
    name: 'Home OS Springboard',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 5,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  browser: {
    id: 'browser',
    name: 'SearchGlobe Browser',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 15,
    requiresBiometricAuth: false,
    vaultMaskingActive: true,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  chrome: {
    id: 'chrome',
    name: 'Google Chrome AI Browser',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 12,
    requiresBiometricAuth: false,
    vaultMaskingActive: true,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  banking: {
    id: 'banking',
    name: 'Apex Secure Bank',
    securityTier: 'TIER_1_CRITICAL',
    riskScore: 95,
    requiresBiometricAuth: true,
    vaultMaskingActive: true,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: true },
  },
  quickbooks: {
    id: 'quickbooks',
    name: 'Intuit QuickBooks Online',
    securityTier: 'TIER_2_RESTRICTED',
    riskScore: 80,
    requiresBiometricAuth: true,
    vaultMaskingActive: true,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: true },
  },
  food: {
    id: 'food',
    name: 'BiteDash Food Delivery',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 30,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  social: {
    id: 'social',
    name: 'Pulse Social',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 10,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  messages: {
    id: 'messages',
    name: 'Secure Chat & SMS',
    securityTier: 'TIER_2_RESTRICTED',
    riskScore: 40,
    requiresBiometricAuth: false,
    vaultMaskingActive: true,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  notes: {
    id: 'notes',
    name: 'Encrypted Notes',
    securityTier: 'TIER_3_STANDARD',
    riskScore: 20,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
  settings: {
    id: 'settings',
    name: 'System Preferences',
    securityTier: 'TIER_2_RESTRICTED',
    riskScore: 35,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'built_in_rules',
    guardrailRules: { requiresApprovalForTransactions: false },
  },
};

export async function resolveAppSecurityProfile(
  target: string,
  serperKey?: string,
  tavilyKey?: string
): Promise<AppSecurityProfile | null> {
  const clean = target.toLowerCase().trim();
  if (BUILT_IN_PROFILES[clean]) {
    return BUILT_IN_PROFILES[clean];
  }

  return {
    id: clean,
    name: target.charAt(0).toUpperCase() + target.slice(1),
    securityTier: 'TIER_3_STANDARD',
    riskScore: 25,
    requiresBiometricAuth: false,
    vaultMaskingActive: false,
    researchSource: 'heuristic_sandbox',
    guardrailRules: { requiresApprovalForTransactions: false },
  };
}
