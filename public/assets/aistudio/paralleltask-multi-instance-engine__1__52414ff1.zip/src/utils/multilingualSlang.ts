/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SupportedLanguage = 'en' | 'es' | 'ja' | 'zh' | 'fr' | 'de' | 'pidgin' | 'yo' | 'ig';

export interface LanguageInfo {
  code: SupportedLanguage;
  label: string;
  flag: string;
  samplePrompt: string;
}

export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  { code: 'en', label: 'English', flag: '🇺🇸', samplePrompt: 'Order a pepperoni pizza on BiteDash' },
  { code: 'es', label: 'Español', flag: '🇪🇸', samplePrompt: 'Pide una pizza de pepperoni en BiteDash' },
  { code: 'ja', label: '日本語', flag: '🇯🇵', samplePrompt: 'BiteDashでペパロニピザを注文して' },
  { code: 'zh', label: '中文', flag: '🇨🇳', samplePrompt: '在BiteDash上点一份意大利辣香肠披萨' },
  { code: 'fr', label: 'Français', flag: '🇫🇷', samplePrompt: 'Commande une pizza pepperoni sur BiteDash' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪', samplePrompt: 'Bestelle eine Peperoni-Pizza auf BiteDash' },
  { code: 'pidgin', label: 'Naija Pidgin', flag: '🇳🇬', samplePrompt: 'Abeg help me order hot pepperoni pizza for BiteDash sharp sharp' },
  { code: 'yo', label: 'Yorùbá', flag: '🇳🇬', samplePrompt: 'Bá mi ra pizza lórí BiteDash' },
  { code: 'ig', label: 'Igbo', flag: '🇳🇬', samplePrompt: 'Zụrụ m pizza na BiteDash ngwa ngwa' },
];
