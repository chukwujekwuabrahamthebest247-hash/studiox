/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class SandboxedAppStore {
  private store: Map<string, any> = new Map();

  public get(key: string): any {
    return this.store.get(key);
  }

  public set(key: string, value: any): void {
    this.store.set(key, value);
  }

  public clear(): void {
    this.store.clear();
  }
}

export const sandboxedAppStore = new SandboxedAppStore();
