/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  DEFAULT_INITIAL_BALANCE,
  LOW_QUOTA_ALERT_THRESHOLD,
  AUTOMATION_MARKUP_MULTIPLIER,
  APP_INSTALL_TOKEN_COST,
  PROMPT_PLANNING_TOKEN_COST,
  EXECUTION_STEP_TOKEN_COST,
  REFERRAL_BONUS_TOKENS,
  REFERRAL_QUALIFYING_PURCHASE_USD,
  AuthenticatedUser,
  QuotaLedgerEntry,
  UserTokenWallet,
  tokensToUsd,
  usdToTokens,
} from '../types/tokenBilling';

const WALLET_STORAGE_KEY = 'omniagent_user_token_wallet';
const LEDGER_STORAGE_KEY = 'omniagent_quota_ledger';
const AUTH_TOKEN_KEY = 'omniagent_auth_token';
const AUTH_USER_KEY = 'omniagent_auth_user';
const CLIENT_ID_KEY = 'omniagent_client_id';
const QUOTA_EVENT_NAME = 'omniagent_quota_updated';
const AUTH_EVENT_NAME = 'omniagent_auth_updated';
const REFERRAL_EVENT_NAME = 'omniagent_referral_reward_received';

export function getOrCreateClientId(): string {
  if (typeof window === 'undefined') return 'usr_default_agent_owner';
  try {
    const existing = localStorage.getItem(CLIENT_ID_KEY);
    if (existing) return existing;
    const generated = `guest_${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem(CLIENT_ID_KEY, generated);
    return generated;
  } catch {
    return 'usr_default_agent_owner';
  }
}

export function getStoredAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getStoredAuthUser(): AuthenticatedUser | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(AUTH_USER_KEY);
    return raw ? (JSON.parse(raw) as AuthenticatedUser) : null;
  } catch {
    return null;
  }
}

export function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-omni-client-id': getOrCreateClientId(),
  };
  const token = getStoredAuthToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export function getAuthMultipartHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'x-omni-client-id': getOrCreateClientId(),
  };
  const token = getStoredAuthToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export function dispatchOpenAuthModal(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('omniagent_open_auth_modal'));
  }
}

export function dispatchOpenBillingModal(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('omniagent_open_billing_modal'));
  }
}

function notifyAuthChanged(user: AuthenticatedUser | null): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(AUTH_EVENT_NAME, { detail: { user } }));
  }
}

export function setAuthSession(
  token: string,
  user: AuthenticatedUser,
  wallet?: UserTokenWallet,
  ledger?: QuotaLedgerEntry[]
): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(AUTH_TOKEN_KEY, token);
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
    } catch {}
  }
  if (ledger) saveLedger(ledger);
  if (wallet) saveWallet(wallet);
  notifyAuthChanged(user);
}

export function clearAuthSession(): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem(AUTH_TOKEN_KEY);
      localStorage.removeItem(AUTH_USER_KEY);
    } catch {}
  }
  notifyAuthChanged(null);
  void syncWalletFromServer();
}

export function subscribeToAuthChanges(
  callback: (user: AuthenticatedUser | null) => void
): () => void {
  const handler = () => {
    callback(getStoredAuthUser());
  };
  if (typeof window !== 'undefined') {
    window.addEventListener(AUTH_EVENT_NAME, handler);
  }
  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(AUTH_EVENT_NAME, handler);
    }
  };
}

export function getStoredWallet(): UserTokenWallet {
  try {
    const raw = localStorage.getItem(WALLET_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const generatedCode = 'OMNI-' + Math.random().toString(36).substring(2, 6).toUpperCase();
      return {
        userId: parsed.userId || getOrCreateClientId(),
        referralCode: parsed.referralCode || generatedCode,
        referredBy: parsed.referredBy || undefined,
        hasMadeFirstQualifyingPurchase: Boolean(parsed.hasMadeFirstQualifyingPurchase),
        referralInvitesCount: Math.max(0, Math.floor(Number(parsed.referralInvitesCount) || 0)),
        referralConversionsCount: Math.max(0, Math.floor(Number(parsed.referralConversionsCount) || 0)),
        referralTokensEarned: Math.max(0, Math.floor(Number(parsed.referralTokensEarned) || 0)),
        appTokenBalance: Math.max(0, Math.floor(Number(parsed.appTokenBalance) ?? DEFAULT_INITIAL_BALANCE)),
        lifetimeTokensUsed: Math.max(0, Math.floor(Number(parsed.lifetimeTokensUsed) || 0)),
        lifetimeTokensPurchased: Math.max(0, Math.floor(Number(parsed.lifetimeTokensPurchased) || 0)),
        lastTopupDate: parsed.lastTopupDate,
        createdAt: parsed.createdAt || new Date().toISOString(),
        updatedAt: parsed.updatedAt || new Date().toISOString(),
      };
    }
  } catch (err) {
    console.warn('Quota wallet read notice:', err);
  }

  const personalReferralCode = 'OMNI-' + Math.random().toString(36).substring(2, 6).toUpperCase();
  const initialWallet: UserTokenWallet = {
    userId: getOrCreateClientId(),
    referralCode: personalReferralCode,
    referredBy: undefined,
    hasMadeFirstQualifyingPurchase: false,
    referralInvitesCount: 0,
    referralConversionsCount: 0,
    referralTokensEarned: 0,
    appTokenBalance: DEFAULT_INITIAL_BALANCE,
    lifetimeTokensUsed: 0,
    lifetimeTokensPurchased: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  saveWallet(initialWallet);
  saveLedger([]);

  return initialWallet;
}

export function saveWallet(wallet: UserTokenWallet): void {
  try {
    wallet.updatedAt = new Date().toISOString();
    localStorage.setItem(WALLET_STORAGE_KEY, JSON.stringify(wallet));
    notifyQuotaChanged(wallet);
  } catch (err) {
    console.warn('Quota wallet save notice:', err);
  }
}

export function getStoredLedger(): QuotaLedgerEntry[] {
  try {
    const raw = localStorage.getItem(LEDGER_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Quota ledger read notice:', err);
  }
  return [];
}

export function saveLedger(ledger: QuotaLedgerEntry[]): void {
  try {
    const trimmed = ledger.slice(-150);
    localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.warn('Quota ledger save notice:', err);
  }
}

function notifyQuotaChanged(wallet: UserTokenWallet): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent(QUOTA_EVENT_NAME, {
        detail: {
          balance: wallet.appTokenBalance,
          lifetimeUsed: wallet.lifetimeTokensUsed,
          dollarValue: tokensToUsd(wallet.appTokenBalance),
          isLowQuota: wallet.appTokenBalance < LOW_QUOTA_ALERT_THRESHOLD,
        },
      })
    );
  }
}

/**
 * Synchronizes authoritative wallet, ledger, and authenticated user from the backend database.
 */
export async function syncWalletFromServer(): Promise<{
  authenticated: boolean;
  user: AuthenticatedUser | null;
  wallet: UserTokenWallet;
  ledger: QuotaLedgerEntry[];
} | null> {
  if (typeof window === 'undefined') return null;
  try {
    const res = await fetch('/api/auth/me', {
      method: 'GET',
      headers: getAuthHeaders(),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.authenticated && data.user) {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
      notifyAuthChanged(data.user);
    } else {
      localStorage.removeItem(AUTH_USER_KEY);
      if (getStoredAuthToken()) {
        localStorage.removeItem(AUTH_TOKEN_KEY);
      }
      notifyAuthChanged(null);
    }
    if (Array.isArray(data.ledger)) {
      saveLedger(data.ledger);
    }
    if (data.wallet) {
      saveWallet(data.wallet);
    }
    return {
      authenticated: Boolean(data.authenticated),
      user: data.user || null,
      wallet: data.wallet || getStoredWallet(),
      ledger: data.ledger || getStoredLedger(),
    };
  } catch {
    return null;
  }
}

/**
 * Server-enforced top-up purchase ($8 = 20,000,000 tokens; $1 = 2,500,000 tokens).
 */
export async function creditUserQuotaAsync(
  userId: string,
  amountInDollars: number,
  paymentReference?: string,
  packageName?: string
): Promise<{
  success: boolean;
  tokensAdded: number;
  newBalance: number;
  newDollarValue: number;
  referralBonusTriggered?: boolean;
  authRequired?: boolean;
  error?: string;
}> {
  try {
    const res = await fetch('/api/quota/credit', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        userId,
        amountInDollars,
        paymentReference,
        packageName,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 || res.status === 403 || res.status === 503) {
      return {
        success: false,
        tokensAdded: 0,
        newBalance: getStoredWallet().appTokenBalance,
        newDollarValue: tokensToUsd(getStoredWallet().appTokenBalance),
        authRequired: true,
        error:
          data?.error ||
          'Sign in and verify your email address before purchasing or consuming tokens.',
      };
    }
    if (res.ok) {
      if (Array.isArray(data.ledger)) saveLedger(data.ledger);
      if (data.wallet) saveWallet(data.wallet);
      return {
        success: true,
        tokensAdded: data.tokensAdded,
        newBalance: data.newBalance,
        newDollarValue: data.newDollarValue,
        referralBonusTriggered: Boolean(data.referralBonusTriggered),
      };
    }
  } catch (err) {
    console.warn('Server credit fallback notice:', err);
  }
  return creditUserQuota(userId, amountInDollars, paymentReference, packageName);
}

export function creditUserQuota(
  userId: string,
  amountInDollars: number,
  paymentReference?: string,
  packageName?: string
): {
  success: boolean;
  tokensAdded: number;
  newBalance: number;
  newDollarValue: number;
  referralBonusTriggered?: boolean;
} {
  const wallet = getStoredWallet();
  const tokensToAdd = usdToTokens(amountInDollars);

  wallet.appTokenBalance += tokensToAdd;
  wallet.lifetimeTokensPurchased += tokensToAdd;
  wallet.lastTopupDate = new Date().toISOString();
  wallet.userId = userId || wallet.userId;

  let referralBonusTriggered = false;
  if (!wallet.hasMadeFirstQualifyingPurchase && amountInDollars >= REFERRAL_QUALIFYING_PURCHASE_USD) {
    wallet.hasMadeFirstQualifyingPurchase = true;
    referralBonusTriggered = true;
  }

  saveWallet(wallet);

  const ledger = getStoredLedger();
  const entry: QuotaLedgerEntry = {
    id: `topup-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    type: 'TOPUP',
    workflowName: packageName || `Top-up ($${amountInDollars.toFixed(2)})`,
    tokensDelta: tokensToAdd,
    balanceAfter: wallet.appTokenBalance,
    dollarEquivalent: amountInDollars,
    metadata: {
      paymentReference: paymentReference || `ref_${Date.now()}`,
      provider: 'Secure Token Checkout',
      referralCode: wallet.referredBy,
    },
  };
  saveLedger([...ledger, entry]);

  return {
    success: true,
    tokensAdded: tokensToAdd,
    newBalance: wallet.appTokenBalance,
    newDollarValue: tokensToUsd(wallet.appTokenBalance),
    referralBonusTriggered,
  };
}

export function getUserReferralLink(customCode?: string): string {
  if (typeof window === 'undefined') return `?ref=${customCode || 'OMNI-DEMO'}`;
  const wallet = getStoredWallet();
  const code = customCode || wallet.referralCode;
  const origin = window.location.origin;
  const pathname = window.location.pathname;
  return `${origin}${pathname}?ref=${encodeURIComponent(code)}`;
}

export function detectAndRegisterReferralInUrl(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get('ref') || params.get('referral');
    if (!refCode) return null;

    const wallet = getStoredWallet();
    if (wallet.referralCode.toUpperCase() === refCode.toUpperCase()) {
      return null;
    }

    if (!wallet.referredBy) {
      wallet.referredBy = refCode.toUpperCase();
      saveWallet(wallet);

      fetch('/api/referrals/visit', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          referralCode: refCode.toUpperCase(),
          friendUserId: wallet.userId,
        }),
      }).catch(() => {});
    }

    return refCode.toUpperCase();
  } catch (err) {
    console.warn('Referral param detect error:', err);
    return null;
  }
}

export async function rewardReferralBonusAsync(
  friendNameOrId?: string
): Promise<{ success: boolean; bonusTokens: number; newBalance: number }> {
  const wallet = getStoredWallet();
  try {
    const res = await fetch('/api/referrals/reward', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        referrerCode: wallet.referralCode,
        friendUserId: friendNameOrId || 'Invited Friend',
        qualifyingAmountUsd: 8,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.ledger)) saveLedger(data.ledger);
      if (data.wallet) saveWallet(data.wallet);
      const updatedBal = data.wallet?.appTokenBalance ?? wallet.appTokenBalance;
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent(REFERRAL_EVENT_NAME, {
            detail: {
              bonusTokens: REFERRAL_BONUS_TOKENS,
              friend: friendNameOrId || 'Your invited friend',
              newBalance: updatedBal,
            },
          })
        );
      }
      return {
        success: true,
        bonusTokens: REFERRAL_BONUS_TOKENS,
        newBalance: updatedBal,
      };
    }
  } catch {}
  return rewardReferralBonus(friendNameOrId);
}

export function rewardReferralBonus(
  friendNameOrId?: string
): { success: boolean; bonusTokens: number; newBalance: number } {
  const wallet = getStoredWallet();

  wallet.appTokenBalance += REFERRAL_BONUS_TOKENS;
  wallet.referralConversionsCount += 1;
  wallet.referralTokensEarned += REFERRAL_BONUS_TOKENS;
  saveWallet(wallet);

  const ledger = getStoredLedger();
  const entry: QuotaLedgerEntry = {
    id: `ref-bonus-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    type: 'REFERRAL_BONUS',
    workflowName: '5M Token Referral Reward (Friend Bought $8 Pack)',
    tokensDelta: REFERRAL_BONUS_TOKENS,
    balanceAfter: wallet.appTokenBalance,
    dollarEquivalent: tokensToUsd(REFERRAL_BONUS_TOKENS),
    metadata: {
      provider: 'OmniAgent Referral Program',
      referredUser: friendNameOrId || 'Invited Friend',
    },
  };
  saveLedger([...ledger, entry]);

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent(REFERRAL_EVENT_NAME, {
        detail: {
          bonusTokens: REFERRAL_BONUS_TOKENS,
          friend: friendNameOrId || 'Your invited friend',
          newBalance: wallet.appTokenBalance,
        },
      })
    );
  }

  return {
    success: true,
    bonusTokens: REFERRAL_BONUS_TOKENS,
    newBalance: wallet.appTokenBalance,
  };
}

export function subscribeToReferralRewards(
  callback: (data: { bonusTokens: number; friend: string; newBalance: number }) => void
): () => void {
  const handler = (e: any) => {
    if (e.detail) callback(e.detail);
  };
  if (typeof window !== 'undefined') {
    window.addEventListener(REFERRAL_EVENT_NAME, handler);
  }
  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(REFERRAL_EVENT_NAME, handler);
    }
  };
}

/**
 * Authoritative Server-Side Pre-Flight Gate (prevents client-side localStorage balance spoofing).
 */
export async function checkServerPreflightQuota(
  prompt: string,
  requiredTokens: number = PROMPT_PLANNING_TOKEN_COST
): Promise<{
  allowed: boolean;
  estimatedTokens: number;
  currentBalance: number;
  shortageTokens: number;
  shortageUsd: number;
  authRequired?: boolean;
  requiresVerification?: boolean;
  error?: string;
}> {
  const safeRequired = Math.max(1, Math.round(requiredTokens || PROMPT_PLANNING_TOKEN_COST));
  try {
    const res = await fetch('/api/quota/preflight', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ prompt, estimatedBuffer: safeRequired, requiredTokens: safeRequired }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 || res.status === 403 || res.status === 503) {
      return {
        allowed: false,
        estimatedTokens: safeRequired,
        currentBalance: getStoredWallet().appTokenBalance,
        shortageTokens: 0,
        shortageUsd: 0,
        authRequired: true,
        requiresVerification: Boolean(data?.requiresVerification || res.status === 403),
        error:
          data?.error ||
          'Authentication & email verification required before consuming tokens.',
      };
    }
    if (res.ok) {
      if (data.wallet) {
        saveWallet(data.wallet);
      }
      return {
        allowed: Boolean(data.allowed),
        estimatedTokens: Number(data.estimatedTokens) || safeRequired,
        currentBalance: Number(data.currentBalance) || 0,
        shortageTokens: Number(data.shortageTokens) || 0,
        shortageUsd: Number(data.shortageUsd) || 0,
      };
    }
  } catch (err) {
    console.warn('Server preflight check unreachable, using cached wallet:', err);
  }
  return checkPreflightQuota(prompt, safeRequired);
}

export function checkPreflightQuota(
  _prompt: string,
  requiredTokens: number = PROMPT_PLANNING_TOKEN_COST
): {
  allowed: boolean;
  estimatedTokens: number;
  currentBalance: number;
  shortageTokens: number;
  shortageUsd: number;
} {
  const wallet = getStoredWallet();
  const estimatedTokens = Math.max(1, Math.round(requiredTokens || PROMPT_PLANNING_TOKEN_COST));

  const allowed = wallet.appTokenBalance >= estimatedTokens && wallet.appTokenBalance > 0;
  const shortageTokens = allowed ? 0 : Math.max(0, estimatedTokens - wallet.appTokenBalance);

  return {
    allowed,
    estimatedTokens,
    currentBalance: wallet.appTokenBalance,
    shortageTokens,
    shortageUsd: tokensToUsd(shortageTokens),
  };
}

/**
 * Authoritative Server-Side Quota Deduction (persists ledger in Supabase / ./data/omniagent_db.json).
 */
export async function deductServerQuota(
  workflowName: string,
  rawTokenCount: number,
  promptSnippet?: string,
  stepsCount?: number,
  requireFullAmount: boolean = false
): Promise<{
  success: boolean;
  tokensDeducted: number;
  remainingBalance: number;
  dollarDeducted: number;
  authRequired?: boolean;
  error?: string;
}> {
  const tokensToDeduct = Math.max(
    1,
    Math.round(rawTokenCount * AUTOMATION_MARKUP_MULTIPLIER)
  );
  try {
    const res = await fetch('/api/quota/deduct', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        workflowName,
        tokenCount: tokensToDeduct,
        promptSnippet,
        stepsCount,
        requireFullAmount,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 || res.status === 403 || res.status === 503) {
      return {
        success: false,
        tokensDeducted: 0,
        remainingBalance: getStoredWallet().appTokenBalance,
        dollarDeducted: 0,
        authRequired: true,
        error: data?.error || 'Verified session required.',
      };
    }
    if (Array.isArray(data.ledger)) saveLedger(data.ledger);
    if (data.wallet) saveWallet(data.wallet);
    if (res.ok && data.success) {
      return {
        success: true,
        tokensDeducted: data.tokensDeducted,
        remainingBalance: data.remainingBalance,
        dollarDeducted: data.dollarDeducted,
      };
    }
    if (res.status === 402) {
      return {
        success: false,
        tokensDeducted: 0,
        remainingBalance: data.remainingBalance || 0,
        dollarDeducted: 0,
        error: data?.error || 'Insufficient token quota.',
      };
    }
  } catch (err) {
    console.warn('Server quota deduction fallback notice:', err);
  }
  return deductAutomationQuota(workflowName, tokensToDeduct, promptSnippet, stepsCount, requireFullAmount);
}

export function deductAutomationQuota(
  workflowName: string,
  rawTokenCount: number,
  promptSnippet?: string,
  stepsCount?: number,
  requireFullAmount: boolean = false
): {
  success: boolean;
  tokensDeducted: number;
  remainingBalance: number;
  dollarDeducted: number;
} {
  const wallet = getStoredWallet();
  const tokensToDeduct = Math.max(
    1,
    Math.round(rawTokenCount * AUTOMATION_MARKUP_MULTIPLIER)
  );

  if (wallet.appTokenBalance <= 0 || (requireFullAmount && wallet.appTokenBalance < tokensToDeduct)) {
    return {
      success: false,
      tokensDeducted: 0,
      remainingBalance: wallet.appTokenBalance,
      dollarDeducted: 0,
    };
  }

  const previousBalance = wallet.appTokenBalance;
  const actualDeducted = Math.min(previousBalance, tokensToDeduct);
  wallet.appTokenBalance = Math.max(0, previousBalance - actualDeducted);
  wallet.lifetimeTokensUsed += actualDeducted;

  saveWallet(wallet);

  const ledger = getStoredLedger();
  const entry: QuotaLedgerEntry = {
    id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    type: 'AUTOMATION_RUN',
    workflowName: workflowName || 'Phone Automation Task',
    tokensDelta: -actualDeducted,
    balanceAfter: wallet.appTokenBalance,
    dollarEquivalent: tokensToUsd(actualDeducted),
    metadata: {
      promptSnippet: promptSnippet ? promptSnippet.slice(0, 70) : undefined,
      stepsCount,
      provider: 'OmniAgent Server Quota Ledger',
    },
  };
  saveLedger([...ledger, entry]);

  return {
    success: true,
    tokensDeducted: actualDeducted,
    remainingBalance: wallet.appTokenBalance,
    dollarDeducted: tokensToUsd(actualDeducted),
  };
}

export function subscribeToQuotaChanges(callback: (wallet: UserTokenWallet) => void): () => void {
  const handler = () => {
    callback(getStoredWallet());
  };
  if (typeof window !== 'undefined') {
    window.addEventListener(QUOTA_EVENT_NAME, handler);
  }
  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener(QUOTA_EVENT_NAME, handler);
    }
  };
}
