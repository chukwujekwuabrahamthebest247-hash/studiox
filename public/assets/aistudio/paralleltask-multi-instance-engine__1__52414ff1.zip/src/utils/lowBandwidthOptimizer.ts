/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BandwidthMode = 'ultra_low_2g' | 'low_data' | 'optimized_4g' | 'uncompressed_5g';

export interface BandwidthSettings {
  mode: BandwidthMode;
  label: string;
  compressionRatio: number;
  frameRateLimit: number;
}
