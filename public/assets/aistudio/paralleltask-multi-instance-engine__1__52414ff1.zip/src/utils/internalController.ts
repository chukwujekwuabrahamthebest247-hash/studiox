/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep, InternalAutomationState } from '../types/phone';

export function createInitialInternalState(): InternalAutomationState {
  return {
    currentInstructionPointer: 0,
    callStack: [],
    domResolverTrace: {
      selectorQueried: null,
      matchesFound: 0,
      activeElementNode: null,
      resolutionState: 'idle',
    },
    memoryStoreDump: {
      app: 'home',
      cartCount: 0,
      cartSubtotal: 0,
      activeMessageThread: null,
      messageDraftBuffer: '',
      unreadTotal: 0,
      notesCount: 2,
      noteDraftTitle: '',
      darkMode: true,
      wifi: true,
      bluetooth: true,
      lowPower: false,
      searchQuery: '',
      browserQuery: '',
    },
    eventDispatcher: {
      queueLength: 0,
      dispatchedEventsCount: 0,
      droppedEventsCount: 0,
      lastEventDispatched: 'SYSTEM_READY',
    },
    internalInterventions: [],
  };
}

export function buildCallStackFrame(step: AgentStep, index: number, stage: string) {
  return {
    frameId: `frame-${Date.now()}-${index}`,
    instructionPointer: index,
    action: step.action,
    target: step.targetName || step.targetApp || 'viewport',
    stage,
    timestamp: new Date().toLocaleTimeString(),
  };
}

export function traceDOMResolution(targetName: string | undefined, container: HTMLElement | null) {
  if (!targetName) {
    return {
      selectorQueried: 'viewport:root',
      matchesFound: 1,
      activeElementNode: 'div#root',
      resolutionState: 'resolved',
    };
  }

  const selector = `[data-agent-target*="${targetName.toLowerCase()}"]`;
  const el = container?.querySelector(selector);

  return {
    selectorQueried: selector,
    matchesFound: el ? 1 : 0,
    activeElementNode: el ? el.tagName.toLowerCase() : 'null',
    resolutionState: el ? 'resolved' : 'searching',
  };
}

export function evaluateInternalEngineHealth(
  state: InternalAutomationState,
  currentStep: AgentStep
): {
  isHealthy: boolean;
  reason?: string;
  recommendedInternalTool?: { tool: string; params: any };
} {
  if (state.eventDispatcher.droppedEventsCount > 0) {
    return {
      isHealthy: false,
      reason: 'Detected dropped actuator events in internal dispatcher queue.',
      recommendedInternalTool: {
        tool: 'tool_internal_force_sync',
        params: { reason: 'Flushing stale message queue' },
      },
    };
  }

  return { isHealthy: true };
}
