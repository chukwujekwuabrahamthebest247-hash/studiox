/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PublicWorkflowTemplate, PublishWorkflowRequest } from '../types/workflowShare';

const WORKFLOWS_STORAGE_KEY = 'omniagent_public_workflow_templates';
const WORKFLOW_EVENT_KEY = 'omniagent_workflows_updated';

// Default featured community templates available immediately
export const DEFAULT_PUBLIC_WORKFLOWS: PublicWorkflowTemplate[] = [
  {
    id: 'wf-lead-scraper-pro',
    slug: 'copy-my-automated-lead-scraper',
    title: 'Automated Lead Scraper',
    description: 'Searches the web for high-growth tech startups, extracts executive founder contacts, and securely compiles them into a structured Notes lead sheet.',
    prompt: 'Open SearchGlobe browser, search for top AI startups in San Francisco, extract founder contact details and save into a note titled "AI Startup Leads".',
    targetApp: 'browser',
    author: 'Abraham (Platform Creator)',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    runCount: 248,
    cloneCount: 97,
    estimatedTokens: 950,
    estimatedSeconds: 6,
    tags: ['Leads', 'Scraper', 'Sales', 'Productivity'],
    isFeatured: true,
  },
  {
    id: 'wf-social-growth',
    slug: 'viral-social-media-growth-autopilot',
    title: 'Viral Social Media Auto-Poster',
    description: 'Composes an authoritative technology market prediction, embeds high-converting hashtags, and broadcasts it automatically on the Social Network feed.',
    prompt: 'Open Social app, create a new trending post about autonomous AI screen agents with hashtag #TechTrends2026, and publish.',
    targetApp: 'social',
    author: 'Elena Rostova',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    runCount: 182,
    cloneCount: 64,
    estimatedTokens: 720,
    estimatedSeconds: 5,
    tags: ['Social', 'Marketing', 'Audience Growth'],
    isFeatured: true,
  },
  {
    id: 'wf-food-deal-hunter',
    slug: 'food-delivery-budget-basket-optimizer',
    title: 'Food Delivery Value Basket Hunter',
    description: 'Navigates food marketplace, compares signature meals under $25, and prepares an optimized lunch order ready for checkout.',
    prompt: 'Open Food Delivery app, find popular artisan dishes, add 2 items under $25 to cart and proceed to review.',
    targetApp: 'food',
    author: 'Marcus Chen',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    runCount: 135,
    cloneCount: 52,
    estimatedTokens: 680,
    estimatedSeconds: 5,
    tags: ['E-Commerce', 'Shopping', 'Lifestyle'],
    isFeatured: false,
  },
  {
    id: 'wf-support-responder',
    slug: 'inbox-zero-rapid-responder',
    title: 'Executive Inbox Rapid Responder',
    description: 'Scans messaging channels for pending partner requests, synthesizes communication context, and drafts a professional confirmation reply.',
    prompt: 'Open Messages app, read unread conversation from Sarah Chen, and draft a response confirming project roadmap.',
    targetApp: 'messages',
    author: 'DevOps Lead',
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    runCount: 312,
    cloneCount: 118,
    estimatedTokens: 820,
    estimatedSeconds: 4,
    tags: ['Messaging', 'Executive', 'Communication'],
    isFeatured: true,
  },
  {
    id: 'wf-darkmode-optimizer',
    slug: 'device-power-dark-mode-optimizer',
    title: 'System Dark Mode & Battery Optimizer',
    description: 'Fine-tunes Android/iOS device power settings, activates system-wide dark palette, and maximizes operating responsiveness.',
    prompt: 'Open Settings app, toggle Dark Mode on, and verify settings updated.',
    targetApp: 'settings',
    author: 'System Admin',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    runCount: 420,
    cloneCount: 204,
    estimatedTokens: 450,
    estimatedSeconds: 3,
    tags: ['System', 'OS Settings', 'Speed'],
    isFeatured: false,
  },
];

export function getStoredWorkflows(): PublicWorkflowTemplate[] {
  try {
    const raw = localStorage.getItem(WORKFLOWS_STORAGE_KEY);
    if (raw) {
      const parsed: PublicWorkflowTemplate[] = JSON.parse(raw);
      // Merge defaults with custom published workflows ensuring no duplicates
      const merged = [...DEFAULT_PUBLIC_WORKFLOWS];
      for (const item of parsed) {
        if (!merged.some((m) => m.id === item.id)) {
          merged.push(item);
        }
      }
      return merged;
    }
  } catch (e) {
    console.warn('Error reading workflow templates:', e);
  }

  saveWorkflows(DEFAULT_PUBLIC_WORKFLOWS);
  return DEFAULT_PUBLIC_WORKFLOWS;
}

export function saveWorkflows(workflows: PublicWorkflowTemplate[]): void {
  try {
    localStorage.setItem(WORKFLOWS_STORAGE_KEY, JSON.stringify(workflows));
    notifyWorkflowsChanged();
  } catch (e) {
    console.warn('Error saving workflow templates:', e);
  }
}

function notifyWorkflowsChanged(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(WORKFLOW_EVENT_KEY));
  }
}

export function subscribeToWorkflows(callback: () => void): () => void {
  if (typeof window !== 'undefined') {
    window.addEventListener(WORKFLOW_EVENT_KEY, callback);
    return () => window.removeEventListener(WORKFLOW_EVENT_KEY, callback);
  }
  return () => {};
}

/**
 * Publishes a new workflow template and returns the public template object with shareable link
 */
export function publishWorkflow(req: PublishWorkflowRequest): PublicWorkflowTemplate {
  const all = getStoredWorkflows();

  const slug = req.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || `workflow-${Date.now()}`;

  const estimatedTokens = Math.max(300, Math.ceil(req.prompt.length / 4) + 250);

  const newWorkflow: PublicWorkflowTemplate = {
    id: `wf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    slug,
    title: req.title.trim(),
    description: req.description.trim() || `Automated workflow for ${req.targetApp || 'installed apps'}`,
    prompt: req.prompt.trim(),
    targetApp: req.targetApp || 'all',
    author: req.authorName?.trim() || 'Community Creator',
    createdAt: new Date().toISOString(),
    runCount: 1,
    cloneCount: 0,
    estimatedTokens,
    estimatedSeconds: Math.max(3, Math.ceil(estimatedTokens / 200)),
    tags: req.tags && req.tags.length > 0 ? req.tags : ['Automation', 'Public Template'],
    isFeatured: false,
  };

  const updated = [newWorkflow, ...all];
  saveWorkflows(updated);

  // Sync with server API in background
  try {
    fetch('/api/workflows/share', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newWorkflow),
    }).catch(() => {});
  } catch {}

  return newWorkflow;
}

/**
 * Increments run counter when a user runs a shared workflow
 */
export function recordWorkflowRun(workflowId: string): void {
  const all = getStoredWorkflows();
  const updated = all.map((wf) => {
    if (wf.id === workflowId || wf.slug === workflowId) {
      return { ...wf, runCount: wf.runCount + 1 };
    }
    return wf;
  });
  saveWorkflows(updated);
}

/**
 * Increments clone counter when a user copies or bookmarks a shared workflow
 */
export function recordWorkflowClone(workflowId: string): void {
  const all = getStoredWorkflows();
  const updated = all.map((wf) => {
    if (wf.id === workflowId || wf.slug === workflowId) {
      return { ...wf, cloneCount: wf.cloneCount + 1 };
    }
    return wf;
  });
  saveWorkflows(updated);
}

/**
 * Builds the canonical 1-click shareable public link
 */
export function getWorkflowShareUrl(workflow: PublicWorkflowTemplate): string {
  if (typeof window === 'undefined') return `?workflow=${workflow.slug}`;
  const origin = window.location.origin;
  const pathname = window.location.pathname;
  return `${origin}${pathname}?workflow=${encodeURIComponent(workflow.slug)}`;
}

/**
 * Extracts shared workflow from the current page URL query parameters
 */
export function detectSharedWorkflowInUrl(): PublicWorkflowTemplate | null {
  if (typeof window === 'undefined') return null;
  try {
    const params = new URLSearchParams(window.location.search);
    const identifier = params.get('workflow') || params.get('template') || params.get('wf');
    if (!identifier) return null;

    const all = getStoredWorkflows();
    const match = all.find(
      (w) => w.slug.toLowerCase() === identifier.toLowerCase() || w.id.toLowerCase() === identifier.toLowerCase()
    );

    if (match) return match;

    // Check if encoded workflow json in query param
    const encodedData = params.get('data');
    if (encodedData) {
      try {
        const decoded = JSON.parse(decodeURIComponent(atob(encodedData)));
        if (decoded.prompt && decoded.title) {
          return {
            id: `wf-imported-${Date.now()}`,
            slug: 'shared-custom-workflow',
            title: decoded.title,
            description: decoded.description || 'Imported shared workflow',
            prompt: decoded.prompt,
            targetApp: decoded.targetApp || 'all',
            author: decoded.author || 'Anonymous Creator',
            createdAt: new Date().toISOString(),
            runCount: 1,
            cloneCount: 1,
            estimatedTokens: Math.max(300, Math.ceil(decoded.prompt.length / 4)),
            estimatedSeconds: 5,
            tags: ['Shared Link'],
          };
        }
      } catch {}
    }
  } catch (err) {
    console.warn('Error reading workflow URL param:', err);
  }
  return null;
}
