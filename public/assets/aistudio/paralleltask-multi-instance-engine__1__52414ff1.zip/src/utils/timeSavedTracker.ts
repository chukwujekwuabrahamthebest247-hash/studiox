/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep } from '../types/phone';

export interface TimeSavedMetrics {
  monthlySecondsSaved: number;
  totalTasksCompleted: number;
  totalTapsAutomated: number;
  lastCalculated: string;
  monthKey: string;
}

const STORAGE_KEY_PREFIX = 'omniagent_time_saved_';

export function getCurrentMonthKey(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

function getStorageKey(monthKey: string): string {
  return `${STORAGE_KEY_PREFIX}${monthKey}`;
}

function createZeroMetrics(monthKey: string = getCurrentMonthKey()): TimeSavedMetrics {
  return {
    monthlySecondsSaved: 0,
    totalTasksCompleted: 0,
    totalTapsAutomated: 0,
    lastCalculated: new Date().toLocaleDateString(),
    monthKey,
  };
}

function loadMetricsForCurrentMonth(): TimeSavedMetrics {
  const monthKey = getCurrentMonthKey();
  if (typeof window === 'undefined') {
    return createZeroMetrics(monthKey);
  }

  try {
    const raw = localStorage.getItem(getStorageKey(monthKey));
    if (!raw) {
      return createZeroMetrics(monthKey);
    }
    const parsed = JSON.parse(raw);
    return {
      monthlySecondsSaved:
        typeof parsed.monthlySecondsSaved === 'number' && parsed.monthlySecondsSaved >= 0
          ? parsed.monthlySecondsSaved
          : 0,
      totalTasksCompleted:
        typeof parsed.totalTasksCompleted === 'number' && parsed.totalTasksCompleted >= 0
          ? parsed.totalTasksCompleted
          : 0,
      totalTapsAutomated:
        typeof parsed.totalTapsAutomated === 'number' && parsed.totalTapsAutomated >= 0
          ? parsed.totalTapsAutomated
          : 0,
      lastCalculated:
        typeof parsed.lastCalculated === 'string'
          ? parsed.lastCalculated
          : new Date().toLocaleDateString(),
      monthKey,
    };
  } catch {
    return createZeroMetrics(monthKey);
  }
}

function persistMetrics(metrics: TimeSavedMetrics): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(getStorageKey(metrics.monthKey), JSON.stringify(metrics));
  } catch {}
}

let currentMetrics: TimeSavedMetrics = loadMetricsForCurrentMonth();
const listeners = new Set<(metrics: TimeSavedMetrics) => void>();

/**
 * Calculates accurate human manual time (in seconds) & manual taps replaced
 * by summing per-step effort for each AgentStep executed.
 */
export function calculateStepManualEquivalent(step: AgentStep): {
  seconds: number;
  taps: number;
} {
  switch (step.action) {
    case 'type_text': {
      const charCount = (step.value || '').trim().length;
      // Locating input field + tapping to focus + thumb-typing ~2.5 chars/sec
      const typingSeconds = Math.max(4, Math.ceil(charCount * 0.4) + 3);
      return { seconds: typingSeconds, taps: 1 };
    }
    case 'navigate_app':
      // Locating app icon across pages/folders, tapping, waiting for launch
      return { seconds: 6, taps: 1 };
    case 'go_home':
      // Swiping up / pressing home button
      return { seconds: 3, taps: 1 };
    case 'swipe_up':
    case 'swipe_down':
      // Manual thumb scroll & visual scanning of list items
      return { seconds: 4, taps: 1 };
    case 'tap':
      // Visual scan + targeting UI control + tap response
      return { seconds: 5, taps: 1 };
    case 'biometric_auth':
      // Aligning face/finger on biometric prompt
      return { seconds: 4, taps: 1 };
    case 'guardrail_approval':
      // Reading high-risk confirmation prompt & tapping authorize
      return { seconds: 6, taps: 1 };
    case 'wait':
      return {
        seconds: Math.min(5, Math.max(0, Math.round((step.duration || 0) / 1000))),
        taps: 0,
      };
    default:
      return { seconds: 4, taps: 1 };
  }
}

export function getTimeSavedMetrics(): TimeSavedMetrics {
  const activeMonthKey = getCurrentMonthKey();
  if (currentMetrics.monthKey !== activeMonthKey) {
    currentMetrics = loadMetricsForCurrentMonth();
  }
  return { ...currentMetrics };
}

export function subscribeToTimeSavedMetrics(
  cb: (metrics: TimeSavedMetrics) => void
): () => void {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function recordAutomationTask(params: {
  taskTitle: string;
  app: string;
  steps?: AgentStep[];
  stepsCount: number;
  speedMultiplier: number;
}): TimeSavedMetrics {
  const activeMonthKey = getCurrentMonthKey();
  if (currentMetrics.monthKey !== activeMonthKey) {
    currentMetrics = loadMetricsForCurrentMonth();
  }

  let secondsSaved = 0;
  let tapsAutomated = 0;

  if (Array.isArray(params.steps) && params.steps.length > 0) {
    for (const step of params.steps) {
      const est = calculateStepManualEquivalent(step);
      secondsSaved += est.seconds;
      tapsAutomated += est.taps;
    }
  } else if (params.stepsCount > 0) {
    secondsSaved = params.stepsCount * 5;
    tapsAutomated = params.stepsCount;
  }

  currentMetrics = {
    monthlySecondsSaved: currentMetrics.monthlySecondsSaved + secondsSaved,
    totalTasksCompleted: currentMetrics.totalTasksCompleted + 1,
    totalTapsAutomated: currentMetrics.totalTapsAutomated + tapsAutomated,
    lastCalculated: new Date().toLocaleDateString(),
    monthKey: activeMonthKey,
  };

  persistMetrics(currentMetrics);
  listeners.forEach((cb) => cb({ ...currentMetrics }));
  return { ...currentMetrics };
}

export function formatHoursSaved(seconds: number): string {
  const hours = Math.max(0, seconds) / 3600;
  return hours.toFixed(1);
}
