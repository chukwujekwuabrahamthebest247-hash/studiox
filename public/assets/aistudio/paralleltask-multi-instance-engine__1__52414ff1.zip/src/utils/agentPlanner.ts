/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AgentStep, PhoneAppType } from '../types/phone';

export function extractCleanSearchQuery(text: string): string {
  if (!text) return '';
  let clean = text.trim();
  clean = clean.replace(/^(search\s+for|search|google|find|look\s+up|browse|navigate\s+to)\s+/i, '');
  clean = clean.replace(/["']/g, '');
  return clean.trim();
}

export function extractOrdinalIndex(text: string): number | null {
  if (!text) return null;
  const lower = text.toLowerCase();
  if (lower.includes('first') || lower.includes('1st')) return 0;
  if (lower.includes('second') || lower.includes('2nd')) return 1;
  if (lower.includes('third') || lower.includes('3rd')) return 2;
  if (lower.includes('fourth') || lower.includes('4th')) return 3;
  if (lower.includes('fifth') || lower.includes('5th')) return 4;
  const match = lower.match(/(?:result|item|link|position)\s*#?\s*([1-9])/);
  if (match && match[1]) {
    return parseInt(match[1], 10) - 1;
  }
  return null;
}

export function isOrdinalSearchResultIntent(text: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase();
  const hasAction =
    lower.includes('tap') ||
    lower.includes('click') ||
    lower.includes('open') ||
    lower.includes('select') ||
    lower.includes('choose');
  const hasTarget =
    lower.includes('result') ||
    lower.includes('article') ||
    lower.includes('link') ||
    lower.includes('first') ||
    lower.includes('1st') ||
    lower.includes('second') ||
    lower.includes('2nd') ||
    lower.includes('third') ||
    lower.includes('3rd') ||
    lower.includes('fourth') ||
    lower.includes('4th');

  return hasAction && hasTarget;
}

export function checkDisallowedAppRequest(prompt: string): { isDisallowed: boolean; appName?: string; reason?: string } {
  const lower = prompt.toLowerCase();
  const disallowed = ['jailbreak', 'torrent', 'pirate', 'root device', 'bypass security', 'sideload'];
  for (const item of disallowed) {
    if (lower.includes(item)) {
      return {
        isDisallowed: true,
        appName: item,
        reason: `Action involving "${item}" is restricted under enterprise compliance & zero-fear safety profile.`,
      };
    }
  }
  return { isDisallowed: false };
}

export function requiresCryptoGuardrail(prompt: string): {
  isCrypto: boolean;
  isSensitive: boolean;
  walletName: string;
  actionType?: string;
} {
  const lower = prompt.toLowerCase();

  let walletName = 'Crypto Wallet';
  if (lower.includes('metamask')) walletName = 'MetaMask';
  else if (lower.includes('binance')) walletName = 'Binance';
  else if (lower.includes('coinbase')) walletName = 'Coinbase Wallet';
  else if (lower.includes('trust wallet')) walletName = 'Trust Wallet';
  else if (lower.includes('phantom')) walletName = 'Phantom';
  else if (lower.includes('ledger')) walletName = 'Ledger Live';
  else if (lower.includes('uniswap')) walletName = 'Uniswap';

  const cryptoKeywords = [
    'crypto',
    'wallet',
    'metamask',
    'binance',
    'coinbase',
    'trust wallet',
    'phantom',
    'ledger',
    'uniswap',
    'cryptowallet',
    'bitcoin',
    'btc',
    'ethereum',
    'eth',
    'solana',
    'sol',
    'usdt',
    'usdc',
    'web3',
  ];

  const isCrypto = cryptoKeywords.some((kw) => lower.includes(kw));
  if (!isCrypto) {
    return { isCrypto: false, isSensitive: false, walletName };
  }

  let actionType: string | undefined;
  if (lower.includes('export') && (lower.includes('key') || lower.includes('seed') || lower.includes('phrase'))) {
    actionType = 'Export Private Key / Seed';
  } else if (lower.includes('seed phrase') || lower.includes('private key') || lower.includes('recovery phrase')) {
    actionType = 'Reveal Private Key / Seed';
  } else if (lower.includes('withdraw')) {
    actionType = 'Withdraw Crypto Funds';
  } else if (lower.includes('transfer')) {
    actionType = 'Transfer Crypto Assets';
  } else if (lower.includes('swap') || lower.includes('trade')) {
    actionType = 'Swap Tokens';
  } else if (lower.includes('send')) {
    actionType = 'Send Crypto Transaction';
  } else if (lower.includes('export')) {
    actionType = 'Export Wallet Keys';
  }

  return {
    isCrypto: true,
    isSensitive: Boolean(actionType),
    walletName,
    actionType,
  };
}

export function generateLocalPlan(
  prompt: string,
  currentApp: PhoneAppType,
  context?: any
): {
  replyMessage: string;
  reasoning: string;
  steps: AgentStep[];
  thinkingOutsideTheBox?: { creativeStrategy: string };
  appliedKnowledge?: string;
} {
  const pLower = prompt.trim().toLowerCase();

  // 1. PURE APP LAUNCH / NAVIGATION (Do strictly that and STOP!)
  // If the user simply asks to open/view an app without requesting a sub-action inside it:
  const isExplicitLaunch =
    pLower.startsWith('open ') ||
    pLower.startsWith('launch ') ||
    pLower.startsWith('go to ') ||
    pLower.startsWith('switch to ') ||
    pLower.startsWith('navigate to ') ||
    pLower.startsWith('start ') ||
    pLower.startsWith('show me ') ||
    pLower === 'messages' ||
    pLower === 'notes' ||
    pLower === 'settings' ||
    pLower === 'browser' ||
    pLower === 'social' ||
    pLower === 'bitedash' ||
    pLower === 'food' ||
    pLower === 'banking' ||
    pLower === 'home';

  const hasSubAction =
    pLower.includes(' and ') ||
    pLower.includes(' then ') ||
    pLower.includes('search') ||
    pLower.includes('like') ||
    pLower.includes('swipe') ||
    pLower.includes('scroll') ||
    pLower.includes('order') ||
    pLower.includes('buy') ||
    pLower.includes('add') ||
    pLower.includes('send') ||
    pLower.includes('transfer') ||
    pLower.includes('swap') ||
    pLower.includes('withdraw') ||
    pLower.includes('text') ||
    pLower.includes('write') ||
    pLower.includes('compose') ||
    pLower.includes('dark') ||
    pLower.includes('wifi') ||
    pLower.includes('bluetooth') ||
    pLower.includes('export') ||
    pLower.includes('flag') ||
    pLower.includes('cart') ||
    pLower.includes('balance') ||
    pLower.includes('price');

  const cryptoCheck = requiresCryptoGuardrail(prompt);

  if (isExplicitLaunch && !hasSubAction) {
    let targetApp: PhoneAppType | null = null;
    let appLabel = '';

    if (pLower.includes('tiktok')) {
      targetApp = 'tiktok';
      appLabel = 'TikTok';
    } else if (pLower.includes('tinder')) {
      targetApp = 'tinder';
      appLabel = 'Tinder';
    } else if (cryptoCheck.isCrypto) {
      targetApp = 'cryptowallet';
      appLabel = cryptoCheck.walletName;
    } else if (pLower.includes('food') || pLower.includes('bitedash') || pLower.includes('restaurant')) {
      targetApp = 'food';
      appLabel = 'BiteDash';
    } else if (pLower.includes('message') || pLower.includes('sms') || pLower.includes('chat')) {
      targetApp = 'messages';
      appLabel = 'Messages';
    } else if (pLower.includes('note') || pLower.includes('memo')) {
      targetApp = 'notes';
      appLabel = 'Notes';
    } else if (pLower.includes('social') || pLower.includes('pulse') || pLower.includes('feed')) {
      targetApp = 'social';
      appLabel = 'Pulse Social';
    } else if (pLower.includes('browser') || pLower.includes('web') || pLower.includes('safari') || pLower.includes('chrome') || pLower.includes('internet')) {
      targetApp = pLower.includes('chrome') ? 'chrome' : 'browser';
      appLabel = pLower.includes('chrome') ? 'Google Chrome' : 'Browser';
    } else if (pLower.includes('setting')) {
      targetApp = 'settings';
      appLabel = 'Settings';
    } else if (pLower.includes('bank') || pLower.includes('apex')) {
      targetApp = 'banking';
      appLabel = 'Apex Secure Bank';
    } else if (pLower.includes('quickbook')) {
      targetApp = 'quickbooks';
      appLabel = 'QuickBooks';
    } else if (pLower.includes('sheet') || pLower.includes('excel')) {
      targetApp = 'sheets';
      appLabel = 'Google Sheets';
    } else if (pLower.includes('home') || pLower.includes('springboard')) {
      return {
        replyMessage: 'Navigating to Home Screen.',
        reasoning: 'Navigating to home screen. Strictly doing what was requested with zero extra actions.',
        steps: [{ action: 'go_home', detail: 'Swipe up to Home Screen' }],
      };
    } else if (Array.isArray(context?.installedApps)) {
      const matchedInstalled = context.installedApps.find(
        (app: { id: string; name: string }) =>
          pLower.includes(app.name.toLowerCase()) || pLower.includes(app.id.toLowerCase())
      );
      if (matchedInstalled) {
        targetApp = matchedInstalled.id as PhoneAppType;
        appLabel = matchedInstalled.name;
      }
    }

    if (targetApp) {
      const steps: AgentStep[] = [];
      if (currentApp !== targetApp) {
        steps.push({
          action: 'navigate_app',
          targetApp,
          detail: `Open ${appLabel}`,
        });
      }
      return {
        replyMessage: `Opened ${appLabel}.`,
        reasoning: `User requested to open ${appLabel}. Executed navigation and stopped with zero unprompted extra actions.`,
        steps: steps.length > 0 ? steps : [{ action: 'wait', duration: 100, detail: `Already on ${appLabel}` }],
      };
    }
  }

  // 1B. TIKTOK PLANNING RULES (Navigation, liking, and scrolling)
  if (pLower.includes('tiktok')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'tiktok') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'tiktok',
        detail: 'Open TikTok',
      });
    }
    if (pLower.includes('like') || pLower.includes('heart')) {
      steps.push({
        action: 'tap',
        targetName: 'app-action-toggle',
        detail: 'Tap Like on current TikTok video',
      });
    }
    if (pLower.includes('scroll') || pLower.includes('swipe') || pLower.includes('next')) {
      steps.push({
        action: 'swipe_up',
        distance: 420,
        detail: 'Scroll TikTok For You feed',
      });
    }
    return {
      replyMessage:
        steps.length > 1
          ? 'Completed requested TikTok actions.'
          : 'Opened TikTok.',
      reasoning:
        'Executed exact user instructions inside TikTok (navigation, liking, or scrolling) with zero unprompted extra steps.',
      steps: steps.length > 0 ? steps : [{ action: 'wait', duration: 100, detail: 'Already on TikTok' }],
    };
  }

  // 1C. TINDER PLANNING RULES (Navigation, liking, and scrolling/swiping)
  if (pLower.includes('tinder')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'tinder') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'tinder',
        detail: 'Open Tinder',
      });
    }
    if (pLower.includes('like') || pLower.includes('heart') || pLower.includes('match')) {
      steps.push({
        action: 'tap',
        targetName: 'app-action-toggle',
        detail: 'Like profile card on Tinder',
      });
    }
    if (pLower.includes('scroll') || pLower.includes('swipe') || pLower.includes('next')) {
      steps.push({
        action: 'swipe_up',
        distance: 400,
        detail: 'Swipe / scroll Tinder discovery stack',
      });
    }
    return {
      replyMessage:
        steps.length > 1
          ? 'Completed requested Tinder actions.'
          : 'Opened Tinder.',
      reasoning:
        'Executed exact user instructions inside Tinder (navigation, liking, or scrolling) with zero unprompted extra steps.',
      steps: steps.length > 0 ? steps : [{ action: 'wait', duration: 100, detail: 'Already on Tinder' }],
    };
  }

  // 1D. CRYPTO WALLET PLANNING RULES + ZERO-FEAR GUARDRAILS
  if (cryptoCheck.isCrypto) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'cryptowallet') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'cryptowallet',
        detail: `Open ${cryptoCheck.walletName}`,
      });
    }

    if (cryptoCheck.isSensitive) {
      const amountMatch = prompt.match(/(\$?[\d,.]+\s*(?:btc|eth|sol|usdt|usdc|bnb|usd)?)/i);
      const amountLabel = amountMatch?.[1]?.trim() || 'Requested Asset Transfer';
      steps.push({
        action: 'biometric_auth',
        detail: `Verify FaceID / TouchID for ${cryptoCheck.walletName}`,
        requiresBiometric: true,
        biometricPrompt: `Biometric authorization required before executing ${cryptoCheck.actionType || 'sensitive wallet operation'} in ${cryptoCheck.walletName}.`,
      });
      steps.push({
        action: 'guardrail_approval',
        detail: `Approve ${cryptoCheck.actionType || 'Crypto Transaction'} (${amountLabel})`,
        requiresApproval: true,
        guardrailType: 'crypto_transaction',
        approvalDetail: `${cryptoCheck.walletName}: ${cryptoCheck.actionType || 'Transaction'} — ${amountLabel}`,
      });
      steps.push({
        action: 'tap',
        targetName: 'app-action-primary',
        detail: `Execute authorized ${cryptoCheck.actionType || 'wallet action'}`,
      });

      return {
        replyMessage: `Initiated protected ${cryptoCheck.walletName} workflow (${cryptoCheck.actionType}) with biometric & guardrail checkpoints.`,
        reasoning: `Sensitive crypto wallet operation (${cryptoCheck.actionType}) detected via requiresCryptoGuardrail(). Enforced biometric_auth + guardrail_approval before execution.`,
        steps,
      };
    }

    // Read-only balance / price / portfolio checks are allowed freely without guardrails
    if (pLower.includes('balance') || pLower.includes('price') || pLower.includes('check') || pLower.includes('portfolio')) {
      steps.push({
        action: 'tap',
        targetName: 'app-action-submit',
        detail: `View read-only ${cryptoCheck.walletName} balance & live prices`,
      });
    }

    return {
      replyMessage: `Opened ${cryptoCheck.walletName} for read-only check.`,
      reasoning: `Read-only crypto wallet inspection in ${cryptoCheck.walletName} permitted without transaction guardrails.`,
      steps: steps.length > 0 ? steps : [{ action: 'wait', duration: 100, detail: `Viewing ${cryptoCheck.walletName}` }],
    };
  }

  // 2. GO HOME (Strictly return to home screen)
  if (
    pLower === 'go home' ||
    pLower === 'home' ||
    pLower === 'home screen' ||
    pLower.includes('return to home') ||
    pLower.includes('swipe up to home') ||
    pLower.includes('exit app')
  ) {
    return {
      replyMessage: 'Navigating to Home Screen.',
      reasoning: 'Executing exact user request to return home.',
      steps: [{ action: 'go_home', detail: 'Return to Home Screen' }],
    };
  }

  // 3. BROWSER & WEB SEARCH (Strictly search and do not click results unless requested!)
  if (pLower.includes('search') || pLower.includes('browse') || pLower.includes('google') || pLower.includes('look up')) {
    const query = extractCleanSearchQuery(prompt) || 'AI Phone Agents & Automation';
    const steps: AgentStep[] = [];
    if (currentApp !== 'browser') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'browser',
        detail: 'Open Web Browser',
      });
    }
    steps.push({
      action: 'type_text',
      value: query,
      detail: `Enter web search query: "${query}"`,
    });

    // Check if user EXPLICITLY instructed clicking or opening a result
    const wantsResultClick =
      isOrdinalSearchResultIntent(prompt) ||
      pLower.includes('click the') ||
      pLower.includes('click on') ||
      pLower.includes('open result') ||
      pLower.includes('open the') ||
      pLower.includes('tap result') ||
      pLower.includes('tap on');

    if (wantsResultClick) {
      const targetIdx = extractOrdinalIndex(prompt) ?? 0;
      steps.push({
        action: 'tap',
        targetName: `browser-result-${targetIdx}`,
        detail: `Select search result article #${targetIdx + 1}`,
      });
    }

    return {
      replyMessage: wantsResultClick
        ? `Searching for "${query}" and opening result #${(extractOrdinalIndex(prompt) ?? 0) + 1}.`
        : `Searching the web for "${query}".`,
      reasoning: wantsResultClick
        ? `Opening browser, searching for "${query}", and selecting result #${(extractOrdinalIndex(prompt) ?? 0) + 1} as explicitly requested.`
        : `Opening browser and submitting search query for "${query}". Strictly respecting user instruction with zero unprompted clicks.`,
      steps,
    };
  }

  // 4. BROWSER RESULT SELECTION (Explicit command to click/open a search result)
  if (
    isOrdinalSearchResultIntent(prompt) ||
    ((pLower.includes('result') || pLower.includes('article') || pLower.includes('link')) &&
      (pLower.includes('click') || pLower.includes('open') || pLower.includes('tap') || pLower.includes('select')))
  ) {
    const targetIdx = extractOrdinalIndex(prompt) ?? 0;
    const steps: AgentStep[] = [];
    if (currentApp !== 'browser') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'browser',
        detail: 'Open Web Browser',
      });
    }
    steps.push({
      action: 'tap',
      targetName: `browser-result-${targetIdx}`,
      detail: `Select search result article #${targetIdx + 1}`,
    });

    return {
      replyMessage: `Opening search result #${targetIdx + 1}.`,
      reasoning: `Executing explicit user request to open search result #${targetIdx + 1}.`,
      steps,
    };
  }

  // 5. BITEDASH (Food Ordering & Cart)
  if (pLower.includes('food') || pLower.includes('bitedash') || pLower.includes('pizza') || pLower.includes('burger') || pLower.includes('cart') || pLower.includes('checkout') || pLower.includes('order')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'food') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'food',
        detail: 'Launch BiteDash food delivery app',
      });
    }

    // A. View cart only
    if ((pLower.includes('view cart') || pLower.includes('open cart') || pLower.includes('my cart') || pLower.includes('show cart')) && !pLower.includes('add')) {
      steps.push({
        action: 'tap',
        targetName: 'food-floating-cart',
        detail: 'Open cart checkout view',
      });
      return {
        replyMessage: 'Opening your BiteDash cart.',
        reasoning: 'Navigating to cart view. Strictly doing what was requested.',
        steps,
      };
    }

    // B. Category section only
    if ((pLower.includes('category') || pLower.includes('section') || pLower.includes('menu')) && !pLower.includes('add') && !pLower.includes('order')) {
      steps.push({
        action: 'tap',
        targetName: 'category-pizza',
        detail: 'Select Pizza category',
      });
      return {
        replyMessage: 'Showing Pizza category on BiteDash.',
        reasoning: 'Selected pizza category without adding items.',
        steps,
      };
    }

    // C. Add to cart only (do NOT checkout!)
    if (pLower.includes('add') && !pLower.includes('checkout') && !pLower.includes('order')) {
      steps.push({
        action: 'tap',
        targetName: 'category-pizza',
        detail: 'Select Pizza section',
      });
      steps.push({
        action: 'tap',
        targetName: 'add-pizza-to-cart',
        detail: 'Add Artisan Pepperoni Pizza to cart',
      });
      return {
        replyMessage: 'Added Artisan Pepperoni Pizza to your cart.',
        reasoning: 'Added requested item to cart. Stopped before checkout as instructed.',
        steps,
      };
    }

    // D. Order / Checkout
    if (pLower.includes('order') || pLower.includes('buy') || pLower.includes('checkout')) {
      steps.push({
        action: 'tap',
        targetName: 'category-pizza',
        detail: 'Select Pizza category',
      });
      steps.push({
        action: 'tap',
        targetName: 'add-pizza-to-cart',
        detail: 'Add Artisan Pepperoni Pizza to cart',
      });
      steps.push({
        action: 'tap',
        targetName: 'food-floating-cart',
        detail: 'Proceed to checkout view',
      });
      return {
        replyMessage: 'Placing order for Artisan Pepperoni Pizza on BiteDash.',
        reasoning: 'Added pizza to cart and navigated to checkout as requested.',
        steps,
      };
    }

    return {
      replyMessage: 'Opened BiteDash.',
      reasoning: 'Navigated to BiteDash with zero unprompted actions.',
      steps,
    };
  }

  // 6. SOCIAL APP (Pulse)
  if (pLower.includes('social') || pLower.includes('pulse') || pLower.includes('like') || pLower.includes('post') || pLower.includes('feed')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'social') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'social',
        detail: 'Open Pulse Social',
      });
    }

    if (pLower.includes('like') || pLower.includes('heart')) {
      steps.push({
        action: 'tap',
        targetName: 'post-like-button-0',
        detail: 'Like latest post from Elena Rostova',
      });
      return {
        replyMessage: 'Liked the latest post on Social.',
        reasoning: 'Tapped like on target post as requested.',
        steps,
      };
    }

    return {
      replyMessage: 'Opened Pulse Social.',
      reasoning: 'Navigated to social feed without taking unprompted interactions.',
      steps,
    };
  }

  // 7. MESSAGES APP
  if (pLower.includes('message') || pLower.includes('sarah') || pLower.includes('alex') || pLower.includes('text') || pLower.includes('chat') || pLower.includes('sms')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'messages') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'messages',
        detail: 'Open Messages app',
      });
    }

    const isSarah = pLower.includes('sarah') || (!pLower.includes('alex'));
    const threadTarget = isSarah ? 'thread-sarah' : 'thread-alex';
    const contactName = isSarah ? 'Sarah Chen' : 'Alex Rivera';

    const wantsToSend =
      pLower.includes('send') ||
      pLower.includes('text') ||
      pLower.includes('reply') ||
      pLower.includes('tell') ||
      pLower.includes('write to');

    // View conversation thread only
    if (!wantsToSend && (pLower.includes('sarah') || pLower.includes('alex') || pLower.includes('thread') || pLower.includes('conversation'))) {
      steps.push({
        action: 'tap',
        targetName: threadTarget,
        detail: `Open conversation with ${contactName}`,
      });
      return {
        replyMessage: `Opened conversation with ${contactName}.`,
        reasoning: `Navigated to ${contactName}'s thread. Stopped without typing or sending.`,
        steps,
      };
    }

    // Send a message
    if (wantsToSend) {
      steps.push({
        action: 'tap',
        targetName: threadTarget,
        detail: `Select ${contactName} conversation`,
      });

      let textToSend = 'Hey! Running 10 mins late, see you soon!';
      const quoteMatch = prompt.match(/["']([^"']+)["']/);
      if (quoteMatch && quoteMatch[1]) {
        textToSend = quoteMatch[1];
      } else {
        const sayingMatch = prompt.match(/(?:saying|say|that)\s+(.+)$/i);
        if (sayingMatch && sayingMatch[1]) {
          textToSend = sayingMatch[1].trim();
        }
      }

      steps.push({
        action: 'type_text',
        value: textToSend,
        detail: `Compose message: "${textToSend}"`,
      });
      steps.push({
        action: 'tap',
        targetName: 'send-message-btn',
        detail: 'Send message',
      });

      return {
        replyMessage: `Sent message to ${contactName}: "${textToSend}".`,
        reasoning: `Selected thread, composed requested text, and sent message.`,
        steps,
      };
    }

    return {
      replyMessage: 'Opened Messages app.',
      reasoning: 'Navigated to messages overview. Doing strictly what was requested.',
      steps,
    };
  }

  // 8. NOTES APP
  if (pLower.includes('note') || pLower.includes('memo')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'notes') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'notes',
        detail: 'Open Notes app',
      });
    }

    const wantsToCreate =
      pLower.includes('create') ||
      pLower.includes('write') ||
      pLower.includes('new note') ||
      pLower.includes('add note') ||
      pLower.includes('take a note');

    if (wantsToCreate) {
      steps.push({
        action: 'tap',
        targetName: 'new-note-button',
        detail: 'Create new note document',
      });

      let noteTitle = 'Quick Note';
      const quoteMatch = prompt.match(/["']([^"']+)["']/);
      if (quoteMatch && quoteMatch[1]) {
        noteTitle = quoteMatch[1];
      } else {
        const titleMatch = prompt.match(/(?:titled|called|name)\s+([^,.]+)/i);
        if (titleMatch && titleMatch[1]) {
          noteTitle = titleMatch[1].trim();
        }
      }

      steps.push({
        action: 'type_text',
        value: noteTitle,
        detail: `Fill note title: "${noteTitle}"`,
      });
      steps.push({
        action: 'tap',
        targetName: 'save-note-button',
        detail: 'Save note',
      });

      return {
        replyMessage: `Created and saved note: "${noteTitle}".`,
        reasoning: 'Created new note and saved specified title as instructed.',
        steps,
      };
    }

    return {
      replyMessage: 'Opened Notes app.',
      reasoning: 'Navigated to Notes. No unprompted note creation or edits.',
      steps,
    };
  }

  // 9. SETTINGS APP
  if (pLower.includes('setting') || pLower.includes('dark') || pLower.includes('light') || pLower.includes('theme') || pLower.includes('wifi') || pLower.includes('bluetooth') || pLower.includes('battery') || pLower.includes('power')) {
    const steps: AgentStep[] = [];
    if (currentApp !== 'settings') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'settings',
        detail: 'Open Phone Settings',
      });
    }

    if (pLower.includes('dark') || pLower.includes('light') || pLower.includes('theme')) {
      steps.push({
        action: 'tap',
        targetName: 'settings-darkmode-toggle',
        detail: 'Toggle Dark Mode theme preference',
      });
      return {
        replyMessage: 'Toggled Dark Mode in Settings.',
        reasoning: 'Opened settings and toggled theme switch as requested.',
        steps,
      };
    }

    if (pLower.includes('wifi')) {
      steps.push({
        action: 'tap',
        targetName: 'settings-wifi-toggle',
        detail: 'Toggle Wi-Fi connection switch',
      });
      return {
        replyMessage: 'Toggled Wi-Fi in Settings.',
        reasoning: 'Opened settings and adjusted Wi-Fi as requested.',
        steps,
      };
    }

    if (pLower.includes('bluetooth')) {
      steps.push({
        action: 'tap',
        targetName: 'settings-bluetooth-toggle',
        detail: 'Toggle Bluetooth switch',
      });
      return {
        replyMessage: 'Toggled Bluetooth in Settings.',
        reasoning: 'Opened settings and adjusted Bluetooth as requested.',
        steps,
      };
    }

    if (pLower.includes('power') || pLower.includes('battery')) {
      steps.push({
        action: 'tap',
        targetName: 'settings-power-toggle',
        detail: 'Toggle Low Power Mode switch',
      });
      return {
        replyMessage: 'Toggled Low Power Mode in Settings.',
        reasoning: 'Opened settings and toggled low power switch.',
        steps,
      };
    }

    return {
      replyMessage: 'Opened Settings.',
      reasoning: 'Navigated to Settings. Standing by with zero unprompted changes.',
      steps,
    };
  }

  // 10. BANKING & ENTERPRISE
  if (pLower.includes('bank') || pLower.includes('statement') || pLower.includes('charge') || pLower.includes('quickbook') || pLower.includes('invoice')) {
    const steps: AgentStep[] = [];

    if (pLower.includes('quickbook') || pLower.includes('invoice')) {
      if (currentApp !== 'quickbooks') {
        steps.push({
          action: 'navigate_app',
          targetApp: 'quickbooks',
          detail: 'Open QuickBooks Online',
        });
      }
      if (pLower.includes('send') || pLower.includes('dispatch')) {
        steps.push({
          action: 'tap',
          targetName: 'quickbooks-send-invoice',
          detail: 'Dispatch invoice #INV-2026-104',
        });
        return {
          replyMessage: 'Dispatched QuickBooks invoice.',
          reasoning: 'Navigated to QuickBooks and sent invoice as requested.',
          steps,
        };
      }
      return {
        replyMessage: 'Opened QuickBooks.',
        reasoning: 'Navigated to QuickBooks without unprompted actions.',
        steps,
      };
    }

    if (currentApp !== 'banking') {
      steps.push({
        action: 'navigate_app',
        targetApp: 'banking',
        detail: 'Open Apex Secure Bank',
      });
    }

    if (pLower.includes('export') || pLower.includes('download')) {
      steps.push({
        action: 'tap',
        targetName: 'export-statement-btn',
        detail: 'Export bank statement',
      });
      return {
        replyMessage: 'Exported encrypted bank statement.',
        reasoning: 'Navigated to bank and triggered statement export.',
        steps,
      };
    }

    if (pLower.includes('flag')) {
      steps.push({
        action: 'tap',
        targetName: 'flag-charges-btn',
        detail: 'Flag recurring anomaly charge',
      });
      return {
        replyMessage: 'Flagged recurring anomaly charge in Apex Bank.',
        reasoning: 'Navigated to bank and flagged anomaly charge as requested.',
        steps,
      };
    }

    return {
      replyMessage: 'Opened Apex Secure Bank.',
      reasoning: 'Navigated to banking screen without unprompted transactions.',
      steps,
    };
  }

  // 11. USER-INSTALLED / SIDELOADED APPS (WhatsApp, Telegram, YouTube, Spotify, etc.)
  if (Array.isArray(context?.installedApps)) {
    const matchedInstalled = context.installedApps.find(
      (app: { id: string; name: string }) =>
        pLower.includes(app.name.toLowerCase()) || pLower.includes(app.id.toLowerCase())
    );
    if (matchedInstalled) {
      const steps: AgentStep[] = [];
      if (currentApp !== matchedInstalled.id) {
        steps.push({
          action: 'navigate_app',
          targetApp: matchedInstalled.id as PhoneAppType,
          detail: `Open ${matchedInstalled.name}`,
        });
      }
      if (pLower.includes('like') || pLower.includes('bookmark')) {
        steps.push({
          action: 'tap',
          targetName: 'app-action-toggle',
          detail: `Tap Like / Bookmark inside ${matchedInstalled.name}`,
        });
      } else if (pLower.includes('scroll') || pLower.includes('swipe')) {
        steps.push({
          action: 'swipe_up',
          distance: 360,
          detail: `Scroll inside ${matchedInstalled.name}`,
        });
      } else if (pLower.includes('run') || pLower.includes('execute')) {
        steps.push({
          action: 'tap',
          targetName: 'app-action-primary',
          detail: `Execute action inside ${matchedInstalled.name}`,
        });
      }
      return {
        replyMessage: `Opened ${matchedInstalled.name}.`,
        reasoning: `Executed requested action in user-installed app "${matchedInstalled.name}".`,
        steps: steps.length > 0 ? steps : [{ action: 'wait', duration: 100, detail: `Already on ${matchedInstalled.name}` }],
      };
    }
  }

  // Default fallback: Return home safely
  return {
    replyMessage: 'Navigating to Home Screen.',
    reasoning: 'Returning device to home screen. Strictly executing requested navigation without extra actions.',
    steps: [
      { action: 'go_home', detail: 'Swipe up to Home Screen' },
    ],
  };
}
