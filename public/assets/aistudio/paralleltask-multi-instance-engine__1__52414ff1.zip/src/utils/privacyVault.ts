/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function scrubPayloadForCloud(text: string): { scrubbed: string; redactedCount: number } {
  if (!text) return { scrubbed: '', redactedCount: 0 };
  let count = 0;
  let scrubbed = text;

  // Mask SSN / credit cards
  const ccRegex = /\b(?:\d{4}[ -]?){3}\d{4}\b/g;
  if (ccRegex.test(scrubbed)) {
    scrubbed = scrubbed.replace(ccRegex, () => {
      count++;
      return '[REDACTED_PAYMENT_CARD]';
    });
  }

  // Mask passwords / api keys
  const keyRegex = /\b(?:sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{20,})\b/g;
  if (keyRegex.test(scrubbed)) {
    scrubbed = scrubbed.replace(keyRegex, () => {
      count++;
      return '[REDACTED_API_KEY]';
    });
  }

  return { scrubbed, redactedCount: count };
}

export function detectRiskCategory(text: string): 'none' | 'financial' | 'auth' | 'system' {
  const lower = text.toLowerCase();
  if (lower.includes('bank') || lower.includes('invoice') || lower.includes('pay') || lower.includes('wire')) {
    return 'financial';
  }
  if (lower.includes('password') || lower.includes('biometric') || lower.includes('auth') || lower.includes('secret')) {
    return 'auth';
  }
  if (lower.includes('reset') || lower.includes('delete') || lower.includes('factory')) {
    return 'system';
  }
  return 'none';
}
