/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient, SupabaseClient, User } from '@supabase/supabase-js';
import { AuthenticatedUser } from '../types/tokenBilling';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        detectSessionInUrl: true,
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null;

export function mapSupabaseUserToAuthUser(
  user: User,
  referralCode: string = ''
): AuthenticatedUser {
  const email = user.email || '';
  const metadata = user.user_metadata || {};
  const appMeta = user.app_metadata || {};

  const displayName =
    metadata.full_name ||
    metadata.name ||
    metadata.user_name ||
    metadata.preferred_username ||
    (email ? email.split('@')[0] : 'Verified Operator');

  const avatarUrl =
    typeof metadata.avatar_url === 'string' && metadata.avatar_url
      ? metadata.avatar_url
      : typeof metadata.picture === 'string' && metadata.picture
      ? metadata.picture
      : undefined;

  const emailConfirmedAt = user.email_confirmed_at || user.confirmed_at || null;
  const provider =
    typeof appMeta.provider === 'string' && appMeta.provider
      ? appMeta.provider
      : Array.isArray(appMeta.providers) && appMeta.providers[0]
      ? String(appMeta.providers[0])
      : 'email';

  return {
    id: user.id,
    email,
    name: String(displayName),
    referralCode: referralCode || metadata.referral_code || '',
    referredBy: typeof metadata.referral_code === 'string' ? metadata.referral_code : undefined,
    createdAt: user.created_at || new Date().toISOString(),
    emailConfirmedAt,
    isVerified: Boolean(user.email_confirmed_at),
    avatarUrl,
    provider,
  };
}
